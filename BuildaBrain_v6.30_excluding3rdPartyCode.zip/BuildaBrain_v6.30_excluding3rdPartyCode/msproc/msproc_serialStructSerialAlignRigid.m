function serialStructAligned = msproc_serialStructSerialAlignRigid(serialStruct, manualCorrect)

%% not recommended - instead, first convert serialStruct to neurolucida structure format then use neurolucida_align_objects.m
%%

if nargin<2
    manualCorrect = 1;
end

[optimizer, metric] = imregconfig('monomodal')

numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

for iScene = 2:numScenes
    iScene
    %imgFixed = serialStruct.thumb(iScene-1).img;
    %binFixed = serialStruct.thumb(iScene-1).bin;
    sxFixed = serialStruct.thumb(iScene-1).section(:,1);
    syFixed = serialStruct.thumb(iScene-1).section(:,2);
    
    %imgMoving = serialStruct.thumb(iScene).img;
    %binMoving = serialStruct.thumb(iScene).bin;
    sxMoving = serialStruct.thumb(iScene).section(:,1);
    syMoving = serialStruct.thumb(iScene).section(:,2);
    
    % image intensity based registration
    %tform = imregcorr(imgMoving,imgFixed,'rigid');
    %tform = imregtform(imgMoving, imgFixed, 'rigid', optimizer, metric);
    %tform = imregtform(uint8(binMoving), uint8(binFixed), 'rigid', optimizer, metric);
    %tform = imregcorr(uint8(binMoving), uint8(binFixed), 'rigid');
    % section outline based registration
    tform = pcregrigid(pointCloud([sxMoving syMoving zeros(size(sxMoving))]),pointCloud([sxFixed syFixed zeros(size(sxFixed))]));
    
    %imgMoved = imwarp(imgMoving,tform);
    %binMoved = imwarp(binMoving,tform);
    A = maketform('affine',tform.T);
    [sxMoved, syMoved, szMoved] = tformfwd(A, sxMoving, syMoving, zeros(size(sxMoving)));
    
    plot(sxFixed,-syFixed,'k.',sxMoving,-syMoving,'b.',sxMoved,-syMoved,'r.');axis equal;
    if manualCorrect
        x = input('Accept alignment? Yes-Hit Enter Key, No-Enter 0')
        while ~isempty(x)
            disp('Click polygon on blue section to align to previous section');
            h = impoly;
            polyPts = h.getPosition;
            xi = polyPts(:,1); yi = polyPts(:,2);
            tform = pcregrigid(pointCloud([xi -yi zeros(size(xi))]),pointCloud([sxFixed syFixed zeros(size(sxFixed))]));
             A = maketform('affine',tform.T);
            [sxMoved, syMoved, szMoved] = tformfwd(A, sxMoving, syMoving, zeros(size(sxMoving)));
            plot(sxFixed,-syFixed,'k.',sxMoving,-syMoving,'b.',sxMoved,-syMoved,'r.'); axis equal
            x = input('Accept alignment? Yes-Hit Enter Key, No-Enter 0')
        end
    end
    
    serialStruct.thumb(iScene).section = [sxMoved syMoved];
    %serialStruct.thumb(iScene).img = imgMoved;
    %serialStruct.thumb(iScene).bin = binMoved;
    serialStruct.thumb(iScene).transform2prev = A;
    
    numObjects = size(serialStruct.zPlane(1).objects(iScene).blobs,2);
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            btemp = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid;
            if ~isempty(btemp);
                bx = btemp(:,1); by = btemp(:,2);
            else
                bx = []; by = [];
            end
            [bxMoved, byMoved, bzMoved] = tformfwd(A, bx, by, zeros(size(bx)));
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid = [bxMoved byMoved];
            %plot(sxFixed,-syFixed,'k.',sxMoving,-syMoving,'b.',sxMoved,-syMoved,'r.',bxMoved,-byMoved,'r.');axis equal;
        end
    end
end

serialStructAligned = serialStruct;

