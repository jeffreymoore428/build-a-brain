function blobs = msproc_bf_mapBlobsInCZIScene(bfCZISceneReader, sceneNum, channels, params, mask)
%% wrapper function to map blobs in a single scene of a multiscene image.
% inputs:
%   bfCZISceneReader - object containing a bioformats reader object for an image file and
%                       the associated series numbers for each scene. This
%                       object is produced by the function
%                       'msproc_bf_setupCZISeriesFileReader.m)
%   sceneNum - number of desired scene within CZI multiscene file
%   channels - list of channels in which to identify blobs (1 x N)
%                       For channel unmixing: if using image unmixing specify channels as a 2 x N
%                       matrix, where row 1 is the set of desired channels,
%                       and row 2 is the set of channels to subtract from
%                       the corresponding channel in row 1. Specify NaN in
%                       elements of row 2 where no unmixing is desired
%                       Example 1: channels = [2 3 4 ; 1 NaN NaN] will subtract
%                       channel 1 out from channel 2, and leave channels 3
%                       and 4 as is
%                       Example 2: channels = [2 3 4 ; 1 2 3] will subtract
%                       channel 1 out from channel 2, channel 2 out from channel 3, and
%                       channel 3 out from channel 4
%                       when doing channel subtraction, params.correctBG
%                       specifies whether to correct only for bleedthrough
%                       (0) or autofluorescence (1)
%   params -  params - datastructure containing the parameters for spot
%                       detection (see documentation for data types)
%   outputs - 'blobs' data structure containing fields:
%               -blobs.centroid - N x 2 matrix of blob centroids
%               -blobs.bsize - N x 1 vector of blob sizes (total number of
%                       pixels comprising the blob)
%               -blobs.imgThresh - 'imgThresh' datastructure containing
%                       thresholded image data for the current channel
%                       (output of 'blobID.m'). imgThresh is a 1 x M structure
%                       where M is the number of channels
%               -blobs.CC - connected components object for all candidate
%                       blobs in imgThresh, output of MATLAB function
%                       'bwconncomp'
%                       contains additional field:
%                       biginds - indices within CC of valid blobs
% NOTES: if params(1).coloc = 1, blobs is a 1 x 1 struct, containing the detected blobs 
% after thresholded binary images from all channels are multiplied together
% if params.coloc = 0, blobs is an 1 x M structure, where M is the number
% of channels. If params(1).invert = 1, inverts all channels before
% computing spot detection
%%

if nargin<5
    mask = [];
end

% load images
disp('Loading images...');
imgs = msproc_bf_getChannelImgs(bfCZISceneReader, sceneNum, channels, params, mask);

disp('Finding blobs in images...');
[imgB_coloc imgThresh CC centroid bsize] = msproc_blobID(imgs, params);

blobs.centroid = centroid;
blobs.bsize = bsize;
blobs.imgThresh = imgThresh;
blobs.CC = CC;
