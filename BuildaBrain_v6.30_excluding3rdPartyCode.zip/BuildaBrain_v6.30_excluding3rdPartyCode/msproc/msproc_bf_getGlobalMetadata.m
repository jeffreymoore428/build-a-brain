function [keys values] = msproc_bf_getGlobalMetadata(readerObject)
%% extracts metadata from bioformats reader object
% input: 
%   readerObject - biofomrats readerObject for a supported image file (see Bioformats function: 'bfGetReader.m')
% outputs:
%   keys - cell array of key strings from biofomrats metadata
%   values - cell array of value strings from bioformats metadata
%%

metadata = readerObject.getGlobalMetadata;

metadataKeys = metadata.keySet().iterator();
for i=1:metadata.size()
  keys{i} = metadataKeys.nextElement();
  values{i} = metadata.get(keys{i});
  %fprintf('%s = %s\n', key{i}, value{i})
end






