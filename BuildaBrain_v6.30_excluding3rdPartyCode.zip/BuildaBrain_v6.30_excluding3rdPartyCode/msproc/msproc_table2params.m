function params = msproc_table2params(tableTextFilename)
% generate BuildaBrain parameters struct from table .txt file
% table is of format:
% parameters,channel,value
% 'parameterName',...,...

%T = readtable(tableTextFilename);
T = readtable(tableTextFilename,'Format','%s%u%s'); % req'd for matlab 2020
numChannels = max(T.channel)

numFields = size(T,1);
for ichannel = 1:numChannels
    channelparams = struct; % initiate empty struct for each channel
    for ifield=1:numFields % fill fields and values
        if isnumeric(T.value)
            paramValue = T.value(ifield);
        else
            paramValue = str2num(T.value{ifield});
        end
        if ichannel==T.channel(ifield)
            channelparams = setfield(channelparams,T.parameter{ifield},paramValue);
        end
    end
    params(ichannel) = channelparams; % generate params struct, potentially multichannel
end


