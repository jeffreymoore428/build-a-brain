function [imgB imgThresh_intensity imgThresh_rawIntensity imgThresh_inds thresh meanIntensity] = msproc_blobMatchFilter(img, params, mask)
% counts blobs in an image by high pass filtering, thresholding
% OUTPUTS:
%   nboutons - (scalar) total number of boutons in image
%   centroid - x-y pair of centroid coordinates of each detected spot
%   bsize - area of each detected spot (pixels)
% INPUTS:
%   img - matrix of image pixels (1 chan, 2d)
%   params - struct with fields:
%       diameter (avg bouton diameter in pixels)
%       min_size (min diameter as fraction of avg bouton area)
%       bouton_thresh - threshold brighness value
%   mask - (optional) binary image matrix must be of same dimensions as 
%       image (length x height) containing ones in pixels to be counted and
%       zeros in pixels to ignore
%
%   UPDATES
%       added edge effect correction - JM 1/30/18
%       removed default parameters - JM 7/24/18
%       use internal image gaussian filter from matlab
%       added heuristic broad pass filter

% set default settings if not provided  by user
if nargin<3;mask = [];end

% calculate img stats
img_lin = mat2list(img);

% optional broad high-pass prefilter
%imgF = imgaussfilt(img,params.hp_sigma); % SLOW - gaussian filter
imgHP_broad = img;
if ~isempty(params.hp_sigma_broad)
    disp('Pre-filtering image...');
    %dwnFactor = sqrt(params.hp_sigma_broad/params.diameter); % Heuristic fast implementaion - filter on downsampled image
    dwnFactor = params.dwnsamp_broad;
    imgDwn = imresize(img,round(size(img)/dwnFactor));
    imgDwnF = imgaussfilt(imgDwn,round(params.hp_sigma_broad/dwnFactor));
    imgF = imresize(imgDwnF,size(img));
    imgHP_broad = img - imgF;
end

% optional sharp high pass filter
imgHP = imgHP_broad;
if ~isempty(params.hp_sigma_sharp)
    disp('Filtering image...');
    imgF_sharp = imgaussfilt(imgHP_broad,params.hp_sigma_sharp);
    imgHP = imgHP_broad - imgF_sharp; 
end

imgHP_lin_all = single(mat2list(imgHP)); % get histogram of high pass filtered image
imgHP_lin = imgHP_lin_all(img_lin>0); % get histogram of filtered image values where original image value > 0

% threshold image
disp('Thresholding image...');
%imgB = imgSharp>params.bouton_thresh;
% downsample distribution of pixel intensities for computing threshold
% (memory constraint)

maxlength = 1e7;
dwn = 1;
if length(imgHP_lin)>maxlength
    dwn = floor(length(imgHP_lin)/maxlength);
end

meanIntensity = mean(imgHP_lin(1:dwn:end));
stdIntensity = std(imgHP_lin(1:dwn:end));

if isempty(params.absThresh)
    disp(['Applying relative threshold: ',num2str(params.thresh_rel)]);
    thresh = meanIntensity + (params.thresh_rel*stdIntensity);
else
    disp(['Applying absolute threshold: ',num2str(params.absThresh)]);
    thresh = params.absThresh;
end

imgB = logical(imgHP>thresh);

if params.save_pixels
    % get intensities of values above threshold
    imgThresh_inds = find(imgB);
    %imgSharp_gt_thresh = imgHP.*imgB;
    imgThresh_intensity = imgHP(imgThresh_inds);
    imgThresh_rawIntensity = img(imgThresh_inds);
else
    imgThresh_inds = [];
    imgThresh_intensity = [];
    imgThresh_rawIntensity = [];
end

% mask image by user-provided mask
if ~isempty(mask)
    imgB = logical(imgB.*mask);
end