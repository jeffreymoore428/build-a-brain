function scaleFactor = msproc_bf_getCZIScaleFactor(keys,values)
%% extract CZI hardware specified scale factor from CZI metadata
% inputs:
%   keys - cell array of key strings from CZI metadata
%   values - cell array of value strings from CZI metadata
% outputs:
%   scaleFactor - numeric scale factor from CZI um/pixel
% NOTE: keys, values pairs can be obtained by calling the function:
%   [keys values] = msproc_bf_getGlobalMetadata(readerObject) from a
%   bioformats reader object (see Bioformats function: 'bfGetReader.m'
%%
keyinds = [];
for ikey=1:length(keys);
    keyind = strfind(keys{ikey},'Scaling|Distance|Value #1');
    if ~isempty(keyind);
        keyinds = [keyinds ;ikey];
    end
end
scaleFactor = str2num(values{keyinds(1)})*1e6;