function [m,b]  = getLineFrom2Pts(Pt1,Pt2)
% Pt1- [x,y] coords of point1
% Pt2- [x,y] coords of point2
% m - slope of line
% b - intercept of line

m = ( Pt2(2) - Pt1(2) ) / ( Pt2(1) - Pt1(1) );
b = Pt1(2) - m*Pt1(1);