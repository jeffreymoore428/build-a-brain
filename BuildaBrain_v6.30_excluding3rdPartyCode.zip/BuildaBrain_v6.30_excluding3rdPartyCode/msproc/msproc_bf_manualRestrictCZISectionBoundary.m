function serialStruct = msproc_bf_manualRestrictCZISectionBoundary(serialStruct,sectionNums)
%% interactive tool to manually reset slide boundary for specified scenes in image
% interactive tool allows user to specify a subregion in the original background channel image, from
% which to identify the section boundary. User is prompted to either accept
% or reject the new boundary from the restricted region. If rejected, the
% user has a choice to either draw a new subregion, or manually define the
% section outline, or reset the background threshold multiplier ('bg_threshfacor' field in parameter struct). 
%This process is repeated until user accepts the new boundary
% inputs:
%   -serialStruct - serialStruct datastructure
%   -sectionNums - vector of the numbers of sections where section
%   boundaries are needed, or where automated detection failed. SectionNums
%   corresponds to the ID numbers of the sections in the serialStruct
%   'sceneNumber' field (serialStruct.sceneNumber vector)
% outputs:
%   - modified serialStruct datastructure with the updated section outlines
%%

for iSection = 1:length(sectionNums)
    % load section
    objectNum = find([serialStruct.sceneNumber] == sectionNums(iSection));
    disp(['Loading section ',num2str(objectNum)]);
    img = serialStruct.thumb(objectNum).img;
    curBounds = serialStruct.thumb(objectNum).section/serialStruct.thumb(objectNum).downsampling;
    x = curBounds(:,1);y=curBounds(:,2);
    imgClass = class(img);
    threshfactor = serialStruct.thumb(objectNum).threshfactor;
    
    isAccepted = 0;
    msproc_plotImageScale(img); hold on; plot(x,y,'.'); title('See instructions in MATLAB terminal'); hold off;
    while ~isempty(isAccepted);
        checkstop();
        disp('Please select new section boundary limits on figure (Right click to complete)');
        h = impoly;
        newMask = createMask(h);
        if isAccepted == 0
            newMaskTypeCorrected = eval([imgClass,'(newMask);']);
            imgRestrict = img.*newMaskTypeCorrected;
            % get section intensity with updated threshold
            [y x imgSectionBin] = msproc_get_section_intensity(imgRestrict,threshfactor);
        elseif isAccepted == 1
            threshfactor = input('New threshold factor: ');
            newMaskTypeCorrected = eval([imgClass,'(newMask);']);
            imgRestrict = img.*newMaskTypeCorrected;
            % get section intensity with updated threshold
            [y x imgSectionBin] = msproc_get_section_intensity(imgRestrict,threshfactor);
        elseif isAccepted == 2
            polyPts = h.getPosition;
            %x = polyPts(:,1); y = polyPts(:,2);
            %imgSectionBin = logical(newMask);
            [y x imgSectionBin] = msproc_get_section_intensity(newMask,threshfactor,0);
        else
            disp('input not recognized, try again');
        end
        msproc_plotImageScale(img); hold on; plot(x,y,'.');  title('See instructions in MATLAB terminal'); hold off;
        disp(['threshfactor = ',num2str(threshfactor)]); 
        isAccepted = input('Accept new boundary? yes-Enter | retry-0 | reset threshold factor-1 | draw manually-2:');
    end
    
    
    % update slide
    serialStruct.thumb(objectNum).section = [x y]*serialStruct.thumb(objectNum).downsampling;
    serialStruct.thumb(objectNum).bin = imgSectionBin;
end
