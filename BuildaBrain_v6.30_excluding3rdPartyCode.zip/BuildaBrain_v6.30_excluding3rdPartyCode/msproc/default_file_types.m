fileType(1).ext = 'czi';
fileType(1).numLabelSeries = 2;
fileType(1).hasThumbs = 1;