function serialStruct = msproc_slide2serialStruct(filedir,filelist);

serialStruct.type = 'multi-slide compilation';

numSlides = size(filelist,1);

for iSlide = 1:numSlides;
    load([filedir,filelist{iSlide}]);
    numScenes = size(slide.sceneNumber,2);
    if isfield(serialStruct,'thumb')
        lastInd = size(serialStruct.thumb,2);
    else
        lastInd = 0;
    end
    serialStruct.slide(iSlide).filepath = slide.filepath;
    serialStruct.slide(iSlide).channels = slide.channels;
    serialStruct.slide(iSlide).bg_channel = slide.bg_channel;
    serialStruct.slide(iSlide).CZIscenes = slide.sceneNumber;
    serialStruct.slide(iSlide).serialStructIndices = [ (lastInd+1):(lastInd + numScenes) ];
    for iScene = 1:numScenes
        serialStruct.sceneNumber(lastInd + iScene) = lastInd + iScene;
        serialStruct.thumb(lastInd + iScene) = slide.thumb(iScene);
        numPlanes = size(slide.zPlane,2);
        for iPlane = 1:numPlanes
            serialStruct.zPlane(iPlane).objects(lastInd + iScene) = slide.zPlane(iPlane).objects(iScene);
        end
    end
end
            
        