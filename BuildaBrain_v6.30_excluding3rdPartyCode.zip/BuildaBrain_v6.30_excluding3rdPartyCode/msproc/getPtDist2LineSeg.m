function distpt = getPtDist2LineSeg(Pt,cp1_exact,cp2_exact)
% Pt- [x,y] coords of test point
% cp1 - closest point
% cp2 - second closest point
% calculate wrt nearest pixels
cp1 = round(cp1_exact);
cp2 = round(cp2_exact);

x12 = [cp1(1) : cp2(1)];
x21 = [cp2(1) : cp1(1)];
if length(x12)>length(x21)
    x = x12;
else
    x = x21;
end

if all(cp1 == cp2)
    distall =  sqrt( sum( (Pt(1)-cp1(1)).^2 + (Pt(2)-cp1(2)).^2 ) );
elseif cp1(1) == cp2(1)
    y12 = [cp1(2) : cp2(2)];
    y21 = [cp2(2) : cp1(2)];
    if length(y12)>length(y21)
        y = y12;
    else
        y = y21;
    end
    distall =  sqrt( sum( (Pt(1)-cp1(1)).^2 + (Pt(2)-y).^2 ) );
else
    [m,b]  = getLineFrom2Pts(cp1,cp2);
    y = m*x+b;
    distall =  sqrt( sum( (Pt(1)-x).^2 + (Pt(2)-y).^2 ) );
end
distpt = min(distall);
    
