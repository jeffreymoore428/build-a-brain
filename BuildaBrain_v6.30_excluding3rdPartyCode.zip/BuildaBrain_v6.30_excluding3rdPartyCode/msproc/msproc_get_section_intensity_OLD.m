function [y x imgSectionBin] = msproc_get_section_intensity_OLD(img, threshold)

if nargin<2
    threshold = [];
else
    sigmin=threshold;
end

if isempty(threshold)
    % get pixel linear arrays
    imglist = double(mat2list(img));
    imglist_gt_0 = imglist(find(imglist>0));
    
    % fit gaussian mixture to section and background
    %sig(:,:,1) = var(imglist_gt_0)/4;
    %sig(:,:,2) = var(imglist_gt_0)/4;
    sig(:,:,1) = 1;
    sig(:,:,2) = 1;
    S = struct('mu',[prctile(imglist_gt_0,10);prctile(imglist_gt_0,90)],'Sigma',sig);
    GM = fitgmdist(imglist_gt_0,2,'Start',S);
    
    % get gaussian mixture stats
    sigind = find(GM.mu==max(GM.mu));
    bgind = find(GM.mu==min(GM.mu));
    img_bg.mu = GM.mu(bgind);
    img_bg.sigma = sqrt(GM.Sigma(:,:,bgind));
    img_bg.proportion = GM.ComponentProportion(bgind);
    img_sig.mu = GM.mu(sigind);
    img_sig.sigma = sqrt(GM.Sigma(:,:,sigind));
    img_sig.proportion = GM.ComponentProportion(sigind);
    
    bg_sig_ratio = img_bg.sigma/img_sig.sigma;
    % find point that separates section and background blobs
    x = [0:2^16-1];
    y_bg =  img_bg.proportion*(exp((-(x-img_bg.mu).^2)/(2*img_bg.sigma^2)));
    y_sig = img_sig.proportion*(bg_sig_ratio)*(exp((-(x-img_sig.mu).^2)/(2*img_sig.sigma^2)));
    dy=abs(y_bg-y_sig)./(y_bg+y_sig);
    dy(find(x<img_bg.mu | x>img_sig.mu)) = NaN;
    sigmin = x(find(dy==min(dy)));
end

% get perimeter of largest object
imgsig = img>sigmin;
CC = bwconncomp(imgsig);
numPixels = cellfun(@numel,CC.PixelIdxList);
largestind = find(numPixels==max(numPixels),1);
imgSection = zeros(size(img));
imgSection(CC.PixelIdxList{largestind})=1;
%imgPerim = bwperim(imgSection);
%[y x] = find(imgPerim);
B = bwboundaries(imgSection);
y = B{1}(:,1);
x = B{1}(:,2);
imgSectionBin = boolean(imgSection);



