function slide = msproc_bf_manualResetCZISectionBoundary(slidefilepath,sectionNum,threshold)
%% manually reset slide boundary (OBSOLETE DO NOT USE - replaced by 'msproc_bf_manualResetCZISectionBoundary.m')
% inputs:
%   slidefilepath - string of filepath/filename to a file containing a slide datastructure
%   sectionNum - number of section in slide to manually draw section outline
% outputs:
%   slide - new slide data structure with replaced section outline
% WARNING: this function writes overwrites the .mat file containing slide
% datastructure for the named image file
%%
load(slidefilepath);

% load section
bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath);
img = msproc_bf_getCZIScene(bfCZISceneReader, sectionNum, slide.bg_channel, 1);

if nargin<3
    
    % get pixel linear arrays
    imglist = double(mat2list(img));
    imglist_gt_0 = imglist(find(imglist>0));
    figure;
    hist(imglist_gt_0,1000);
    drawnow;
    pause;
    threshold = input('Manually enter intensity threshold for slide: ');
    
    
end

% get section intensity with updated threshold
[y x imgSectionBin] = msproc_get_section_intensity(img, threshold);

% update slide
objectNum = find([slide.sceneNumber] == sectionNum);
slide.thumb(objectNum).section = [x y]*slide.thumb(objectNum).downsampling;
slide.thumb(objectNum).bin = imgSectionBin;

% resave file
save(slidefilepath,'slide','-v7.3');
