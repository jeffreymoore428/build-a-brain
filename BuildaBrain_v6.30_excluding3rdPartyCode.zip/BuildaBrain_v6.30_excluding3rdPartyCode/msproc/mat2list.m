function mat1d = mat2list(mat2d)
% convert 2D matrix or image to a 1D vector

dim1 = size(mat2d,1);
dim2 = size(mat2d,2);

mat1d = reshape(mat2d,dim1*dim2,1);
