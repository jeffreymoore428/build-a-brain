function newSerialStruct = msproc_serialStructReorderSections(serialStruct, newSections)
% remap section order in vector new sections, 

names = fieldnames(serialStruct);
numfields = size(names,1);
for iname = 1:numfields
    curname = names{iname};
    if ~strcmp(curname,'thumb') & ~strcmp(curname,'zPlane')
        eval(['newSerialStruct.',names{iname},' = serialStruct.',names{iname},';']);
    end
end

oldSceneNumbers = serialStruct.sceneNumber;
newSerialStruct.sceneNumber = [1:length(newSections)];

for iScene=1:length(newSections)
    currentScene = find(oldSceneNumbers == newSections(iScene));
    if isempty(currentScene)
        error('newSections references scene number not in current dataset')
    end
    numPlanes = size(serialStruct.zPlane,2);
    for iPlane = 1:numPlanes
        newSerialStruct.thumb(iScene) = serialStruct.thumb(currentScene);
        newSerialStruct.zPlane(iPlane).objects(iScene) = serialStruct.zPlane(iPlane).objects(currentScene);
    end
end
