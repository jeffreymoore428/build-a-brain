function serialSections = msproc_serialStructBoundaries2Contours(serialSections)
% convert boundaries to contours (obsolete - new version of section boundary findre
% does this automatically)

numSections = size(serialSections.thumb,2);
for iSection = 1:numSections
    bw = serialSections.thumb(iSection).bin;
    thumb_factor = serialSections.thumb(iSection).downsampling;
    B = bwboundaries(bw);
    y = B{1}(:,1); 
    x = B{1}(:,2);
    serialSections.thumb(iSection).section = [x y]*thumb_factor;
end