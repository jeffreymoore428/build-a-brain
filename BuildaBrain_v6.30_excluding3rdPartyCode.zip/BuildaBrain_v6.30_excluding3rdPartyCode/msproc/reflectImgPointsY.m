function rpoints = reflectImgPointsY(points,imgDims)

yax = imgDims(1)/2;
rpoints(:,1) = points(:,1);
rpoints(:,2) = ((points(:,2) - yax)*(-1) + yax);
