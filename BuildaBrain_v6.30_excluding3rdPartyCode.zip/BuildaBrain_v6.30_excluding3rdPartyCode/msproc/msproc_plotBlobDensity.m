function densityImgThumbMask = msproc_plotBlobDensity(serialStruct,sceneNum, filterSize, displaySat)
if nargin<4; displaySat = 0.5; end

numPlanes = size(serialStruct.zPlane,2);
objectNum = find([serialStruct.sceneNumber] == sceneNum);
numObjects = size(serialStruct.zPlane(1).objects(objectNum).blobs,2);
for iObj = 1:numObjects
    
    %get object locations
    bx = []; by = [];
    for iPlane = 1:numPlanes
        bx = [bx ; ceil(serialStruct.zPlane(iPlane).objects(objectNum).blobs(iObj).centroid(:,1))];
        by = [by ; ceil(serialStruct.zPlane(iPlane).objects(objectNum).blobs(iObj).centroid(:,2))];
    end
    % calculate density image
    dims = serialStruct.zPlane(1).objects(objectNum).blobs(iObj).imgThresh(1).dims;
    densityImg = msproc_getDensity(dims, bx, by, filterSize);
    
    % resize to thumb size
    thumbSize = size(serialStruct.thumb(objectNum).img);
    imgClass = class(serialStruct.thumb(objectNum).img);
    densityImgThumb = imresize(densityImg,thumbSize);
    mask = double(serialStruct.thumb(objectNum).bin);
    densityImgThumbMask = densityImgThumb .* mask;
    
    % plot
    figure;
    msproc_plotImageScale(uint16(densityImgThumbMask*((2^16)-1)),displaySat); axis equal; hold on;
    thumbScale = serialStruct.thumb(objectNum).downsampling;
    sx = serialStruct.thumb(objectNum).section(:,1)/thumbScale;
    sy = serialStruct.thumb(objectNum).section(:,2)/thumbScale;
    plot(sx,sy,'.','Color',[0.5 0.5 0.5]);
end
