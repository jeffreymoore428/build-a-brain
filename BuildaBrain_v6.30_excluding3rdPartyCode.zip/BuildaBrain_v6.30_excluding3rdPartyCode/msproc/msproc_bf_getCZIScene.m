function img = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, channelNum, thumbFlag)
% return full-resolution image of single channel, single scene from
% multi-scene CZI file
%
% INPUTS:
%           bfCZISceneReader - reader object, output from
%               msproc_bf_setupCZISeriesFileReader.m
%           sceneNum - index of scene to access (1-N)
%           channelNum - index of channel to access (1-N)
%               thumbFlag (optional) - flag top return thumbnail (thumbFlag =
%               1) or full resolution image (thumbFlag = 0) (default)
% OUTPUTS:
%           img - image (2D matrix of pixel intensity values)
%
% J. Moore 7/18/2018

if nargin<4
    thumbFlag = 0;
end

if thumbFlag == 1;
    bfCZISceneReader.r.setSeries(bfCZISceneReader.thumbSeriesInds(sceneNum));
else
    bfCZISceneReader.r.setSeries(bfCZISceneReader.sceneSeriesInds(sceneNum));
end

img = bfGetPlane(bfCZISceneReader.r, channelNum);
