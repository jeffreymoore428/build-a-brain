function serialStruct = msproc_serialStructRemovePixelData(serialStruct)
% remove pixel data from slide or serial sections structure

numZ = size(serialStruct.zPlane,2);

for iP = 1:numZ
    numO = size(serialStruct.zPlane(iP).objects,2);
    for iO = 1:numO
        numB = size(serialStruct.zPlane(iP).objects(iO).blobs,2);
        for iB = 1:numB
            if isfield(serialStruct.zPlane(iP).objects(iO).blobs(iB),'CC')
                serialStruct.zPlane(iP).objects(iO).blobs(iB).CC = [];
            end
            numI = size(serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh,2);
            for iI = 1:numI
                if isfield(serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI),'intensity')
                    serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI).intensity = [];
                end
                if isfield(serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI),'rawIntensity')
                    serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI).rawIntensity = [];
                end
                if isfield(serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI),'inds')
                    serialStruct.zPlane(iP).objects(iO).blobs(iB).imgThresh(iI).inds = [];
                end
            end
        end
    end
end