function [offsets_pix offsets_umSorted] = msproc_bf_getCZISceneOffsets(keys,values)

scaleFactor = msproc_bf_getCZIScaleFactor(keys,values);

keyinds = [];
for ikey=1:length(keys);
    keyind = strfind(keys{ikey},'Information|Image|S|Scene|CenterPosition #');
    % keyind =strfind(keys{ikey},'Experiment|AcquisitionBlock|RegionsSetup|SampleHolder|TileRegion|CenterPosition #'); slide position
    if keyind;
        keyinds = [keyinds ;ikey];
    end;
end

for iind = 1:length(keyinds)
    curkey = keys{keyinds(iind)};
    C = strsplit(curkey,'#');
    sceneNums(iind) = str2num(C{end});
    offsets_um(iind,:) = str2num(values{keyinds(iind)});
end

[sceneNumsSorted sortinds] = sort(sceneNums,'ascend');

offsets_umSorted = offsets_um(sortinds,:);
offsets_pix = offsets_umSorted/scaleFactor;
