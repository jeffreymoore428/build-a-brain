function serialStruct = msproc_serialStructRemoveUnboundedPts(serialStruct)


numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

for iScene = 1:numScenes
    %checkstop();
    numObjects = size(serialStruct.zPlane(1).objects(iScene).blobs,2);
    sx = serialStruct.thumb(iScene).section(:,1);
    sy = serialStruct.thumb(iScene).section(:,2);
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            btemp = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid;
            bsizetemp = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).bsize; % added v5.95
            if ~isempty(btemp)
                in = inpolygon(btemp(:,1),btemp(:,2),sx,sy);
                binx = btemp(find(in),1);
                biny = btemp(find(in),2);
                bsizein = bsizetemp(find(in)); % added v5.95
            else
                binx = []; biny = []; in = []; 
                bsizein = []; % error in v5.95, added v5.96
            end
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).allCentroids = btemp;
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroidsInBounds = in;
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid = [binx biny];
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).bsize = bsizein; % added v5.95
        end
    end
end

