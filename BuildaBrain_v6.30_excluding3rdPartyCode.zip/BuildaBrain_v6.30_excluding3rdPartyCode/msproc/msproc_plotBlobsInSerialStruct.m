function msproc_plotBlobsInSerialStruct(serialStruct, sceneNums, scenes2reflectX, scenes2reflectY)
colors = {'r';'b';'g';'m';'k';'c';'y'};

if nargin<2; sceneNums = []; end

numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

if isempty(sceneNums)
    plotScenes = 1:numScenes;
else
    plotScenes = sceneNums;
end

if nargin<3; scenes2reflectX = [];end
if nargin<4; scenes2reflectY = [];end

numPlotScenes = length(plotScenes);
reflectX = zeros(1,numPlotScenes);
reflectX(scenes2reflectX) = 1;
reflectY = zeros(1,numPlotScenes);
reflectY(scenes2reflectY) = 1;


numTiles = ceil(sqrt(numPlotScenes));
%maxDims = [0 0];
%minDims = [0 0];
minx = 0; maxx = 0;
miny = 0; maxy = 0;

for iScene = 1:numPlotScenes
    %checkstop();
    disp(['Plotting section ',num2str(plotScenes(iScene))]);;
    numObjects = size(serialStruct.zPlane(1).objects(plotScenes(iScene)).blobs,2);
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            btemp = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid;
            bytemp = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid;
            dims = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).imgThresh(1).dims;
            if ~isempty(btemp)
                bx = [bx ; btemp(:,1)];
                by = [by ; btemp(:,2)];
            end
        end
        plotPoints = [bx, by];
        if reflectX(iScene);plotPoints = reflectImgPointsX(plotPoints,dims);end
        if reflectY(iScene);plotPoints = reflectImgPointsX(plotPoints,dims);end
        if(~isempty(plotPoints)); bx = plotPoints(:,1); by = plotPoints(:,2); end
        
        %maxDims = max([maxDims;dims]);
        %minDims = min([minDims;dims]);
        
        subplot(numTiles,numTiles,iScene)
        hold on;
        plot(bx,-by,'.','Color',colors{iObj},'MarkerSize',2);axis equal;
    end
    sx = serialStruct.thumb(plotScenes(iScene)).section(:,1);
    sy = serialStruct.thumb(plotScenes(iScene)).section(:,2);
    plotPoints = [sx, sy];
    if reflectX(iScene);plotPoints = reflectImgPointsX(plotPoints,dims);end
    if reflectY(iScene);plotPoints = reflectImgPointsX(plotPoints,dims);end
    if ~isempty(plotPoints);sx = plotPoints(:,1); sy = plotPoints(:,2);end
    plot(sx,-sy,'.','MarkerSize',2,'Color',[0.5 0.5 0.5]);
    minx = min([minx min(sx)]);
    miny = min([miny min(-sy)]);
    maxx = max([maxx max(sx)]);
    maxy = max([maxy max(-sy)]);
end

for iScene = 1:numPlotScenes
    subplot(numTiles,numTiles,iScene);%xlim([minDims(2) maxDims(2)]);ylim([-maxDims(1) -minDims(1)]);
    xlim([minx maxx]);ylim([miny maxy]);axis equal
end

