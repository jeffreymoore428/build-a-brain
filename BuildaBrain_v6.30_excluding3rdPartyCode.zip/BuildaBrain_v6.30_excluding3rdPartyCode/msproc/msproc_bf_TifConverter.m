function msproc_bf_TifConverter(filedir,filelist,channels,maxProject)

for ifile = 1:size(filelist,1);
    %checkstop();
    disp(['Processing slide ',num2str(ifile)]);
    filepath = [filedir,filelist{ifile}];
    msproc_bf_seriesFile2Tif(filepath, channels, maxProject);
end