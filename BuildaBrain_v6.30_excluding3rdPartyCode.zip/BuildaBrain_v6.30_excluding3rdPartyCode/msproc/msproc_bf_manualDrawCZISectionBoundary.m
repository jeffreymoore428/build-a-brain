function slide = msproc_bf_manualDrawCZISectionBoundary(slidefilepath,sectionNum)
%% manually reset slide boundary (OBSOLETE DO NOT USE - replaced by 'msproc_bf_manualResetCZISectionBoundary.m')
% inputs:
%   slidefilepath - string of filepath/filename to a bioformats supported image
%   sectionNum - number of section in slide to manually draw section outline
% outputs:
%   slide - new slide data structure with replaced section outline
% WARNING: this function writes overwrites the .mat file containing slide datastructure for the named image
%%
load(slidefilepath);

% load section
bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath);
img = msproc_bf_getCZIScene(bfCZISceneReader, sectionNum, slide.bg_channel, 1);

% draw section outline
msproc_plotImageScale(img);
h = impoly;
polyPts = h.getPosition;
x = polyPts(:,1); y = polyPts(:,2);

% update slide

objectNum = find([slide.sceneNumber] == sectionNum);
slide.thumb(objectNum).section = [x y]*slide.thumb(objectNum).downsampling;

% resave file
save(slidefilepath,'slide','-v7.3');
