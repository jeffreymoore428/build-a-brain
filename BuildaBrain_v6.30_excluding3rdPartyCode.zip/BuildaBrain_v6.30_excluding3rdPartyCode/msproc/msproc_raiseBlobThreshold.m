function serialStruct = msproc_raiseBlobThreshold(serialStruct,sizeThresholdLow,sizeThresholdHigh,intensityThreshold)

nZ = size(serialStruct.zPlane,2);
for iZ = 1:nZ
    nObj = size(serialStruct.zPlane(iZ).objects,2);
    for iObj = 1:nObj
        nBlobs = size(serialStruct.zPlane(iZ).objects(iObj).blobs,2);
        disp(['Re-thresholding image ',num2str(iObj),'/',num2str(nObj)]);
        for iBlob = 1:nBlobs
            nImgs = size(serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh,2);
            xydims = serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(1).dims;
            xyzdims = [xydims, nImgs];
            imgsB = zeros(xyzdims,'logical');
            for iImg = 1:nImgs
                temp = serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(iImg);
                if ~isnan(intensityThreshold(iBlob,iImg))
                    newIntenseInds = find(temp.intensity > intensityThreshold(iBlob,iImg));
                else
                    newIntenseInds = find(temp.intensity);
                end
                newparams = temp.params;
                newparams.min_size = sizeThresholdLow(iBlob);
                newparams.max_size = sizeThresholdHigh(iBlob);
                intensity = temp.intensity(newIntenseInds);
                inds = temp.inds(newIntenseInds);
                serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(iImg).intensity = intensity;
                serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(iImg).inds = inds;
                serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(iImg).absoluteThresh = intensityThreshold(iBlob,iImg);
                serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(iImg).params = newparams;
                newimgB = zeros(temp.dims,'logical');
                newimgB(inds) = true;
                imgsB(:,:,iImg) = newimgB;
            end
            imgB_coloc = prod(imgsB,3);
            tempParams = serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).imgThresh(1).params;
            [CC centroid bsize nblobs] = msproc_blobCountInBinaryImg(imgB_coloc,tempParams);  
            serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).centroid = centroid;
            serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).bsize = bsize;
            serialStruct.zPlane(iZ).objects(iObj).blobs(iBlob).CC = CC;
        end
    end
end

