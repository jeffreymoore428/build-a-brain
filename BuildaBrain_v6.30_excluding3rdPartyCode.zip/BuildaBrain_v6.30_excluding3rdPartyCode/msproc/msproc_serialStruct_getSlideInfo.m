function [slideInd,sceneInSlide,slideFilename,slideOrigPath] = msproc_serialStruct_getSlideInfo(serialStruct,sceneNumber)

sceneInSlide = [];
slideInd = [];
slideOrigPath = [];
slideFilename = [];

if strcmp(serialStruct.type,'multi-slide-compilation')
    for islide = 1:size(serialStruct.slide,2)
        ssInd = find(serialStruct.slide(islide).serialStructIndices==sceneNumber);
        sceneInSlide = serialStruct.slide(islide).CZIscenes(ssInd);
        if ~isempty(sceneInSlide)
            slideInd = islide;
            pathfilename = serialSections.slide(islide).filepath;
            [ slideFilename, slideOrigPath ] = getFilenameFromFullPath(pathfilename)
            break;
        end
        error('BB error: Scene number not available');
    end
elseif strcmp(serialStruct.type,'slide')
    slideInd = 1;
    [ slideFilename, slideOrigPath ] = getFilenameFromFullPath(serialStruct.filepath);
    sceneInSlide = sceneNumber;
else
    error('BB error: SerialStruct type not recognized');
end