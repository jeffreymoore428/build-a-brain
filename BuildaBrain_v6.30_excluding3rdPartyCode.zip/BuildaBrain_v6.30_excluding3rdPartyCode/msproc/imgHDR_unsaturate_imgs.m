function imgHDR = imgHDR_unsaturate_imgs(dim_img,bright_img,nbits,dim_scale_factor, dwn)

% use 2 images acquired at different exposures to unsaturate

% output -  double precision image
% inputs -  dim_img - low exposure image matrix
%           bright_img - high exposure image matrix
%           nbits - bit resolution of images (wrapper wode will extract
%               this automatically) 8 or 16 bit
%           dim_scale_factor - (optional) scale factor to multiply dim image by to
%               maximize dynamic range. DEFAULT: maximum value that does
%               not saturate the dim image
%           dwn - (optional) downampling factor used for computing relative 
%               gain between the images, to speed up computation. DEFAULT: 1000 
%
%           JDM 2018/08/16

%% set default parameters if not supplied
% downsampling factor for computing gains if not supplied by user (for speed)
if nargin<5 || isempty(dwn)
    dwn = 1000;
end

% set default scaling factor of dim image to not saturate, if not supplied by user
if nargin<4 || isempty(dim_scale_factor)
    dim_scale_factor = (2^nbits - 1)/double(max(max(dim_img)));
end

maxVal = 2^(nbits-1)-1; % find threshold (all pixels with highest bit=1

%% compute relative gain between the two images
nonsatInds = dim_img<maxVal & bright_img<maxVal; % get unsaturated pixel indices
dimList = dim_img(nonsatInds);
brightList = bright_img(nonsatInds);
dimList_dwn = double(dimList(1:dwn:end)); % downsample list of unsaturated pixels
brightList_dwn = double(brightList(1:dwn:end));
slope = fastRegressionSlope(dimList_dwn,brightList_dwn);

%% rescale pixel intensities so that unsaturated pixels are matched, with
% the user specified gain
bright_img_scaled = (double(bright_img)/slope)*dim_scale_factor;
dim_img_scaled = double(dim_img)*dim_scale_factor;

%% replace pixels with MSB=1 with the dim image
imgHDR = bright_img_scaled;
brightSat = bright_img>=maxVal;
imgHDR(brightSat) = dim_img_scaled(brightSat);

%% calculate scale factor
function slope = fastRegressionSlope(x,y)
slope = corr(x,y)*std(y)/std(x);
