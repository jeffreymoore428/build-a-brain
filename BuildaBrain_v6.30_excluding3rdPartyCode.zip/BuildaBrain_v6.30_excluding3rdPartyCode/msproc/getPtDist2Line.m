function dist = getPtDist2Line(Pt,m,b);
% Pt- [x,y] coords of point
% m - slope of line
% b - intercept of line

% get standard line form
%A = m; B = -1; C = b;
%dist = abs(A*Pt(1) + B*Pt(2) + C) / sqrt(A^2 + B^2);

% get perpendicular line through point
m_perp = -1/m;
b_perp = Pt(2) - m_perp*Pt(1);

x = (b-b_perp) / (m_perp - m);
y = m*x+b;

dist = sqrt( sum((Pt - [x y]).^2) );