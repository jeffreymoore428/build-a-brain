function slide = msproc_bf_setCZIImageOffsetsInSlide(slide)

r = bfGetReader(slide.filepath);
[keys values] = msproc_bf_getGlobalMetadata(r);
scaleFactor = msproc_bf_getCZIScaleFactor(keys,values);
[offsets_pix offsets_umSorted] = msproc_bf_getCZISceneOffsets(keys,values);
slide.scaleFactor = scaleFactor;

numScenes = length(slide.sceneNumber);
for iScene = 1:numScenes
    sceneNum = slide.sceneNumber(iScene);
    dims = slide.zPlane(1).objects(iScene).blobs(1).imgThresh(1).dims;
    slide.thumb(iScene).offset_pix = offsets_pix(sceneNum,:)-[ dims(2)/2 dims(1)/2 ];
    slide.thumb(iScene).slide_boundary_x = offsets_pix(sceneNum,1) + [-1 1] * dims(2)/2;
    slide.thumb(iScene).slide_boundary_y = offsets_pix(sceneNum,2) + [-1 1] * dims(1)/2;
end

% find image boundaries in slide
xmin = Inf; xmax = -Inf;
ymin = Inf; ymax = -Inf;
for iScene = 1:numScenes
    xmin = min(xmin,slide.thumb(iScene).slide_boundary_x(1));
    xmax = max(xmax,slide.thumb(iScene).slide_boundary_x(2));
    ymin = min(ymin,slide.thumb(iScene).slide_boundary_y(1));
    ymax = max(ymax,slide.thumb(iScene).slide_boundary_y(2));
end
slide.xbounds_pix = [xmin xmax];
slide.ybounds_pix = [ymin ymax];

