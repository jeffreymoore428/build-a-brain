function [imgB_coloc imgThresh CC centroid bsize] = msproc_blobID(imgs, params)

% blob match filter to identify boutons
for iimg = 1:size(imgs,3)
    iimg_params = params;
    % select different filters for each channel if provided
    if length(params.thresh_rel)>1;iimg_params.thresh_rel = params.thresh_rel(iimg);end
    if length(params.absThresh)>1; iimg_params.absThresh = params.absThresh(iimg);end
    if length(params.absThresh)>size(imgs,3);warning('Warning: more thresholds than channels');end
    if length(params.thresh_rel)>size(imgs,3);warning('Warning: more thresholds than channels');end
    % implement filter
    disp(['Applying matched filter ',num2str(iimg),'/',num2str(size(imgs,3)),'...']);
    [imgB_iimg imgThresh_intensity imgThresh_rawIntensity imgThresh_inds thresh meanIntensity] = msproc_blobMatchFilter(imgs(:,:,iimg), iimg_params);
    imgB(:,:,iimg) = imgB_iimg;
    imgThresh(iimg).intensity = imgThresh_intensity;
    imgThresh(iimg).rawIntensity = imgThresh_rawIntensity;
    imgThresh(iimg).inds = imgThresh_inds;
    imgThresh(iimg).dims = size(imgB_iimg);
    imgThresh(iimg).params = iimg_params;
    imgThresh(iimg).meanIntensity = meanIntensity;
    imgThresh(iimg).thresh = thresh;
end
% find blobs present in all channels 
imgB_coloc = prod(imgB,3); %(imgB_coloc == imgB if single channel)

% map boutons
disp('Mapping acceptable blobs...');
[CC centroid bsize nblobs] = msproc_blobCountInBinaryImg(imgB_coloc,params);

if ~params.save_pixels
    CC = [];
end