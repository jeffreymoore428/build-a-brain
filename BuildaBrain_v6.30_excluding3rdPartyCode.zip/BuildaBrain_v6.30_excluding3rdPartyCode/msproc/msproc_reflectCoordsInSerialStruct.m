function serialStruct = msproc_reflectCoordsInSerialStruct(serialStruct, sceneNums, scenes2reflectX, scenes2reflectY)
colors = {'r';'b';'g';'m'};

if nargin<2; sceneNums = []; end

numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

if isempty(sceneNums)
    plotScenes = 1:numScenes;
else
    plotScenes = sceneNums;
end

if nargin<3; scenes2reflectX = [];end
if nargin<4; scenes2reflectY = [];end

numPlotScenes = length(plotScenes);
reflectX = zeros(1,numPlotScenes);
reflectX(scenes2reflectX) = 1;
reflectY = zeros(1,numPlotScenes);
reflectY(scenes2reflectY) = 1;

for iScene = 1:numPlotScenes
    plotScenes(iScene)
    numObjects = size(serialStruct.zPlane(1).objects(plotScenes(iScene)).blobs,2);
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            btemp = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid;
            dims = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).imgThresh(1).dims;
            if ~isempty(btemp)
                bx = [bx ; btemp(:,1)];
                by = [by ; btemp(:,2)];
            end
        end
        plotPoints = [bx, by];
        if reflectX(iScene) & ~isempty(plotPoints);plotPoints = reflectImgPointsX(plotPoints,dims);end
        if reflectY(iScene) & ~isempty(plotPoints);plotPoints = reflectImgPointsY(plotPoints,dims);end
        if(~isempty(plotPoints)); bx = plotPoints(:,1); by = plotPoints(:,2); end
        
        %plot(bx,-by,'.','Color',colors{iObj},'MarkerSize',2);axis equal;
        serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid = [bx by];
    end
    sx = serialStruct.thumb(plotScenes(iScene)).section(:,1);
    sy = serialStruct.thumb(plotScenes(iScene)).section(:,2);
    img = serialStruct.thumb(plotScenes(iScene)).img;
    bin = serialStruct.thumb(plotScenes(iScene)).bin;
    plotPoints = [sx, sy];
    if reflectX(iScene);
        plotPoints = reflectImgPointsX(plotPoints,dims);
        img = fliplr(img);
        bin = fliplr(bin);
    end
    if reflectY(iScene);
        plotPoints = reflectImgPointsY(plotPoints,dims);
        img = flipud(img);
        bin = flipud(bin);
    end
    if ~isempty(plotPoints);sx = plotPoints(:,1); sy = plotPoints(:,2);end
    %plot(sx,-sy,'.','Color',[0.5 0.5 0.5]);
    serialStruct.thumb(plotScenes(iScene)).section = [sx sy];
    serialStruct.thumb(plotScenes(iScene)).img = img;
    serialStruct.thumb(plotScenes(iScene)).bin =bin;
    serialStruct.thumb(plotScenes(iScene)).isReflectedX = reflectX(iScene);
    serialStruct.thumb(plotScenes(iScene)).isReflectedY = reflectY(iScene);
end


