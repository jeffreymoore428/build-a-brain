function sPoints = remove_close_markers3(points1,thresh);

%% finds colocolization of markers in 3D
% inputs:
%   points1 - N x 3 array of coordinates
%   thresh - threshold Eucliean distance to consider colocalized
% outputs:
%   single_markers - markers with multiples removed
%%

x1 = points1(:,1);
y1 = points1(:,2);
z1 = points1(:,3);

i=1; sPoints = [];
while i<length(x1)
    % create new points with current point deleted
    x2 = x1(i+1:end);
    y2 = y1(i+1:end);
    z2 = z1(i+1:end);
    dist2allOthers = sqrt( (x1(i)-x2).^2 + (y1(i)-y2).^2 + (z1(i)-z2).^2 );
    x1(dist2allOthers<thresh) = [];
    y1(dist2allOthers<thresh) = [];
    z1(dist2allOthers<thresh) = [];
    sPoints = [sPoints ; x1(i) y1(i) z1(i)];
    i=i+1
end
single_markers = [x1 , y1, z1];
