function imginv = img_invert(img);
% invert single channel image

maxval = max(max(img));
imginv = maxval - img;
