function [blobIntensity blobSize blobRawIntensity] = msproc_getBlobIntensity(blobStruct)

if isfield(blobStruct(1).imgThresh(1),'rawIntensity');
    calcRawIntensity = 1;
else
    calcRawIntesnity = [];
    blobRawIntensity = [];
end

numChannels = size(blobStruct.imgThresh,2);
for ichan = 1:numChannels
    numblobs = length(blobStruct.CC.bigInds);
    for iblob = 1:numblobs
        %disp([num2str(iblob),'/',num2str(numblobs)]);
        blobInd = blobStruct.CC.bigInds(iblob);
        blobInds = blobStruct.CC.PixelIdxList{blobInd};
        threshInds = blobStruct.imgThresh(ichan).inds;
        threshIntensity = blobStruct.imgThresh(ichan).intensity;
        if calcRawIntensity
            threshRawIntensity = blobStruct.imgThresh(ichan).rawIntensity;
        end
        [C iThreshInds iBlobInds] = intersect(threshInds,blobInds);
        blobIntensity(iblob,ichan) = mean(threshIntensity(iThreshInds));
        if calcRawIntensity
            blobRawIntensity(iblob,ichan) = mean(threshRawIntensity(iThreshInds));
        end
        blobSize(iblob) = length(blobInds);
    end
end
     