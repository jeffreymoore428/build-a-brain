function msproc_bf_seriesFile2Tif(filepath, channels, maxProject, scenes)

if nargin<4;scenes = [];end
if nargin<3;maxProject = 0;end

% if background subtraction parameter selected, choose whether to corect
% for bleedthrough or autofluorescence
if size(channels,1)==2
    correctBG = input('Correct for bleedthrough (0) or background/autofluorescence (1)?')
    if (correctBG ~=0 & correctBG ~= 1)
        disp('Warning: correction value must be 0 or 1. Using default (0)...')
        correctBG = 0;
    end
end

bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(filepath);

if isempty(scenes)
    scenes2process = [1:bfCZISceneReader.numScenes];
else
    scenes2process = scenes;
end

numPlanes = bfCZISceneReader.numPlanes;
numChannels =  bfCZISceneReader.numChannels;

dotInds = strfind(filepath,'.'); 
lastDot = dotInds(end);

for iScene = 1:length(scenes2process);
    disp(['Processing scene ',num2str(scenes2process(iScene))]);
    if maxProject
        img0 = msproc_bf_getCZIScene(bfCZISceneReader, scenes2process(iScene), 1)*0;
        for ichannel = 1:length(channels)
            img0_allchans(:,:,ichannel) = img0;
        end
    end
    % get tif for each z-plane
    for iPlane = 1:numPlanes
        disp(['Processing plane ',num2str(iPlane)]);
        % creat filename
        for ichannel = 1:size(channels,2)
            img_temp = msproc_bf_getCZIScene(bfCZISceneReader, scenes2process(iScene), (iPlane-1)*numChannels + channels(1,ichannel));
            if size(channels,1)==2 & ~isnan(channels(2,ichannel))
                img2subtract = msproc_bf_getCZIScene(bfCZISceneReader, scenes2process(iScene), (iPlane-1)*numChannels + channels(2,ichannel));
                img_temp = unmix_channels(img_temp,img2subtract,correctBG);
            end
            if maxProject
                img_currentPlane = img_temp;
                imgs(:,:,ichannel) = max(img0_allchans(:,:,ichannel),img_currentPlane);
                img0_allchans(:,:,ichannel) = imgs(:,:,ichannel);
            else
                imgs(:,:,ichannel) = img_temp;
            end
        end
        if maxProject
        else
            tifName = [filepath(1:lastDot-1),'_Scene_',num2str(scenes2process(iScene)),'_Plane_',num2str(iPlane),'.tif'];
            imwrite(imgs,tifName,'tif');
        end
    end
    if maxProject
        tifName = [filepath(1:lastDot-1),'_Scene_',num2str(scenes2process(iScene)),'.tif'];
        imwrite(imgs,tifName,'tif','Quality',85);
    end
    clear imgs
end