function [img_inds_fullres img_inds_thumbs sizexy_imgs] = msproc_bf_mapCZISeries2Scene(r, bg_downsample)
% identify scenes in multi-scene CZI image
% used for creating bfReaderObject in function
% 'msproc_bf_setupCZISeriesFileReader.m'

% INPUTS:
%           r - reader object from bioformats matlab package
% OUTPUTS:
%           img_inds_fullres - reader object series indices for full
%           resolution scene images
%           img_inds_thumbs - reader object series indices for lowest
%           resolution scene images
%           sizexy-imgs - number of pixels in each reader object series
%           image
%
% J. Moore 7/18/2018

if nargin<2  % added 12/2019 for multi-resolution thumbs
    bg_downsample = [];
end

% read in table of image file type parameters
fileFmtFilename = 'default_file_format_encoding.txt';
T = readtable(fileFmtFilename);


originalSeries = r.getSeries;

for i=1:r.getSeriesCount;
    r.setSeries(i-1); 
    %I = bfGetPlane(r, 1); 
    sizexy(i,:) = [r.getSizeX r.getSizeY];
end
totalsize = prod(sizexy,2);

fileName = char(r.getCurrentFile);
fileTypeSep = strfind(fileName,'.');
fileType = fileName(fileTypeSep(end)+1:end);

fileTypeInd = find(cellfun(@(x)strcmp(x,fileType),T.FileType));
if ~isempty(fileTypeInd)
    disp(['Image type: ',T.FileType{fileTypeInd}]);
    numLabelSeries = T.numLabelSeries(fileTypeInd);
    hasThumbs = T.hasThumbs(fileTypeInd);
else
    warning('File type not recognized');
    numLabelSeries = 0;
    hasThumbs = 0;
end

sizexy_imgs = totalsize(1:end-numLabelSeries);
if hasThumbs
    img_inds_fullres = [0 ; find(diff(sizexy_imgs)>0)];
    img_inds_thumbs  = [img_inds_fullres(2:end)-1 ; length(sizexy_imgs)-1];
else
    img_inds_fullres = [1:r.getSeriesCount]-1;
    img_inds_thumbs  = img_inds_fullres;
end

% return r to original state
r.setSeries(originalSeries);

if ~isempty(bg_downsample)  % added 12/2019 for multi-resolution thumbs
    % modify thumbs to use an intermediate resolution
    % 1 = fully downsampled thumbs, 0 = full resolution thumbs
    img_inds_thumbs = round(prctile([img_inds_fullres' ; img_inds_thumbs'],100*bg_downsample))';
end



    

