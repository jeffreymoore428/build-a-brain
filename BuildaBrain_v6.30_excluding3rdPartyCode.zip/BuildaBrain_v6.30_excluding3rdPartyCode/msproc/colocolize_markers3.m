function [colocID1_rd colocID2_rd minDistColoc minDist] = colocolize_markers3(points1,points2,thresh);

%% finds colocolization of markers in 3D
% inputs:
%   points1 - N x 3 array of coordinates
%   points2 - N x 3 array of coordinates
%   thresh - threshold Eucliean distance to consider colocalized
% outputs:
%   colocID1_rd - array of indices within 'points1' that are colocalized with a point in 'points2'
%   colocID2_rd - array of indices within 'points2' that are colocalized with a point in 'points1'
%   minDistColoc - distance between pairs of colocalized points
%   minDist - for each point in points1, the distance to the closest point in points2
%%

x1 = points1(:,1);
y1 = points1(:,2);
z1 = points1(:,3);

x2 = points2(:,1);
y2 = points2(:,2);
z2 = points2(:,3);

for i=1:length(x1);
    %checkstop();
    dist1To2(:,i) = sqrt( (x1(i)-x2).^2 + (y1(i)-y2).^2 + (z1(i)-z2).^2 );
    minDist(i) = min(dist1To2(:,i));
    minDistID2(i) = find(dist1To2(:,i) == min(dist1To2(:,i)),1);
end
isColoc = minDist<thresh;
colocID1 = find(isColoc);
colocID2 = minDistID2(isColoc);
minDistColoc = minDist(colocID1); 

colocID1_rd = [];
colocID2_rd = [];
minDistColoc_rd = [];
% % remove duplicates
for i=1:length(colocID1)
    %checkstop();
    dupInds = find(colocID2 == colocID2(i));
    if length(dupInds)==1
        colocID1_rd = [colocID1_rd ; colocID1(i)];
        colocID2_rd = [colocID2_rd ; colocID2(i)];
        minDistColoc_rd = [minDistColoc_rd ; minDistColoc(i)];
    elseif length(dupInds>1)
        bestDupInd = find( minDistColoc(dupInds) == min(minDistColoc(dupInds)), 1);
        bestInd = dupInds(bestDupInd);
        if i==bestInd
            colocID1_rd = [colocID1_rd ; colocID1(i)];
            colocID2_rd = [colocID2_rd ; colocID2(i)];
            minDistColoc_rd = [minDistColoc_rd ; minDistColoc(i)];
        end
    else
        warning('colocolization not found!');
    end
end


    