function [colocID1_rd minDist] = colocolize_markers3_self(points1,thresh);

colocID1_rd = [];

nPts = size(points1,1);
for iPt = 1:nPts
    curPt = points1(iPt,:);
    otherInds = [ 1:(iPt-1),(iPt+1):nPts ];
    otherPts = points1(otherInds',:);
    [colocID1_rd_cur colocID2_rd minDistColoc minDist_cur] = colocolize_markers3_fast(curPt,otherPts,thresh);
    colocID1_rd = [colocID1_rd ; iPt(colocID1_rd_cur)];
    minDist(iPt) = minDist_cur;
end
    