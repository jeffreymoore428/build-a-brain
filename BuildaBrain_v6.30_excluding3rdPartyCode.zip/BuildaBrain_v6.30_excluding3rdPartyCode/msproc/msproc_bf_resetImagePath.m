function slide = msproc_bf_resetImagePath(slide,newpath)

if nargin<2
    newpath = [];
end

if isempty(newpath)
    newpath = uigetdir(pwd,'Cannot locate slide! Please choose the directory where the slide image is stored:');
end

if strcmp(slide.type,'slide')
    [pathstr,name,ext] = fileparts(slide.filepath);
    newfilepath = [newpath,getPathSlash(newpath),name,ext];
    if exist(newfilepath)
        slide.filepath = [newpath,getPathSlash(newpath),name,ext];
    else
        error(['BB error: New path does not contain a file named: ',name,ext]);
    end
else
    error('BB error: can only reset image path for "slide" datasets')
end