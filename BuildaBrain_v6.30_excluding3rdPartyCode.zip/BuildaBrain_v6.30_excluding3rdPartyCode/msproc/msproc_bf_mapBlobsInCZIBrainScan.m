function slideFileNames = msproc_bf_mapBlobsInCZIBrainScan(filedir,filelist,channels,bg_channel, params, outputFilename)
%% wrapper function to identify objects in a set of images
% inputs:
%   filedir - string containing the path to the directory containing the image files (e.g. CZI multiscene files)
%   filelist - cell array of strings contining the filenames of the image files
%   channels - indices of channels to process (first imaged channel is 1)
%   bg_channel - channel from which to identify section outlines
%   params - datastructure containing the parameters for spot detection (see documentation for data types
% outputs:
%   list of file names for datasets created
% effects:
% for each image file, saves a file in the current working directory called
% 'slide_[imageFileName].mat' containing a 'slide' datastruct.
% Additionally, this function saves a file called 'SerialSections.mat'
% concatenating the scenes in all image files into a single serialStruct
% dataset. The file 'serialSections.mat' contains this serialStruct object
% called 'serialSections', in the present working directory

if nargin<6
    outputFilename = 'serialSections.mat';
end

curdir = cd;
slashChar = getPathSlash(curdir);

for ifile = 1:size(filelist,1);
    disp(['Processing slide ',num2str(ifile)]);
    filepath = [filedir,filelist{ifile}];
    slide = msproc_bf_mapInCZISeriesFile(filepath, channels, bg_channel, params);
    % save each slide
    slideFileNames{ifile} = ['slide_',filelist{ifile},'.mat'];
    save(slideFileNames{ifile},'slide','-v7.3');
end
slideFileNames = slideFileNames';
serialSections = msproc_slide2serialStruct([curdir,slashChar],slideFileNames);
save(outputFilename,'serialSections','-v7.3');
