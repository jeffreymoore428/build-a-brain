function serialSections = msproc_bf_stripCZIImageOffsets(serialSections)

% strip all slide positioning parameters if they're there
if isfield(serialSections,'xbounds_pix');
    serialSections = rmfield(serialSections,'xbounds_pix');
end
if isfield(serialSections,'ybounds_pix');
    serialSections = rmfield(serialSections,'ybounds_pix');
end
if isfield(serialSections.thumb,'offset_pix')
    serialSections.thumb = rmfield(serialSections.thumb,'offset_pix');
end
if isfield(serialSections.thumb,'slide_boundary_x')
    serialSections.thumb = rmfield(serialSections.thumb,'slide_boundary_x');
end
if isfield(serialSections.thumb,'slide_boundary_y')
    serialSections.thumb = rmfield(serialSections.thumb,'slide_boundary_y');
end

