function msproc_plotBlobsOnSlide(serialStruct, sceneNums)
colors = {'r';'b';'g';'m'};

if nargin<2; sceneNums = []; end

numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

if isempty(sceneNums)
    plotScenes = 1:numScenes;
else
    plotScenes = sceneNums;
end

numPlotScenes = length(plotScenes);

for iScene = 1:numPlotScenes
    plotScenes(iScene)
    numObjects = size(serialStruct.zPlane(1).objects(plotScenes(iScene)).blobs,2);
    sx = serialStruct.thumb(plotScenes(iScene)).section(:,1);
    sy = serialStruct.thumb(plotScenes(iScene)).section(:,2);
    if isfield(serialStruct.thumb(plotScenes(iScene)),'offset_pix');
        offsetx = serialStruct.thumb(plotScenes(iScene)).offset_pix(1);
        offsety = serialStruct.thumb(plotScenes(iScene)).offset_pix(2);
    else
        offsetx = 0;
        offsety = 0;
    end
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            btemp = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid;
            bytemp = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).centroid;
            dims = serialStruct.zPlane(iPlane).objects(plotScenes(iScene)).blobs(iObj).imgThresh(1).dims;
            if ~isempty(btemp)
                bx = [bx ; btemp(:,1)];
                by = [by ; btemp(:,2)];
            end
        end

        hold on;
        plot(bx+offsetx,-(by+offsety),'.','Color',colors{iObj},'MarkerSize',2);axis equal;
    end
   
    plot(sx+offsetx,-(sy+offsety),'.','Color',[0.5 0.5 0.5]);
end

