function slide = msproc_bf_mapInCZISeriesFile(filepath, channels, bg_channel, params, scenes, displaySat)
%% wrapper function to map section outlines and spots in a multiscene file
% inputs:
%   filepath - string containing path and filename of (multiscene) image
%               file
%   channels - vector of channel indices to process (1 indexed)
%   bg_channel - channel number of background channel, used to calculate
%               section outline
%   params -  datastructure containing the parameters for spot detection
%               (see documentation for data types)
%   scenes - vector of scene indices to process. indices are scene numbers
%               in (multiscene) image file (default: all)
%   displaySat - percentage of pixels to show as saturated when displaying
%               the slide background image with detected spots, displayed
%               during processing (default: 0.1)
% outputs:
%   slide - 'slide' datastructure with detected objects, section outlines
%               (see documentation for datatypes - slide). by default, the
%               positions of objects in each scene are relative to scene
%               edges. Can be converted to locations in whole slide image
%               using the function: 'msproc_bf_setCZIImageOffsetsInSlide.m'
%%

if nargin<5; scenes = []; end
if nargin<6; displaySat = 0.1; end % percentage of pixels to saturate in display

slide.filepath = filepath;
slide.channels = channels;
slide.bg_channel = bg_channel;
slide.type = 'slide';

% added/modified 12/2019 for multi-resolution thumbs
%bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath);
if isfield(params(1),'bg_downsample')
    bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath,params(1).bg_downsample);
else
    bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath);
end


if isempty(scenes)
    scenes2process = [1:bfCZISceneReader.numScenes];
else
    scenes2process = scenes;
end

numPlanes = bfCZISceneReader.numPlanes;
numChannels =  bfCZISceneReader.numChannels;

for iScene = 1:length(scenes2process);
    %checkstop();
    disp(['Processing scene ',num2str(scenes2process(iScene))]);
    % get section outline from first zPlane
    if isfield(params(1),'invert')
        if params(1).invert
            disp('Inverting image!')
        end
        thumb = msproc_bf_mapSectionInCZIScene(bfCZISceneReader, scenes2process(iScene), bg_channel, params(1).bg_threshfactor, params(1).invert);
    else
        thumb = msproc_bf_mapSectionInCZIScene(bfCZISceneReader, scenes2process(iScene), bg_channel, params(1).bg_threshfactor);
    end
    % write section info to slide struct
    slide.sceneNumber(iScene) = scenes2process(iScene);
    slide.thumb(iScene) = thumb;
    
    if isfield(params(1),'unmix_mask')
        if params(1).unmix_mask
            mask = slide.thumb(iScene).section;
        else
            mask = [];
        end
    else
        mask = [];
    end
    % get objects in each z-plane
    for iPlane = 1:numPlanes
        disp(['Processing plane ',num2str(iPlane)]);
        % map structures
        if params(1).coloc == 0
            for ichannel = 1:size(channels,2)
                if size(params,2)>1;
                    subparams = params(ichannel);
                else
                    subparams = params;
                end
                objects.blobs(ichannel) = msproc_bf_mapBlobsInCZIScene(bfCZISceneReader, scenes2process(iScene), (iPlane-1)*numChannels + channels(:,ichannel), subparams, mask); %changed 11/28 to support channel unmixing
            end
        else
            objects.blobs = msproc_bf_mapBlobsInCZIScene(bfCZISceneReader, scenes2process(iScene), (iPlane-1)*numChannels + channels, params, mask);
        end
        
        % write plane objects to slide struct
        slide.zPlane(iPlane).objects(iScene) = objects;
        
        % display
        % get section outline parameters for displaying
        img_thumb = slide.thumb(iScene).img;
        thumb_factor = slide.thumb(iScene).downsampling;
        x = slide.thumb(iScene).section(:,1);
        y = slide.thumb(iScene).section(:,2);
        
        % get z-plane objects parameters for displaying
        centroid = slide.zPlane(iPlane).objects(iScene).blobs(1).centroid;

        % plot
        msproc_plotImageScale(img_thumb,displaySat);
        hold on;
        if (~isempty(centroid)); plot(centroid(:,1)/thumb_factor,centroid(:,2)/thumb_factor,'r.'); end
        if (~isempty(x) & ~isempty(y)); plot(x/thumb_factor,y/thumb_factor,'b.'); end
        hold off;
        pause(1);
    end
    
    % save slide file
    save('slidetemp.mat','slide','-v7.3');
    
end