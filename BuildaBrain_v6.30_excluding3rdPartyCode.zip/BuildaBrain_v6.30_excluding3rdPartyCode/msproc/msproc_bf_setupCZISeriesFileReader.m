function bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(filepath,bg_downsample)
%% setup reader object for accessing CZI multi-scene image using bioformats matlab package
% reader object contains information and links to access individual image
% planes from (multiscene), multichannel, multiplane, multi-resolution
% image files (e.g. Zeiss CZI format)
%
% INPUTS:
%           filepath - string containing file name or full directory path
%           to CZI multiscene file
% OUTPUTS:
%           bfCZISceneReader - reader object for accessing scenes in file
%               has fields:
%               r - bioformats reader object for corresponding image file
%               SceneSeriesInds - series indices of bioformat reader object corresponding to
%                   the full resolution images in pyramid images (0 indexed). Currently
%                   implemented for CZI multiscene files
%               thumbSeriesInds - series indices of bioformat reader object corresponding to
%                   the smallest resolution images in pyramid (0 indexed). Currently
%                   implemented for CZI multiscene files
%               sceneSize - vector containing number of pixels in each scene
%               numScenes - number of scenes in image file
%               numPlanes - number of planes in image file
%               numChannels - number of color channels in image file
%               
%
% J. Moore 7/18/2018
%%

if nargin<2 % added 12/2019 for multi-resolution thumbs
    bg_downsample = [];
end

r = bfGetReader(filepath);

numPlanes = r.getSizeZ;
numChannels = r.getSizeC;

[sceneSeriesInds thumbSeriesInds sizeall_all] = msproc_bf_mapCZISeries2Scene(r,bg_downsample);

bfCZISceneReader.r = r;
bfCZISceneReader.sceneSeriesInds = sceneSeriesInds;
bfCZISceneReader.thumbSeriesInds = thumbSeriesInds;
bfCZISceneReader.sceneSize = sizeall_all;
bfCZISceneReader.numScenes = length(sceneSeriesInds);
bfCZISceneReader.numPlanes = numPlanes;
bfCZISceneReader.numChannels = numChannels;