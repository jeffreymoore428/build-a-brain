function serialStruct = msproc_importSpotsFromFile(serialStruct,T)
% import spots from external file as additional spots channels
% use format from imageJ cell counter, resave as .csv file

if isempty(serialStruct)
    disp('BB error: Spots map file is required for spots to be added');
    return;
end

% UNTESTED, in development
disp('Import file must be a .csv file in table format with the following parameter names in first line: Type, Slice, X, Y ...');

if nargin<2
    [FileName,PathName,FilterIndex] = uigetfile('*.csv','Please select csv file');
    T = readtable([PathName,FileName]);
end

counterNumbers = T.Type;
counterSectionNums = T.Slice;
counterX = T.X;
counterY = T.Y;

% add to first plane only

newObjs = unique(counterNumbers);
numNewObjs = size(newObjs,1);

disp(['Adding ',num2str(numNewObjs),' new spot channels to spots map file...']);

numScenes = size(serialStruct.zPlane(1).objects,2);

for iScene = 1:numScenes
    %checkstop();
    numObjects = size(serialStruct.zPlane(1).objects(iScene).blobs,2);
    for iObj = 1:numNewObjs
        %get object locations in current scene
        posX = counterX(find(counterSectionNums == iScene & counterNumbers == newObjs(iObj)));
        posY = counterY(find(counterSectionNums == iScene & counterNumbers == newObjs(iObj)));
        if (~isempty(posX) & ~isempty(posY))
            counterSectionPositions = [posX posY];
        else
            counterSectionPositions = [];
        end
        % fill object locations
        % start with params from first object channel
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj) = serialStruct.zPlane(1).objects(iScene).blobs(1);
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).centroid = counterSectionPositions;
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).bsize = ones(size(counterSectionPositions,1),1);
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).CC = [];
        % set imgThresh params to [], parameters not used, leave dims field
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).imgThresh.intensity = [];
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).imgThresh.rawIntensity = [];
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).imgThresh.params = [];
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).imgThresh.meanIntensity = [];
        serialStruct.zPlane(1).objects(iScene).blobs(numObjects+iObj).imgThresh.thresh = [];
    end
end
disp('Spots added to map file!');
