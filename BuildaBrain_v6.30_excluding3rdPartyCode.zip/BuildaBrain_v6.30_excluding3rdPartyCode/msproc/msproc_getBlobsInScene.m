function [centroids dims bsize bintensity bintensityM bintensityALL] = msproc_getBlobsInScene(serialStruct,sceneNum,planeNum,blobNum,intensityFlag)

if nargin<3; planeNum = []; end;
if nargin<4; blobNum = []; end;
if nargin<5; intensityFlag = []; end

if isempty(planeNum); planeNum = 1; end
if isempty(blobNum); blobNum = 1; end
if isempty(intensityFlag); intensityFlag = 0; end

bintensity = []; bintensityM = []; bintensityALL = [];

centroids = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).centroid;
bsize = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).bsize';
dims = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).imgThresh(1).dims;

if intensityFlag
    idx = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).CC.bigInds;
    pixIdx = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).CC.PixelIdxList;
    
    nImgs = size(serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).imgThresh,2);
    for iImg = 1:nImgs
        intensity = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).imgThresh(iImg).intensity;
        intensityInds = serialStruct.zPlane(planeNum).objects(sceneNum).blobs(blobNum).imgThresh(iImg).inds;
        bintensityALL{iImg} = [];
        for iidx = 1:length(idx)
            blobInds = pixIdx{idx(iidx)};
            [C,ai,bi] = intersect(intensityInds,blobInds);
            blobIntensity = intensity(ai);
            bintensity{iImg}{iidx} = blobIntensity;
            bintensityM(iidx,iImg) = mean(blobIntensity);
            bintensityALL{iImg} = [bintensityALL{iImg} ; blobIntensity ];
        end
    end
end
    
    