function imgs = msproc_bf_getChannelImgs(bfCZISceneReader, sceneNum, channels, params, mask)

%   bfCZISceneReader - object containing a bioformats reader object for an image file and
%                       the associated series numbers for each scene. This
%                       object is produced by the function
%                       'msproc_bf_setupCZISeriesFileReader.m)
%   sceneNum - number of desired scene within CZI multiscene file
%   channels - list of channels in which to identify blobs (1 x N)
%                       For channel unmixing: if using image unmixing specify channels as a 2 x N
%                       matrix, where row 1 is the set of desired channels,
%                       and row 2 is the set of channels to subtract from
%                       the corresponding channel in row 1. Specify NaN in
%                       elements of row 2 where no unmixing is desired
%                       Example 1: channels = [2 3 4 ; 1 NaN NaN] will subtract
%                       channel 1 out from channel 2, and leave channels 3
%                       and 4 as is
%                       Example 2: channels = [2 3 4 ; 1 2 3] will subtract
%                       channel 1 out from channel 2, channel 2 out from channel 3, and
%                       channel 3 out from channel 4
%                       when doing channel subtraction, params.correctBG
%                       specifies whether to correct only for bleedthrough
%                       (0) or autofluorescence (1)
%   params -  params - datastructure containing the parameters for spot
%                       detection (see documentation for data types)
%   mask - for channel subtraction, subtract only in maasked region

if nargin<5
    mask = [];
end

numChanRows = size(channels,1);
numChans = size(channels,2);
for ichan = 1:numChans
    if numChanRows == 1 % no channel subtraction
        imgs(:,:,ichan) = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, channels(1,ichan));
    elseif numChanRows == 2 % with channel subtraction
        img_sig = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, channels(1,ichan));
        if isnan(channels(2,ichan))
            imgs(:,:,ichan) = img_sig;
        else
            img2subtract = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, channels(2,ichan));
            imgs(:,:,ichan) = unmix_channels(img_sig,img2subtract,params.correctBG,mask);
        end
    else
        error('BB error: channel format not supported')
    end
        
    % invert image if requested
    if isfield(params,'invert')
        if params.invert
            imgs(:,:,ichan) = img_invert(imgs(:,:,ichan));
        end
    end
end