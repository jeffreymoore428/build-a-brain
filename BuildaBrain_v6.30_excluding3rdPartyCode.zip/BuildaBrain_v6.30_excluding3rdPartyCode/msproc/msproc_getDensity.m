function densityImg = msproc_getDensity(dims,x,y, regionSize, ptweights)
% apply gaussian blur to 2D point process
% ouput:    densityImg - matrix of blurred intensity values over space of size dims
% inputs:   dims - [1 x 2] matrix of image size [height, width]
%           x - x values of points (integers indices between 1 and dims(2)
%           y - y values of points (integers indices between 1 and dims(1)
%           regionSize - width of gaussian smoothing kernel
%           ptweights (optional) - weight points unequally. By default, all
%           point weights = 1

if nargin<5
    ptweights = ones(size(x));
end

linearInd = sub2ind(dims, y, x);
img = zeros(dims);
for iind = 1:length(linearInd) % modified 3/5/19 to account for multiple points per pixel
    img(linearInd(iind)) = img(linearInd(iind))+ptweights(iind);
end
%h = fspecial('average', regionSize);
%densityImg = imfilter(img,h);
densityImg = imgaussfilt(img,regionSize);

