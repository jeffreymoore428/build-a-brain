function thumb = msproc_bf_mapSectionInCZIScene(bfCZISceneReader, sceneNum, channel, threshfactor, invert)

if nargin<4
    threshfactor = 1;
end

if nargin<5
    invert = [];
end

disp('Calculating section outline...');
img_thumb = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, channel,1);
if invert
    img_thumb = img_invert(img_thumb);
end
    
thumb_factor = sqrt( bfCZISceneReader.sceneSize(bfCZISceneReader.sceneSeriesInds(sceneNum)+1) / bfCZISceneReader.sceneSize(bfCZISceneReader.thumbSeriesInds(sceneNum)+1) );
[y_thumb x_thumb img_thumb_bin] = msproc_get_section_intensity(img_thumb, threshfactor);
y = y_thumb*thumb_factor;
x = x_thumb*thumb_factor;

% write thumb struct
thumb.img = img_thumb;
thumb.downsampling = thumb_factor;
thumb.bin = img_thumb_bin;
thumb.section = [x y];
thumb.threshfactor = threshfactor;