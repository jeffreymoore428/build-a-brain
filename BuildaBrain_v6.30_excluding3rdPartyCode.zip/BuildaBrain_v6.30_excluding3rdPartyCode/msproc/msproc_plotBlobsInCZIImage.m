function msproc_plotBlobsInCZIImage(slide,sceneNum,channelNum, planeNum, displaySat)

if nargin<4; planeNum = []; end
if nargin<5; displaySat = 0.5; end
if isempty(planeNum); planeNum = 1;end
colors = {'r';'b';'g';'m';'c';'y'};

bfCZISceneReader = msproc_bf_setupCZISeriesFileReader(slide.filepath);
numChannels = bfCZISceneReader.r.getSizeC;
img = msproc_bf_getCZIScene(bfCZISceneReader, sceneNum, (planeNum-1)*numChannels+channelNum, 0);

msproc_plotImageScale(img,displaySat)

objectNum = find([slide.sceneNumber] == sceneNum);
numObjects = size(slide.zPlane(planeNum).objects(objectNum).blobs,2);
for iObj = 1:numObjects
    if ~isempty(slide.zPlane(planeNum).objects(objectNum).blobs(iObj).centroid)
        bx = slide.zPlane(planeNum).objects(objectNum).blobs(iObj).centroid(:,1);
        by = slide.zPlane(planeNum).objects(objectNum).blobs(iObj).centroid(:,2);
    else
        bx = []; by = [];
    end
    hold on;
    plot(bx,by,'.','Color',colors{iObj});axis equal;
end
sx = slide.thumb(objectNum).section(:,1);
sy = slide.thumb(objectNum).section(:,2);
plot(sx,sy,'.','Color',[0.5 0.5 0.5]);
    