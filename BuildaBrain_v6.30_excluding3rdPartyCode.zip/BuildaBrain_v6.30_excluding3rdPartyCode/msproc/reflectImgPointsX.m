function rpoints = reflectImgPointsX(points,imgDims)

xax = imgDims(2)/2;
if ~isempty(points)
    rpoints(:,1) = ((points(:,1) - xax)*(-1) + xax);
    rpoints(:,2) = points(:,2);
else
    rpoints = points;
end