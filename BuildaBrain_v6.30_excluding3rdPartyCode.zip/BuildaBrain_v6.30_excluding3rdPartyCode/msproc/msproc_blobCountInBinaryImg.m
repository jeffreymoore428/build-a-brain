function [CC centroid bsize nblobs] = msproc_blobCountInBinaryImg(imgB,params)
%% identifies (contiguous) spots in binary image that are of the correct size range specified in the parameters file
% inputs:
%   imgB - single channel binary image of bright pixels
%   params - datastructure containing the parameters for spot detection
%               (see documentation for data types)
% outputs:
%   CC - conneced components datastructure (see MATLAB function
%   bwconncomp). Contains all connected components regardless of size
%   contains additional field:
%       biginds - indices in CC struct that are within the size range
%       specified in params

%%

CC = [];
centroid = [];
bsize = [];
nblobs = [];

% find connected components
disp('Identifying connected components...')
CC = bwconncomp(imgB);
%imgBlack = zeros(size(imgB));
%imgBouton = imgBlack;
numPixels = cellfun(@numel,CC.PixelIdxList);
blobArea = ((params.diameter/2)^2)*pi;
idx = find( numPixels>(blobArea*params.min_size) & numPixels<(blobArea*params.max_size) );
CC.bigInds = idx;

disp('Counting blobs...')
for iidx = 1:length(idx);
    %if mod(iidx,100)==0; disp([num2str(round(iidx/length(idx)*100)),'% complete...']); end % display progress
    %imgTest = imgBlack;
    %imgTest(CC.PixelIdxList{idx(iidx)})=1;
    %[y x] = find(imgTest); % find x-y- indices of pixels in current bouton
    [y x] = ind2sub(size(imgB),CC.PixelIdxList{idx(iidx)});
    centroid(iidx,:) = [mean(x) mean(y)]; %calculate centroid
    bsize(iidx) = length(x); % calculate size
    %imgBouton(CC.PixelIdxList{idx(iidx)}) = 1;
end

% get number of boutons
nboutons = size(centroid,1);


