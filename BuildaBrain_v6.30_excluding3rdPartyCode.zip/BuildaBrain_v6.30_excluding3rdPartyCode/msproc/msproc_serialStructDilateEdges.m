function serialStruct = msproc_serialStructDilateEdges(serialStruct,diskPixels,sectionNums)

if nargin<3
    sectionNums = serialStruct.sceneNumber;
end

for iScene = 1:size(serialStruct.thumb,2)
    if ~isfield(serialStruct.thumb(iScene),'dilation')
        serialStruct.thumb(iScene).dilation = [];
    end
end

numScenes = length(sectionNums);
for iScene = 1:numScenes
    %checkstop();
    disp(['Dilating section ',num2str(sectionNums(iScene)),'...']);
    %bin = serialStruct.thumb(sectionNums(iScene)).bin; % updated to 
    [m,n] = size(serialStruct.thumb(sectionNums(iScene)).bin);
    thumb_factor = serialStruct.thumb(sectionNums(iScene)).downsampling;
    xy = serialStruct.thumb(sectionNums(iScene)).section;
    x = xy(:,1);
    y = xy(:,2);
    bin = poly2mask(x/thumb_factor,y/thumb_factor,m,n);
    diskSize = round(max([abs(diskPixels)/thumb_factor 0]));
    se = strel('disk',diskSize);
    if diskPixels>0 && diskSize>0
        bind = imdilate(bin,se);
    elseif diskPixels<0 && diskSize>0
        bind = imerode(bin,se);
    else
        warning('BB warning: dilation too small, no change');
        bind = bin;
    end
    % recompute largest object
    CC = bwconncomp(bind);
    numPixels = cellfun(@numel,CC.PixelIdxList);
    largestind = find(numPixels==max(numPixels),1);
    imgSection = zeros(size(bind));
    imgSection(CC.PixelIdxList{largestind})=1;
    B = bwboundaries(imgSection);
    y_thumb = B{1}(:,1);
    x_thumb = B{1}(:,2);
    imgSectionBin = logical(imgSection);
    x = x_thumb*thumb_factor;
    y = y_thumb*thumb_factor;
    % update structure
    serialStruct.thumb(sectionNums(iScene)).bin = imgSectionBin;
    serialStruct.thumb(sectionNums(iScene)).section = [x y];
    % track all dilations
    actualDilation = sign(diskPixels)*diskSize*thumb_factor;
    serialStruct.thumb(sectionNums(iScene)).dilation = [serialStruct.thumb(iScene).dilation actualDilation];
end
    
    