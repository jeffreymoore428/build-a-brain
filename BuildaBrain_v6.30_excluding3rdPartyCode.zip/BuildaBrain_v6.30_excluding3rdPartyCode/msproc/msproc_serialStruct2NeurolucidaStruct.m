function [objStruct markerStruct] = msproc_serialStruct2NeurolucidaStruct(serialSections,cutInterval,um_per_pixel,zThickness,isOffset,sectionOutlineType)

% set default parameters
if nargin<2; cutInterval = 0; end;
if nargin<3; um_per_pixel = []; end; % if entered, this parameter overrides internal CZI scale factor
if nargin<4; zThickness = 0; end;
if nargin<5; isOffset = 1; end;
if nargin<6; sectionOutlineType = '"Contour Name 1"'; end

markerTypes = {'OpenUpTriangle' ; 'Asterisk' ; 'FilledStar' ; 'OpenDownTriangle' ; 'Dot' ; ...
    'OpenStar' ; 'FilledCircle' ; 'OpenCircle' ; 'FilledDiamond' ; 'OpenDiamond' ; ...
    'FilledUpTriangle' ; 'FilledDownTriangle' ; 'Cross' ; 'Plus' };
% increased marker types from 3 version 5.97

% all available types from: https://github.com/NeuralEnsemble/neuroConstruct
% private String[] shapes = new String[]{"Dot", "OpenStar", "FilledQuadStar", "CircleArrow", "OpenCircle",
% "DoubleCircle", "OpenQuadStar", "CircleCross", "Cross", "Circle1",
% "Flower3", "Plus", "Circle2", "Pinwheel", "OpenUpTriangle", "Circle3",
% "TexacoStar", "OpenDownTriangle", "Circle4", "ShadedStar", "OpenSquare",
% "Circle5", "SkiBasket", "Asterisk", "Circle6", "Clock", "OpenDiamond",
% "Circle7", "ThinArrow", "FilledStar", "Circle8", "ThickArrow", "FilledCircle",
% "Circle9", "SquareGunSight", "FilledUpTriangle", "Flower2", "GunSight",
% "FilledDownTriangle", "SnowFlake", "TriStar", "FilledSquare", "OpenFinial",
% "NinjaStar", "FilledDiamond", "FilledFinial", "KnightsCross", "Flower", "MalteseCross", "Splat"};

objStruct = [];
markerStruct = [];
% convert serial sections object to JM's Neurolucida Structure Format

if isempty(um_per_pixel)
   if isfield(serialSections,'scaleFactor') ;
        scaleFactor = serialSections.scaleFactor;
   else
       scaleFactor = 1;
   end
else
    scaleFactor = um_per_pixel;
    cutInterval = cutInterval/um_per_pixel;
end

if isfield(serialSections,'xbounds_pix');
    xshift_pix = serialSections.xbounds_pix(1);
    yshift_pix = serialSections.ybounds_pix(1);
else
    xshift_pix = 0;
    yshift_pix = 0;
end

% convert section outlines to JM's Neurolucida objStruct format
numScenes = length(serialSections.sceneNumber);
objStruct.name = sectionOutlineType;
for iScene = 1:numScenes
    sceneNum = serialSections.sceneNumber(iScene);
    objStruct.contour(iScene).name = sectionOutlineType;
    if isfield(serialSections.thumb(iScene),'offset_pix') & isOffset;
        offset = serialSections.thumb(iScene).offset_pix;
    else
        offset = [0 0];
    end
    xypoints = serialSections.thumb(iScene).section + ...
        repmat(offset,size(serialSections.thumb(iScene).section,1),1);
    zpoints = ones(size(xypoints,1),1)*(sceneNum-1)*cutInterval;
    objStruct.contour(iScene).points = [xypoints zpoints];
    objStruct.contour(iScene).sections = ones(size(xypoints,1),1)*sceneNum;
    objStruct.contour(iScene).ptLines = [];
end

% convert points to JM's Neurolucida markerStruct format
numPlanes = size(serialSections.zPlane,2);
for iPlane = 1:numPlanes
    numObjects = size(serialSections.zPlane(iPlane).objects,2);
    for iObj = 1:numObjects
        numBlobs = size(serialSections.zPlane(iPlane).objects(iObj).blobs,2);
        for iBlob = 1:numBlobs
            sceneNum = serialSections.sceneNumber(iObj);
            if isfield(serialSections.thumb(iObj),'offset_pix') & isOffset;
                offset = serialSections.thumb(iObj).offset_pix;
            else
                offset = [0 0];
            end
            if ~isempty(serialSections.zPlane(iPlane).objects(iObj).blobs(iBlob).centroid)
                xypoints = serialSections.zPlane(iPlane).objects(iObj).blobs(iBlob).centroid + ...
                    repmat(offset,size(serialSections.zPlane(iPlane).objects(iObj).blobs(iBlob).centroid,1),1);
            else
                xypoints = [];
            end
            zpoints = ones(size(xypoints,1),1)*(sceneNum-1)*cutInterval + (iPlane-1)*zThickness;
            markerStruct(iBlob).type = markerTypes{iBlob};
            if ~isfield(markerStruct(iBlob),'points')
                markerStruct(iBlob).points = [xypoints zpoints];
                markerStruct(iBlob).sections = ones(size(xypoints,1),1)*sceneNum;
            else
                currentPoints = markerStruct(iBlob).points;
                currentSections = markerStruct(iBlob).sections;
                markerStruct(iBlob).points = [currentPoints ; [xypoints zpoints] ];
                markerStruct(iBlob).sections = [currentSections ; ones(size(xypoints,1),1)*sceneNum];
            end
        end
    end
end

for iScene = 1:numScenes
    origPoints = objStruct.contour(iScene).points;
    if ~isempty(origPoints)
        formattedPoints = [(origPoints(:,1)-xshift_pix) (origPoints(:,2)-yshift_pix)*-1 origPoints(:,3) ] * scaleFactor ; 
        objStruct.contour(iScene).points =  formattedPoints;
    end
end
    
for iBlob = 1:numBlobs
    origPoints = markerStruct(iBlob).points;
    if ~isempty(origPoints)
        formattedPoints = [(origPoints(:,1)-xshift_pix) (origPoints(:,2)-yshift_pix)*-1 origPoints(:,3) ] * scaleFactor ; 
        markerStruct(iBlob).points = formattedPoints;
    end
end




