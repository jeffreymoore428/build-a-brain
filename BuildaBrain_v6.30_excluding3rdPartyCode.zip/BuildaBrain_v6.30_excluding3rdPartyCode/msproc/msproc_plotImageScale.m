function msproc_plotImageScale(img,displaySat,R)

if nargin<2; displaySat = 0.5; end % percentage of pixels to saturate in display
if nargin<3; R = imref2d(size(img)); end

imgClass = class(img);
whitethresh = prctile(mat2list(img),100-displaySat);

%% old
%img_sat = eval(['(img.*',imgClass,'((img<=whitethresh))) + (whitethresh*',imgClass,'((img>whitethresh))) ;']);
%imagesc( R.XWorldLimits, R.YWorldLimits, img_sat );axis equal;colormap gray;

% add panels
% hFig = gcf;
% hIm = imagesc( R.XWorldLimits, R.YWorldLimits, img_sat );axis equal;colormap gray;
% hSP = imscrollpanel(hFig,hIm);
% api = iptgetapi(hSP);
% api.setMagnification(1) % 1X = 100%
% imoverview(hIm)

%% make interactive axes
iptsetpref('ImtoolStartWithOverview',true)
fh = imgcf; close(fh); % close any open image

% non-deployable for use in matlab only
%ih = imtool(img,[0 whitethresh]);

% deployable for compiler
hFig = figure;
hIm = imshow(img,[0 whitethresh]);
hSP = imscrollpanel(hFig,hIm);
imoverview(hIm);
figure(hFig);
