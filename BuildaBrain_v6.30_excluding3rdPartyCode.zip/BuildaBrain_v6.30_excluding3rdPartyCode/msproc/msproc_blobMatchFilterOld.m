function [imgB imgThresh_intensity imgThresh_inds params] = msproc_blobMatchFilterOld(img, params, mask)
% counts blobs in an image by high pass filtering, thresholding (OBSOLETE)
% OUTPUTS:
%   nboutons - (scalar) total number of boutons in image
%   centroid - x-y pair of centroid coordinates of each detected spot
%   bsize - area of each detected spot (pixels)
% INPUTS:
%   img - matrix of image pixels (1 chan, 2d)
%   params - (optional) struct with fields:
%       bouton_diameter (avg bouton diameter in pixels)
%       min_size (min diameter as fraction of avg bouton area)
%       bouton_thresh - threshold brighness value
%   mask - (optional) binary image matrix must be of same dimensions as 
%       image (length x height) containing ones in pixels to be counted and
%       zeros in pixels to ignore
%
%   UPDATES
%       added edge effect correction - JM 1/30/18

% set default settings if not provided  by user
if nargin<3;mask = [];end

% calculate img stats
img_lin = mat2list(img);

% set filter size
filt_length = round(params.diameter*4);
filt_length_half = ceil(filt_length/2);
%filt_length_half = 0; %no correction for edge effect

% remove edge effects
imgBorder = ones(size(img)+2*filt_length_half)*round(mean(mean(img)));
imgBorder(filt_length_half+1:end-filt_length_half,filt_length_half+1:end-filt_length_half)=img;
numpixels_border = prod(size(imgBorder));

disp('Processing image...');
gfilt = fspecial('gaussian',params.diameter*filt_length,params.diameter); % get blurred image
imgF = imfilter(imgBorder,gfilt);
%gfiltt = fspecialgauss(params.bouton_diameter*filt_length,params.bouton_diameter);
%imgFt = convn(imgBorder,gfilt,'same');

%imgSharp = imgGray-imgF; % subtract blurred img
imgSharp = imgBorder - imgF;
imgSharp_lin = reshape(imgSharp,numpixels_border,1); % get histogram of high pass filtered image

% threshold image
%imgB = imgSharp>params.bouton_thresh;
% downsample distribution of pixel intensities for computing threshold
% (memory constraint)
maxlength = 1e7;
dwn = 1;
if length(imgSharp_lin)>maxlength
    dwn = floor(length(imgSharp_lin)/maxlength);
end
thresh = mean(imgSharp_lin(1:dwn:end))+params.thresh_rel*std(imgSharp_lin(1:dwn:end));


imgB_border = imgSharp>thresh;
imgB = imgB_border(filt_length_half+1:end-filt_length_half,filt_length_half+1:end-filt_length_half);

% get intensities of values above threshold
imgThresh_inds = find(imgB);
imgSharp_noborder = imgSharp(filt_length_half+1:end-filt_length_half,filt_length_half+1:end-filt_length_half);
imgSharp_gt_thresh = imgSharp_noborder.*imgB;
imgThresh_intensity = imgSharp_gt_thresh(imgThresh_inds);

% mask image by user-provided mask
if ~isempty(mask)
    imgB = imgB.*mask;
end