function serialStruct = msproc_serialStructRemoveEdgePts(serialStruct,filterNumStds, distFromEdgeThresh)

if nargin<2
    filterNumStds = 2;
end
if nargin<3
    distFromEdgeThresh = [];
end


numPlanes = size(serialStruct.zPlane,2);
numScenes = size(serialStruct.zPlane(1).objects,2);

for iScene = 1:numScenes
    numObjects = size(serialStruct.zPlane(1).objects(iScene).blobs,2);
    sx = serialStruct.thumb(iScene).section(:,1);
    sy = serialStruct.thumb(iScene).section(:,2);
    for iObj = 1:numObjects
        %get object locations
        bx = []; by = [];
        for iPlane = 1:numPlanes
            %checkstop();
            % get threshold distance from edges to cut off
            if isempty(distFromEdgeThresh)
                params = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).imgThresh(1).params;
                filtersize = max([params.hp_sigma_broad,params.hp_sigma_sharp]);
                if isempty(filtersize);filtersize = 0;end
                distFromEdgeThresh = filterNumStds * filtersize;
            end
            btemp = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid;
            bsizetemp = serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).bsize; % added v5.95
            if ~isempty(btemp)
                for iPt = 1:size(btemp,1)
                    % get closest 2 edge points to each point
                    dist2edge = sqrt( (btemp(iPt,1) - sx).^2 + (btemp(iPt,2) - sy).^2 );
                    [dist2edgeSort dist2edgeSortInds] = sort(dist2edge,'ascend');
                    closestEdgePt1 = [sx(dist2edgeSortInds(1)) sy(dist2edgeSortInds(1))];
                    closestEdgePt2 = [sx(dist2edgeSortInds(2)) sy(dist2edgeSortInds(2))];
                    % get shortest distance to line between 2 closest points
                    shortestDist(iPt) = getPtDist2LineSeg(btemp(iPt,:),closestEdgePt1,closestEdgePt2);
                end
                in = shortestDist>distFromEdgeThresh;
                binx = btemp(find(in),1);
                biny = btemp(find(in),2);
                bsizein = bsizetemp(find(in)); % added v5.95
            else
                binx = []; biny = []; in = [];
                bsizein = []; % error in v5.95, added v5.96
            end
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).allCentroids = btemp;
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroidsInBounds = in;
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).centroid = [binx biny];
            serialStruct.zPlane(iPlane).objects(iScene).blobs(iObj).bsize = bsizein; % added v5.95
            clear shortestDist;
        end
    end
end

