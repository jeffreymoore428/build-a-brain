% Build-a-Brain Workshop
% software for automated and supervised processing and organiztion of slide
% scanner imaging data
%
% J. Moore 7/20/2018
%
% version 1.0 - first version
% support for:   
%                - loading slide scanner images/data into Matlab using bioformats package
%                - support multi-scene, multi-plane images
%                - spot detection within serial sections
%                - serial secion organization, 3D alignment
%                - read in data from Nicrobrightfield Neurolucida (.xml or .ASC)
%                - output data to Neurolucida format (.ASC)
%                - high dynamic range images: combining multiple exposures to > 16 bit range
%                - spot co-localization
%
% version 1.1
% added support for:
%                - large scale spatial filtering with heuristic downsampling for computation speed
%                - returns filtered AND raw pixel values of candidate spots
% version 1.2
%               - interactive tool to reset section boundaries
%               - allows for absolute intensity thresholding
% version 2.0
%               - allows for different thresholds for each channel in
%               colocalization mode channel independent mode (note: for
%               indepedent channels, can have separate parameter sets
%               except for the 'invert' and 'coloc' fields, of which only
%               the first value will be read
%               - improved algorithm to calculate section boundaries
%               - improved handling of manual ssection boundary tracing
%               - added comments to function definitions 
%               - 
% version 3.0 - added gui, 3d visualization tools, fixed multi-contour bugs
% version 4.0 - added dilation/erosion tools, updated layout for testing
% object detection in single image
% version 4.1 - fixed erosion bug
% version 4.2 - 11/1/18 changed
% 'neurolucida_list_all_sectionNums_with_outline' to respect original
% section order (warning: untested in most cases, maybe have to revert)
% version 4.4 - added support for channel unmixing (beta)
% v5.95 added support for blob size carried through outline point removal