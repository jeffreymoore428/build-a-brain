function T = qupath_tsvList2ImageJ(fileList,prefix,saveFile)

% file list in csv format:

% column 1 - file full path name
% column 2 - section number
% column 3 - marker names in desired order

if nargin<1
    [file,path] = uigetfile('*.csv','Select database of Qupath points .tsv files');
    fileList = fullfile(path,file);
end

if nargin<2
    prefix = 'PointsList_';
end
outputFile = [prefix,fileList];

if nargin<3
    saveFile = 0;
end

C = readcell(fileList,'Delimiter',',');
nSects = size(C,1);

typeCounter = 0;
for iSect = 1:nSects
    if ~ismissing(C{iSect,3})
        typeCounter = typeCounter+1;
        typeInfo(typeCounter).name = C{iSect,3};
    end
end

T = table;
X = [];
Y = [];
Type = [];
Slice = [];
for iSect = 1:nSects
    sectionNum = C{iSect,2};
    fileName = C{iSect,1};
    CPts = readcell(fileName,'FileType','text','Delimiter','\t');
    if size(CPts,1)>1
        Xsect = [CPts{2:end,1}]';
        Ysect = [CPts{2:end,2}]';
        SliceSect = ones(size(Xsect))*sectionNum;
        TypeSect = zeros(size(Xsect));
        CTypesSect = {CPts{2:end,3}}';
        for iType = 1:typeCounter
            isType = strcmp(CTypesSect,typeInfo(iType).name);
            TypeSect(find(isType)) = iType;
        end
    else
        Xsect = [];
        YSect = [];
        TypeSect = [];
        SliceSect = [];
    end
    X = [X ; Xsect(TypeSect>0)];
    Y = [Y ; Ysect(TypeSect>0)];
    Type = [Type ; TypeSect(TypeSect>0)];
    Slice = [Slice ; SliceSect(TypeSect>0)];
end
T.X = X;
T.Y = Y;
T.Type = Type;
T.Slice = Slice;

if saveFile
    writetable(T,outputFile);
end


