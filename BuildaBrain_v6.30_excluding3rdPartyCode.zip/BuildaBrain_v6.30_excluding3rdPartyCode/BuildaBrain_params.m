params.hp_sigma_broad = []; % broad highpass filter, permits downsampling, set to [] to bypass
params.dwnsamp_broad = []; % downsampling factor for broad filter (recommended values: ~1-10% of hp_sigma_broad)
params.hp_sigma_sharp = 25; % sharp highpass filter, no downsampling, set to [] to bypass
params.diameter = 25; % approxiamte diameter of object
params.min_size = 0.5; % min blob size(times avg area)
params.max_size = 4; % max blob size(times avg area)
params.thresh_rel = 8; % threshold brightness - std's above mean of filtered img. optional if coloc = 1: vector of thresholds for each channel i.e. [6 8 4];
params.absThresh = []; % overrides relative threshold, set to [] to bypass. optional if coloc = 1: vector of thresholds for each channel i.e. [6 8 4];
params.bg_threshfactor = 1.0; % scaling factor to identify section outline
params.coloc = 0; % flag to map channels independently or intersectionally
params.save_pixels = 0; % flag whether to save out spot detected pixel values, for post-hoc threshold adjustment, not recommended if objects occupy the majority of image
params.invert = 0; % invert
params.correctBG = 1; % only used when using channel unmixing. if correctBG = 0, only correct bleedthrough. If correctBG = 1 (default), also correct for autofluorescence / background in subtraction channel (see ' msproc_bf_mapBlobsInCZIScene.m')
params.unmix_mask = 1;
%params.bg_downsample = 1; % downsampling factor for background image in pyramid files only; 0 - full resolution, 1-maximum downsampling. Uses channel 1 value only. Downsampling is approximately by a factor of 2^(N*bg_downsample), where 2^N is the most downsampled pyramid level

%note: 
%if coloc = 0, apply different params values to different channels using
%the following format
%
%params1 = params;
%params(1) = params1;
%params(2) = params1;
%params(2).thresh_rel = 10;