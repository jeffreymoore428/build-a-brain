% sample script to batch process slides for bouton or cell counting
% output for each slideis saved as a file in working directory

% the preset example processes 3 brains sequentially 

% load counting parameters, stored in default_paramer_sets.m
default_parameter_sets;
cell_params_10x.invert = 1;
cell_params_10x.hp_sigma_sharp = 15; 
cell_params_10x.diameter = 35;% avg blob diameter (pixels)
cell_params_10x.thresh_rel = 8;
cell_params_10x.min_size = 0.5;% min blob size(times avg area)

% set data directories to process
filedir = 'E:\scans\jm_20180413_pdyn_sst_ai65_pup5_antiRFP\zeiss\10x\';


% set data files to process

filelist = {    '2018_06_26__3063.czi'; ...
                '2018_06_26__3064.czi'; ...
                };
                 
                    
% set channels containing objects (channel numbers are specified by the order acquired)
channels = 1;

% set background channel
background_channel = 1;

% process all files
msproc_bf_mapBlobsInCZIBrainScan(filedir,filelist,channels, background_channel, cell_params_10x);

