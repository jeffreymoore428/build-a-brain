%list of additional functions
% slide = msproc_bf_manualResetCZISectionBoundary(slidefilepath,sectionNum)
%           interactively reset the section boundary for a single scene

% slide = msproc_bf_manualDrawCZISectionBoundary(slidefilepath,sectionNum)
%           interactively reset the section boundary for a single scene by
%           drawing directly

% msproc_plotBlobsInCZIImage(slide,sceneNum,channelNum, planeNum)
%           plot spot detection objects for a single scene on original image

% msproc_plotBlobsInSerialStruct(serialStruct, sceneNums)
%           plot all spot detection objects specified in a vector of
%           sceneNums

% msproc_plotBlobsOnSlide(slide, sceneNums)
%           plot all spot detection objects specified in a vector of
%           sceneNums. If slide positions have been mapped previously with
%           function "msproc_bf_setCZIImageOffsetsInSlide.m", plot will be
%           in on-slide coordinates

% densityImgThumbMask = msproc_plotBlobDensity(serialStruct,sceneNum,filterSize)
%           plots plot spot detection objectdensity for a single scene with
%           smooting filter of 'filterSize' pixels, returns density image

% serialStruct = msproc_raiseBlobThreshold(serialStruct,sizeThresholdLow,sizeThresholdHigh,intensityThreshold)
%           restrict spot detection with stricter detection threshold parameters post-hoc

% newSerialStruct = msproc_reorder_sections(serialStruct, newSections)
%           re-order sections in serialStruct with section IDS in vector
%           newSections, using indices in serialStruct.sceneNumber

% %[objStructMerge, markerStructMerge] = neurolucida_align_merge_2_structures(fixedObjStruct,fixedMarkerStruct, ...
%                                                                             movingObjStruct,movingMarkerStruct, ...
%                                                                             applyTform,manualCorrect,...
%                                                                             fixedContourName,movingContourName)...
% merge 2 files of neurolucida tracing data

%[colocID1_rd colocID2_rd minDistColoc minDist] = colocolize_markers(points1,points2,thresh);
%           compute colocalization of markers for 2 sets of points and
%           maximum distance threshold to consider colocalized

% note - functions that operate on serialStruct objects also operate on
% slide objects, but not necessarily vice versa
% 
