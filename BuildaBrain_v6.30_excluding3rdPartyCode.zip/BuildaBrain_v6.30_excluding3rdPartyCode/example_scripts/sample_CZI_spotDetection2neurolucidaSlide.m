% sample script for outputting spot detection data to neurolucida data
% file, aligned with original section positions in slide

%used for manually tracing internal contours relative to detected spots

interSectionDistance = 120; % user specified distance between sections, in microns

% create neurolucida data file containing detected spots in single slide, together with image for tracing section boundaries
load('slide_2018_07_28__3253.czi.mat');
slide = msproc_bf_setCZIImageOffsetsInSlide(slide); % get image positions in slide and scaling from CZI metadata
[objStruct markerStruct] = msproc_serialStruct2NeurolucidaStruct(slide,interSectionDistance); % format for neurolucida, scaled in um
neurolucidaASC_writefile(slide.filepath,objStruct,markerStruct,interSectionDistance); % write neurolucida file