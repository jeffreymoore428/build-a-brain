interSectionDistance = 120; %user specified distance between sections
scaleB = 0.325;
scaleC = 0.65;
manualCorrect = 1; % flag to manually review and edit 3d alignment

% combine slides for alignment 
filedirB = 'D:\temp analysis\buildabrain_output\'; % directory of spot detection output files
filelistB = {'slide_2018_07_28__3253.czi.mat'; ... % list of slides to combine
            'slide_2018_07_28__3254.czi.mat'; ...
            'slide_2018_07_28__3255.czi.mat'; ...
            'slide_2018_07_28__3256.czi.mat'};

filedirC = 'D:\temp analysis\buildabrain_output\'; % directory of spot detection output files
filelistC = {'slide_2018_07_27__3240.czi.mat'; ... % list of slides to combine
            'slide_2018_07_27__3241.czi.mat'; ...
            'slide_2018_07_27__3242.czi.mat'; ...
            'slide_2018_07_27__3243.czi.mat'};
scenes2reflectX = [4 6 8 9 12 13 14 15 19 20 22 25 29 30 32 34 38 41 42 46 49 51 53 56 58 59 60 61 62 63 66 67]; % select scenes to reflect
scenes2resetBoundaries = [24 26 27 28 35];
ssB = msproc_slide2serialStruct(filedirB,filelistB); % create serialSections object containing data from all slides
ssC = msproc_slide2serialStruct(filedirC,filelistC); % create serialSections object containing data from all slides
ssB = msproc_bf_manualRestrictCZISectionBoundary(ssB,scenes2resetBoundaries);
ssC = msproc_bf_manualRestrictCZISectionBoundary(ssC,scenes2resetBoundaries);
%serialStruct = msproc_serialStructBoundaries2Contours(serialStruct); % obsolete - ensures section boundaries are single contour
ssB = msproc_reflectCoordsInSerialStruct(ssB, [], scenes2reflectX); % reflect flipped sections
ssC = msproc_reflectCoordsInSerialStruct(ssC, [], scenes2reflectX); % reflect flipped sections
ssB = msproc_serialStructRemoveUnboundedPts(ssB); % clean data by removing points located outside of section boundaries
ssC = msproc_serialStructRemoveUnboundedPts(ssC); % clean data by removing points located outside of section boundaries
[osB msB] = msproc_serialStruct2NeurolucidaStruct(ssB,interSectionDistance,scaleB); % format for neurolucida, scaled in um if on slide
[osC msC] = msproc_serialStruct2NeurolucidaStruct(ssC,interSectionDistance,scaleC); % format for neurolucida, scaled in um if on slide
[osM, msM] = neurolucida_align_merge_2_structures(osB,msB,osC,msC,1,manualCorrect);
[osMA, msMA] = neurolucida_align_objects(osM,msM); % supervised serial section alignment - follow interactive instructions
[osMAJ msMAJ] = neurolucida_jitter_z_vals(osMA,msMA,interSectionDistance);
neurolucida_plot_objects(osMAJ,msMAJ,{'k:','w:'},{'b.';'r.'});