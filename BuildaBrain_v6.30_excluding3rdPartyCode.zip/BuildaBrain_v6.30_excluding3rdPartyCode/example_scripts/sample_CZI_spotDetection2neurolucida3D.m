% sample script for outputting spot detection data to neurolucida data
% file, supervisedalignment in 3D

interSectionDistance = 120; %user specified distance between sections
scale = 0.325;
manualCorrect = 1; % flag to manually review and edit 3d alignment

% combine slides for alignment 
filedir = 'E:\temp analysis\buildabrain_output\'; % directory of spot detection output files
filelist = {'slide_2018_07_28__3257.czi.mat'; ... % list of slides to combine
            'slide_2018_07_28__3258.czi.mat'; ...
            'slide_2018_07_28__3259.czi.mat'; ...
            'slide_2018_07_28__3260.czi.mat'};
%scenes2reflectX = [4 6 8 9 12 13 14 15 19 20 22 25 29 30 32 34 38 41 42 46 49 51 53 56 58 59 60 61 62 63 66 67]; % select scenes to reflect, 53-56
scenes2reflectX = [1 3 8 9 10 13 14 15 19 20 24 25 27 28 30 31 32 33 35 36 37 39 42 44 46 47 49 52 57 58 63 68 70];
serialStruct = msproc_slide2serialStruct(filedir,filelist); % create serialSections object containing data from all slides
%serialStruct = msproc_serialStructBoundaries2Contours(serialStruct); % obsolete - ensures section boundaries are single contour
serialStruct = msproc_reflectCoordsInSerialStruct(serialStruct, [], scenes2reflectX); % reflect flipped sections
serialStruct = msproc_serialStructRemoveUnboundedPts(serialStruct); % clean data by removing points located outside of section boundaries
[objStruct markerStruct] = msproc_serialStruct2NeurolucidaStruct(serialStruct,interSectionDistance,scale); % format for neurolucida, scaled in um if on slide
[objStructAligned markerStructAligned] = neurolucida_align_objects(objStruct,markerStruct); % supervised serial section alignment - follow interactive instructions
[objStructJitter, markerStructJitter] = neurolucida_jitter_z_vals(objStructAligned,markerStructAligned,interSectionDistance);
neurolucida_plot_objects(objStructJitter, markerStructJitter,{'b:'},{'r.'});
neurolucidaASC_writefile([filedir,'brainAligned_',filelist{1}],objStructAligned,markerStructAligned,interSectionDistance); % write whole-brain aligned neurolucida file