% sample script to batch process slides for bouton or cell counting
% output for each slideis saved as a file in working directory

% the preset example processes 3 brains sequentially 

% load counting parameters, stored in default_paramer_sets.m
default_parameter_sets;

% set data directories to process
filedir1 = 'E:\scans\JM_20180618_PdynSstAi65_scAAVFlexGFPSypHA\';
filedir2 = 'D:\scans\unsorted\';
filedir3 = 'E:\scans\unsorted\';
filedir4 = 'D:\scans\unsorted\';

% set data files to process
filelist1 = {   '2018_07_11__3179.czi'; ...
                '2018_07_11__3180.czi'; ...
                '2018_07_11__3181.czi'; ...
                '2018_07_11__3182.czi'; ...
                };

filelist2 = {    '2018_07_28__3253.czi'; ...
                 '2018_07_28__3254.czi'; ...
                 '2018_07_28__3255.czi'; ...
                 '2018_07_28__3256.czi'; ...
                };
            
filelist3 =    { '2018_07_28__3257.czi'; ...
                 '2018_07_28__3258.czi'; ...
                 '2018_07_28__3259.czi'; ...
                 '2018_07_28__3260.czi'; ...
                };
            
filelist4 =    { '2018_08_22__3492.czi'; ...
                 '2018_08_22__3493.czi'; ...
                 '2018_08_22__3494-1.czi'; ...
                 '2018_08_22__3495.czi'; ...
                 '2018_08_22__3496.czi';...
                };


% set channels containing objects (channel numbers are specified by the order acquired)
channels1 = [2 3 4];
channels2 = [3 4 5];
channels3 = [3 4 5];
%channels4 = [3 4 5];
channels4 = [3 4 5];

% set background channel
background_channel1 = 3;
background_channel2 = 1;
background_channel3 = 1;
background_channel4 = 1;

% process all files
%msproc_bf_mapBlobsInCZIBrainScan(filedir1,filelist1,channels1, background_channel1, bouton_params_20x);
msproc_bf_mapBlobsInCZIBrainScan(filedir2,filelist2,channels2, background_channel2, bouton_params_20x);
%msproc_bf_mapBlobsInCZIBrainScan(filedir3,filelist3,channels3, background_channel3, bouton_params_20x);
%msproc_bf_mapBlobsInCZIBrainScan(filedir4,filelist4,channels4, background_channel4, bouton_params_20x);


