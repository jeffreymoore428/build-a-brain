function serialMeasures = serialStruct_measurePts(serialSections,serialMeasures,name,measureType,scale,sectionNums,displaySat)

if nargin<2; serialMeasures = [];end
if nargin<3; name = []; end
if nargin<4; measureType = 'line'; end
if nargin<5; scale = 1; end
if nargin<6; sectionNums = []; end
if nargin<7; displaySat = 0.1; end % percentage of pixels to saturate in display

if strcmp(measureType,'contour')
    contourType = 'freehand';
end

if strcmp(measureType,'polyContour')
    measureType = 'contour';
    contourType = 'polygon';
end

if isempty(sectionNums)
    sectionNums = 1:size(serialSections.thumb,2);
end

numMeasures = size(serialMeasures,2);
serialMeasures(numMeasures+1).scale = scale;
serialMeasures(numMeasures+1).type = measureType;

numSections = size(serialSections.thumb,2);
for iSection = 1:length(sectionNums)
    %img = serialSections.thumb(sectionNums(iSection)).img;
    dwn = serialSections.thumb(sectionNums(iSection)).downsampling;
    while 1
        checkstop();
        if isfield(serialSections.thumb(sectionNums(iSection)),'R')
            R = serialSections.thumb(sectionNums(iSection)).R;
        else
            R = [];
        end
        %msproc_plotImageScale(img,displaySat,R); % clear copy of image
        serialStruct_plotMeasureImage(serialSections,serialMeasures,name,sectionNums(iSection),displaySat);
        disp(['Section ',num2str(sectionNums(iSection))]);
        
        % plot dots on section
        colors = {'r';'b';'g';'m';'c';'y';'k'};
        objectNum = find([serialSections.sceneNumber] == sectionNums(iSection));
        for iPlane = 1:size(serialSections.zPlane,2) % check dimensions
            numObjects = size(serialSections.zPlane(iPlane).objects(objectNum).blobs,2);
            for iObj = 1:numObjects
                if ~isempty(serialSections.zPlane(iPlane).objects(objectNum).blobs(iObj).centroid)
                    bx = serialSections.zPlane(iPlane).objects(objectNum).blobs(iObj).centroid(:,1);
                    by = serialSections.zPlane(iPlane).objects(objectNum).blobs(iObj).centroid(:,2);
                    bxdwn = bx/dwn;
                    bydwn = by/dwn;
                    if isfield(serialSections.thumb(sectionNums(iSection)),'Yflip')
                        if serialSections.thumb(sectionNums(iSection)).Yflip == 1
                            bxdwn = bxdwn + serialSections.thumb(sectionNums(iSection)).YflipOffset/dwn; 
                        end
                    end
                else
                    bxdwn = []; 
                    bydwn = [];
                end
                if ~isempty(R)
                    bxdwn = bxdwn - R.XWorldLimits(1);
                    bydwn = bydwn - R.YWorldLimits(1);
                end
                hold on;
                plot(bxdwn,bydwn,'.','Color',colors{iObj});axis equal;
            end
        end
        % end code to plot dots on section

        try
            if strcmp(measureType,'line')
                disp('Click line. Drag points or object to change position...');
                h = imline;
                disp('Double click on object to complete');
                wait(h);
                pts = h.getPosition;
                
            elseif strcmp(measureType,'contour');
                
                if strcmp(contourType,'freehand')
                    disp('Click and drag mouse to draw contour. Release to complete...');
                    h = imfreehand;
                    pts = h.getPosition; % get points instantly
                
                elseif strcmp(contourType,'polygon');
                    disp('Click points to draw contour. Right click to complete...');
                    h = impoly;
                    pts = h.getPosition; % get points instantly
                end
     
            elseif strcmp(measureType,'points');
                
                fhpt = imgcf; % handle to current iamge figure
                xpts = []; ypts = []; % initialize points
                %curXlim = xlim; curYlim = ylim; % get current axis limits
                
                disp('Click on points. Close figure when done...');
                while isvalid(fhpt) % break out of loop if figure section is closed
                    try
                        %xlim(curXlim); ylim(curYlim) % set axis limits, in case figure is zoomed
                        h = impoint;
                        pt = h.getPosition;
                        xpts = [xpts ; pt(1)]; ypts = [ypts ; pt(2)]; % add point
                        %curXlim = xlim; curYlim = ylim;
                    end
                end
                
                clear h;
                pts = [xpts ypts];
                if isempty(pts)
                    pts = NaN; % no points = same case as if measure rejected
                end
                
            end

            isRejected = input('Accept measurement? yes-return, skip-0, re-draw-1, change saturation-2: ');
            imgPts = pts;
            % upsample contours so one point per pixel
            if strcmp(measureType,'contour')
                mask = createMask(h);
                [y x imgSectionBin] = msproc_get_section_intensity(mask,1,0);
                pts = [x y];
            end
            if ~isempty(R) & ~isempty(pts)
                pts = pts + repmat([R.XWorldLimits(1) , R.YWorldLimits(1)],size(pts,1),1); % add offsets to pts
            end
            pts = pts*dwn; % scale to original image size
            % matched flip orientation
            if isfield(serialSections.thumb(sectionNums(iSection)),'Yflip')
                if serialSections.thumb(sectionNums(iSection)).Yflip == 1
                    pts(:,1) = pts(:,1) - serialSections.thumb(sectionNums(iSection)).YflipOffset; % translate points if flipped
                end
            end
        catch
           disp('Error in measurement');
           isRejected = 1;
        end
        if isempty(isRejected) || ~isRejected
            break;
        elseif isRejected==2
            newSat = input('Please enter new image saturation level (% pixels saturated, 0-100 (default: 0.1)): ');
            if isnumeric(newSat) && newSat>=0 && newSat<=100
                displaySat = newSat;
            else
                disp('Invalid pixel saturation level, reverting.')
            end
        else
            disp('Measure declined, please redraw measurement or Ctrl-C to exit and start over:')
        end
    end
    if isempty(isRejected) && ~any(any(isnan(pts)))
        serialMeasures(numMeasures+1).shape(iSection).pts = reflectImgPointsY(pts,[0 0]);
        serialMeasures(numMeasures+1).shape(iSection).imgPts = imgPts;
    else
        serialMeasures(numMeasures+1).shape(iSection).pts = NaN;
        serialMeasures(numMeasures+1).shape(iSection).imgPts = NaN;
    end
    serialMeasures(numMeasures+1).shape(iSection).section = sectionNums(iSection);
end

% if no name, prompt for name
while isempty(name)
    name = input('Enter measurement name: ','s');
    if isempty(name)
        disp('Name must be specified, please try again.');
    end
end
serialMeasures(numMeasures+1).name = name;
disp('Done defining measurements!');
try
    fh = imgcf;
    close(fh);
end
