function serialSectionsTransform = serialStruct_reflectYAxis(serialSections,flipy);

serialSectionsTransform = serialSections;
serialSectionsTransform.isFlipped = 1;

numSections = size(serialSections.thumb,2);
for iSection = 1:numSections;
    if isfield(serialSectionsTransform.thumb(iSection),'Yflip')
        if isempty(serialSectionsTransform.thumb(iSection).Yflip) % initiate to 0
            serialSectionsTransform.thumb(iSection).Yflip = 0; % flag to indicate orientation as original (0) or flipped (1)
        end
    else
        serialSectionsTransform.thumb(iSection).Yflip = 0; % initiate to 0
    end
    if ~isempty(intersect(iSection,flipy))
        s = serialSections.thumb(iSection).section;
        sp = reflectImgPointsX(s,[0 0]);
        serialSectionsTransform.thumb(iSection).section = sp;
        img = serialSections.thumb(iSection).img;
        bin = serialSections.thumb(iSection).bin;
        imgr = fliplr(img);
        binr = fliplr(bin);
        serialSectionsTransform.thumb(iSection).img = imgr;
        serialSectionsTransform.thumb(iSection).bin = binr;
        serialSectionsTransform.thumb(iSection).Yflip = mod(serialSectionsTransform.thumb(iSection).Yflip+1,2); % 1 if flipped, 0 if native
        dwnFactor = serialSectionsTransform.thumb(iSection).downsampling;
        if isfield(serialSectionsTransform.thumb(iSection),'R')
            serialSectionsTransform.thumb(iSection).R.XWorldLimits = fliplr(-serialSectionsTransform.thumb(iSection).R.XWorldLimits);
            YflipOffset = 0;
        else
            YflipOffset = size(serialSectionsTransform.thumb(iSection).img,2)*dwnFactor;
        end
        serialSectionsTransform.thumb(iSection).YflipOffset = YflipOffset;
    end
end

for iPlane = 1:size(serialSections.zPlane,2)
    for iObj = 1:size(serialSections.zPlane(iPlane).objects,2)
        if ~isempty(intersect(iObj,flipy))
            for iBlob = 1:size(serialSections.zPlane(iPlane).objects(iObj).blobs,2);
                c = serialSections.zPlane(iPlane).objects(iObj).blobs(iBlob).centroid;
                cp = reflectImgPointsX(c,[0 0]);
                serialSectionsTransform.zPlane(iPlane).objects(iObj).blobs(iBlob).centroid = cp;
            end
        end
    end
end