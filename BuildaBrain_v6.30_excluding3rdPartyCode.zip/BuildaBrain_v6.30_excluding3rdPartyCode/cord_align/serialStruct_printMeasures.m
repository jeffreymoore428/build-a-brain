function serialStruct_printMeasures(serialMeasures);

for iMeasure = 1:size(serialMeasures,2)
    disp(['Name: ',serialMeasures(iMeasure).name]);
    disp(['Type: ',serialMeasures(iMeasure).type]);
    disp(['Sections: ',num2str([serialMeasures(iMeasure).shape.section])]);
end

