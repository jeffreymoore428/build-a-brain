function serialStruct_plotMeasure(serialSections, serialMeasures, name, sections)

figure;
msproc_plotBlobsInSerialStruct(serialSections, sections);

% allSections = [];
% for iMeasure = 1:size(serialMeasures,2)
%     if strcmp(serialMeasures(iMeasure).name,name)
%         sections = [serialMeasures(iMeasure).shape.section];
%         allSections = [allSections sections];
%     end
% end
% allUniqueSections = sort(unique(allSections));
% 
% numTiles = ceil(sqrt(length(allUniqueSections)));

numTiles = ceil(sqrt(length(sections)));

for iSection = 1:length(sections)
    curSection = sections(iSection);
    for iMeasure = 1:size(serialMeasures,2)
        for iShape = 1:size(serialMeasures(iMeasure).shape,2)
            if serialMeasures(iMeasure).shape(iShape).section == curSection
                subplot(numTiles,numTiles,iSection); xlabel(['Section ',num2str(curSection)]);
                type = serialMeasures(iMeasure).type;
                pts = serialMeasures(iMeasure).shape(iShape).pts;
                hold on;
                if ~any(any(isnan(pts)))
                    if strcmp(serialMeasures(iMeasure).name,name)
                        dotColor = [0 1 0];
                        lineWidth = 3;
                    else
                        dotColor = [0.5 0.5 0.5];
                        lineWidth = 1;
                    end
                    if strcmp(type,'points')
                        plot(pts(:,1),pts(:,2),'.','Color',dotColor);
                    else
                        plot(pts(:,1),pts(:,2),'Color',dotColor,'LineWidth',lineWidth);
                    end
                end
            end
        end
    end
end