function varargout = ConstructaCord(varargin)
% CONSTRUCTACORD MATLAB code for ConstructaCord.fig
%      CONSTRUCTACORD, by itself, creates a new CONSTRUCTACORD or raises the existing
%      singleton*.
%
%      H = CONSTRUCTACORD returns the handle to a new CONSTRUCTACORD or the handle to
%      the existing singleton*.
%
%      CONSTRUCTACORD('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONSTRUCTACORD.M with the given input arguments.
%
%      CONSTRUCTACORD('Property','Value',...) creates a new CONSTRUCTACORD or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ConstructaCord_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ConstructaCord_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ConstructaCord

% Last Modified by GUIDE v2.5 24-Feb-2020 13:44:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ConstructaCord_OpeningFcn, ...
                   'gui_OutputFcn',  @ConstructaCord_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ConstructaCord is made visible.
function ConstructaCord_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ConstructaCord (see VARARGIN)

% Choose default command line output for ConstructaCord
handles.output = hObject;

% Update handles structure
imshow('logo.png');
guidata(hObject, handles);

% UIWAIT makes ConstructaCord wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ConstructaCord_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function inFilename_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function inFilename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in browse.
function browse_Callback(hObject, eventdata, handles)
disp('Loading file...');
[FileName,PathName,FilterIndex] = uigetfile('*.mat','Please select a map file');
handles.inFilename_val = [PathName,FileName];
set(handles.inFilename,'String',handles.inFilename_val);
S=load(handles.inFilename_val);
fs = fieldnames(S);
handles.serialSections = eval(['S(1).',fs{1}]);
handles.outFilename_val = ['mac_',FileName];
set(handles.outFilename,'String',handles.outFilename_val);
handles.measuresFile_val = ['measures_',FileName];
% load corresponding measures file if available
if exist([PathName,handles.measuresFile_val],'file')
    SM=load([PathName,handles.measuresFile_val]);
    fsm = fieldnames(SM);
    handles.serialMeasures = eval(['SM(1).',fsm{1}]);
else
    handles.serialMeasures = [];
end
guidata(hObject,handles);
disp('File loaded!');

% --- Executes on button press in setAxes.
function setAxes_Callback(hObject, eventdata, handles)
halign = figure;
[o y dwnsamp sm] = serialStruct_manualSetAxis(handles.serialSections,handles.serialMeasures,handles.secs2flip_val);
handles.serialMeasures = sm;
imgTform = getTformFromAxes(o,y,dwnsamp);
handles.serialSections = serialStruct_rigidTransform(handles.serialSections,imgTform,handles.secs2flip_val);
numMeasures = size(handles.serialMeasures,2);
guidata(hObject,handles);
close(halign);

% --- Executes on button press in plot.
function plot_Callback(hObject, eventdata, handles)
h = figure;
msproc_plotBlobsInSerialStruct(handles.serialSections,handles.secs2plot_val);
% if isempty(handles.secs2plot_val)
%     numSections = size(handles.serialSections.thumb,2);
% else
%     numSections = length(handles.secs2plot_val);
% end
% 
% for iSection = 1:numSections;
%     ha = h.Children(iSection);
%     ha.reset;
%     axis(ha,'equal');
% end

function secs2plot_Callback(hObject, eventdata, handles)
handles.secs2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2plot_CreateFcn(hObject, eventdata, handles)
handles.secs2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function secs2flip_Callback(hObject, eventdata, handles)
handles.secs2flip_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2flip_CreateFcn(hObject, eventdata, handles)
handles.secs2flip_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in flip.
function flip_Callback(hObject, eventdata, handles)
disp('Flipping sections...');
handles.serialSections = serialStruct_reflectYAxis(handles.serialSections,handles.secs2flip_val);
guidata(hObject,handles);
disp('Sections flipped!');

function outFilename_Callback(hObject, eventdata, handles)
handles.outFilename_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function outFilename_CreateFcn(hObject, eventdata, handles)
handles.outFilename_val = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
disp('Saving...');
serialSections = handles.serialSections;
serialMeasures = handles.serialMeasures;
save([handles.outFilename_val],'serialSections','-v7.3');
save(['measures_',handles.outFilename_val],'serialMeasures','-v7.3');
[objStruct,markerStruct] = msproc_serialStruct2NeurolucidaStruct(serialSections,handles.interval_val,handles.scale_val);
objStruct = neurolucida_addMeasure2NeurolucidaObjects(objStruct,serialSections,serialMeasures,handles.interval_val,handles.scale_val);
markerStruct = neurolucida_addMeasure2NeurolucidaMarkers(markerStruct,serialSections,serialMeasures,handles.interval_val,handles.scale_val);
neurolucidaASC_writefile([handles.outFilename_val],objStruct,markerStruct,handles.interval_val);
disp('Origin aligned contours and measurements saved!');


% --- Executes on button press in measure.
function measure_Callback(hObject, eventdata, handles)
if isempty(handles.scale_val)
    error('BB error: Please set scale');
end
%figure;
measureType = 'line';
handles.serialMeasures = serialStruct_measurePts(handles.serialSections,handles.serialMeasures,handles.measureName,measureType,handles.scale_val,handles.secs2measure_val);
handles.serialMeasures = serialStruct_squeezeMeasures(handles.serialMeasures,handles.measureName);
guidata(hObject,handles);



function scale_Callback(hObject, eventdata, handles)
handles.scale_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function scale_CreateFcn(hObject, eventdata, handles)
handles.scale_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function interval_Callback(hObject, eventdata, handles)
handles.interval_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function interval_CreateFcn(hObject, eventdata, handles)
handles.interval_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in mkContour.
function mkContour_Callback(hObject, eventdata, handles)
if isempty(handles.scale_val)
    error('BB error: Please set scale');
end
%figure;
measureType = 'contour';
handles.serialMeasures = serialStruct_measurePts(handles.serialSections,handles.serialMeasures,handles.measureName,measureType,handles.scale_val,handles.secs2measure_val);
handles.serialMeasures = serialStruct_squeezeMeasures(handles.serialMeasures,handles.measureName);
guidata(hObject,handles);
disp('Contours built!');

function secs2measure_Callback(hObject, eventdata, handles)
handles.secs2measure_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2measure_CreateFcn(hObject, eventdata, handles)
handles.secs2measure_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function measureName_edit_Callback(hObject, eventdata, handles)
handles.measureName = get(hObject,'String');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function measureName_edit_CreateFcn(hObject, eventdata, handles)
handles.measureName = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PrintMeasures.
function PrintMeasures_Callback(hObject, eventdata, handles)
serialStruct_printMeasures(handles.serialMeasures);


% --- Executes on button press in RemoveMeasures.
function RemoveMeasures_Callback(hObject, eventdata, handles)
handles.serialMeasures = serialStruct_removeMeasureFromSections(handles.serialMeasures,handles.measureName,handles.secs2measure_val);
guidata(hObject,handles);
disp('Measures removed!');


% --- Executes on button press in plotMeasure.
function plotMeasure_Callback(hObject, eventdata, handles)
serialStruct_plotMeasure(handles.serialSections,handles.serialMeasures,handles.measureName,handles.secs2measure_val);


% --- Executes on button press in plotWithImage.
function plotWithImage_Callback(hObject, eventdata, handles)
serialStruct_plotMeasureImage(handles.serialSections,handles.serialMeasures,handles.measureName,handles.secs2measure_val);


% --- Executes on button press in addPts.
function addPts_Callback(hObject, eventdata, handles)
if isempty(handles.scale_val)
    error('BB error: Please set scale');
end
%figure;
measureType = 'points';
handles.serialMeasures = serialStruct_measurePts(handles.serialSections,handles.serialMeasures,handles.measureName,measureType,handles.scale_val,handles.secs2measure_val);
handles.serialMeasures = serialStruct_squeezeMeasures(handles.serialMeasures,handles.measureName);
guidata(hObject,handles);
disp('Points built!');


% --- Executes on button press in mkPolyContour.
function mkPolyContour_Callback(hObject, eventdata, handles)
if isempty(handles.scale_val)
    error('BB error: Please set scale');
end
%figure;
measureType = 'polyContour';
handles.serialMeasures = serialStruct_measurePts(handles.serialSections,handles.serialMeasures,handles.measureName,measureType,handles.scale_val,handles.secs2measure_val);
handles.serialMeasures = serialStruct_squeezeMeasures(handles.serialMeasures,handles.measureName);
guidata(hObject,handles);
disp('Contours built!');
