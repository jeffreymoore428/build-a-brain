function imgTform = getTformFromAxes(o,y,dwnsamp)

for i=1:size(o,1)
    d(i) = sqrt(sum((y(i,:)-o(i,:)).^2));
    imgTform(i).tform = fitgeotrans([o(i,:); y(i,:)],[0 0 ; 0 -d(i)],'NonreflectiveSimilarity');
    imgTform(i).tformpts = fitgeotrans([o(i,:); y(i,:)]*dwnsamp(i),[0 0 ; 0 -d(i)]*dwnsamp(i),'NonreflectiveSimilarity');
end
