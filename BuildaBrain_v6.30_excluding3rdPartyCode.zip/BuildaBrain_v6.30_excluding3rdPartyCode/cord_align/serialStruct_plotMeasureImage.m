function serialStruct_plotMeasureImage(serialSections,serialMeasures,measureName,sectionNums,displaySat)
% plot serial measures on image
if nargin<5
    displaySat = 0.1;
end

for iSection = 1:length(sectionNums)
    % plot first section in specified handle (uses newly created figure if
    % not specified)
    img = serialSections.thumb(sectionNums(iSection)).img;
    if isfield(serialSections.thumb(sectionNums(iSection)),'R') && ~isempty(serialSections.thumb(sectionNums(iSection)).R)
        R = serialSections.thumb(sectionNums(iSection)).R;
        msproc_plotImageScale(img,displaySat,R);
        title(['Section ',num2str(sectionNums(iSection))]);
    else
        R = [];
        msproc_plotImageScale(img,displaySat);
        title(['Section ',num2str(sectionNums(iSection))]);
    end
    
    hold on;
    curSection = sectionNums(iSection);
    for iMeasure = 1:size(serialMeasures,2)
        if isfield(serialMeasures(iMeasure),'name')
            for iShape = 1:size(serialMeasures(iMeasure).shape,2)
                if serialMeasures(iMeasure).shape(iShape).section == curSection
                    type = serialMeasures(iMeasure).type;
                    if isfield(serialMeasures(iMeasure).shape(iShape),'imgPts')
                        imgPts = serialMeasures(iMeasure).shape(iShape).imgPts;
                    else
                        imgPts = NaN;
                    end
                    if ~any(any(isnan(imgPts)))
                        if strcmp(serialMeasures(iMeasure).name,measureName)
                            dotColor = [0 1 0]; %green if current measure
                        else
                            dotColor = [0.5 0.5 0.5]; % gray if previous emasure
                        end
                        if strcmp(type,'points')
                            plot([imgPts(:,1) ; imgPts(1,1)] , [imgPts(:,2) ; imgPts(1,2)],'.','Color',dotColor);
                        else
                            plot([imgPts(:,1) ; imgPts(1,1)] , [imgPts(:,2) ; imgPts(1,2)],'Color',dotColor,'LineWidth',1);
                        end
                    end
                end
            end
        end
    end
end