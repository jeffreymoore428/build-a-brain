function newSerialMeasures = serialStruct_squeezeMeasures(serialMeasures,name)
% combine all measures of same name into a single field

newSerialMeasures = [];
currentMeasure = 0;
for iMeasure = 1:size(serialMeasures,2)
    if ~strcmp(serialMeasures(iMeasure).name,name) % if not measure of interest, just add to output
        currentMeasure = currentMeasure + 1;
        newSerialMeasures(currentMeasure).name = serialMeasures(iMeasure).name;
        newSerialMeasures(currentMeasure).type = serialMeasures(iMeasure).type;
        newSerialMeasures(currentMeasure).scale = serialMeasures(iMeasure).scale;
        newSerialMeasures(currentMeasure).shape = serialMeasures(iMeasure).shape;
    else % if name of interest
        if isfield(newSerialMeasures,'name') && any(strcmp({newSerialMeasures.name},name)) % if already has a measure with same name
            ind = find(strcmp({newSerialMeasures.name},name)); % get index in the output struct for the already named measure
            % check consistency
            if ~strcmp(newSerialMeasures(ind).type,serialMeasures(iMeasure).type)
                error('BB error: cannot combine shapes of different types')
            end
            if ~(newSerialMeasures(ind).scale==serialMeasures(iMeasure).scale)
                error('BB error: cannot combine shapes of different scales')
            end
            % append shapes
            lastShape = size(newSerialMeasures(ind).shape,2); % get number of shapes
            for iShape = 1:size(serialMeasures(iMeasure).shape,2) % put current shapes at end of list
                newSerialMeasures(ind).shape(lastShape+iShape) = serialMeasures(iMeasure).shape(iShape);
            end
        else % if doesn't have a measure with same name, add to output
            currentMeasure = currentMeasure + 1;
            newSerialMeasures(currentMeasure).name = serialMeasures(iMeasure).name;
            newSerialMeasures(currentMeasure).type = serialMeasures(iMeasure).type;
            newSerialMeasures(currentMeasure).scale = serialMeasures(iMeasure).scale;
            newSerialMeasures(currentMeasure).shape = serialMeasures(iMeasure).shape;
        end
    end
end
            
        