function [o y dwnsamp serialMeasures] = serialStruct_manualSetAxis(serialSections,serialMeasures,sectionNums,displaySat)

if isfield(serialSections,'isTransformed')
    warning('BB warning: sections already transformed!');
end

if nargin<2; serialMeasures = []; end;
if nargin<3; sectionNums = []; end;
if nargin<4; displaySat = 0.1; end % percentage of pixels to saturate in display

numMeasures = size(serialMeasures,2);
serialMeasures(numMeasures+1).name = 'y_axis thumbs';
serialMeasures(numMeasures+1).type = 'line';
serialMeasures(numMeasures+1).scale = NaN;

if isempty(sectionNums)
    sectionNums = 1:size(serialSections.thumb,2);
end

numSections = length(sectionNums);
for iSection = 1:numSections;
    checkstop();
    img = serialSections.thumb(sectionNums(iSection)).img;
    dwn = serialSections.thumb(sectionNums(iSection)).downsampling;
    if isfield(serialSections.thumb(sectionNums(iSection)),'R')
        msproc_plotImageScale(img,displaySat,serialSections.thumb(sectionNums(iSection)).R);
    else
        msproc_plotImageScale(img,displaySat);
    end
    disp(['Section ',num2str(iSection),'/',num2str(numSections)]);
    disp('Click origin...')
    ho = impoint;
    disp('Click to define y axis...')
    hy = impoint;
    % get points
    o(iSection,:) = ho.getPosition;
    y(iSection,:) = hy.getPosition;
    dwnsamp(iSection) = dwn;
    serialMeasures(numMeasures+1).shape(iSection).pts = [o(iSection,:) ; y(iSection,:)];
    serialMeasures(numMeasures+1).shape(iSection).section = sectionNums(iSection);
end
disp('Done defining axes!');

