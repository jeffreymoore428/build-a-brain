function xyp = movePoints2Ref(xyPoints,phi,x0,y0);

[t r] = cart2pol(xyPoints(:,1)-x0,xyPoints(:,2)-y0);
tp = t-phi;
[xp yp] = pol2cart(tp,r);

xyp = [xp , yp];