function serialSectionsTransform = serialStruct_rigidTransform(serialSections,imgTform,sectionNums);

if nargin<3; sectionNums = []; end

serialSectionsTransform = serialSections;
serialSectionsTransform.isTransformed = 1;
serialSectionsTransform = msproc_bf_stripCZIImageOffsets(serialSectionsTransform); % strip any slide positioning offsets if they're there

if isempty(sectionNums)
    sectionNums = 1:size(serialSections.thumb,2);
end

numSections = length(sectionNums);
for iSection = 1:numSections;
    s = serialSections.thumb(sectionNums(iSection)).section;
    sp = transformPointsForward(imgTform(iSection).tformpts, s);
    serialSectionsTransform.thumb(sectionNums(iSection)).section = sp;
    % transform images
    img = serialSections.thumb(sectionNums(iSection)).img;
    bin = serialSections.thumb(sectionNums(iSection)).bin;
    if isfield(serialSections.thumb(sectionNums(iSection)),'R')
        Rorig = serialSections.thumb(sectionNums(iSection)).R;
    else
        Rorig = imref2d(size(img));
    end
    [imgr,Rnew] = imwarp(img,Rorig,imgTform(iSection).tform);
    [binr] = imwarp(bin,Rorig,imgTform(iSection).tform);
    serialSectionsTransform.thumb(sectionNums(iSection)).img = imgr;
    serialSectionsTransform.thumb(sectionNums(iSection)).bin = binr;
    serialSectionsTransform.thumb(sectionNums(iSection)).R = Rnew;
end

for iPlane = 1:size(serialSections.zPlane,2)
    for iObj = 1:numSections
        for iBlob = 1:size(serialSections.zPlane(iPlane).objects(sectionNums(iObj)).blobs,2);
            c = serialSections.zPlane(iPlane).objects(sectionNums(iObj)).blobs(iBlob).centroid;
            if ~isempty(c)
                cp = transformPointsForward(imgTform(iObj).tformpts, c);
                serialSectionsTransform.zPlane(iPlane).objects(sectionNums(iObj)).blobs(iBlob).centroid = cp;
            end
        end
    end
end