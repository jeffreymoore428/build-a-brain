function outputSerialMeasures = serialStruct_removeMeasureFromSections(serialMeasures,name,sections);
% remove contours / measure from sections
% if empty, remove measure altogether


% copy serialMeasures struct into newSerialMeasures except for excluded
% sections
newSerialMeasures = [];
for iMeasure = 1:size(serialMeasures,2)
    if strcmp(serialMeasures(iMeasure).name,name)
        newSerialMeasures(iMeasure).name = serialMeasures(iMeasure).name;
        newSerialMeasures(iMeasure).type = serialMeasures(iMeasure).type;
        newSerialMeasures(iMeasure).scale = serialMeasures(iMeasure).scale;
        allSections = [serialMeasures(iMeasure).shape.section];
        lastShape = 1;
        for iShape=1:length(allSections)
            if isempty(intersect(sections,serialMeasures(iMeasure).shape(iShape).section))
                newSerialMeasures(iMeasure).shape(lastShape).section = serialMeasures(iMeasure).shape(iShape).section; % add shape if sections don't match
                newSerialMeasures(iMeasure).shape(lastShape).pts = serialMeasures(iMeasure).shape(iShape).pts;
                newSerialMeasures(iMeasure).shape(lastShape).imgPts = serialMeasures(iMeasure).shape(iShape).imgPts;
                lastShape = lastShape + 1;
            end
        end
    else
        newSerialMeasures(iMeasure).name = serialMeasures(iMeasure).name;
        newSerialMeasures(iMeasure).type = serialMeasures(iMeasure).type;
        newSerialMeasures(iMeasure).scale = serialMeasures(iMeasure).scale;
        newSerialMeasures(iMeasure).shape = serialMeasures(iMeasure).shape;
    end
end

% copy newSerialMeasures struct into outputSerialMeasures except for
% empty measures
outputSerialMeasures = [];
lastMeasure = 1;
for iMeasure = 1:size(newSerialMeasures,2)
    if isfield(newSerialMeasures(iMeasure),'shape') && ~isempty(newSerialMeasures(iMeasure).shape);
        outputSerialMeasures(lastMeasure).name = newSerialMeasures(iMeasure).name;
        outputSerialMeasures(lastMeasure).type = newSerialMeasures(iMeasure).type;
        outputSerialMeasures(lastMeasure).scale = newSerialMeasures(iMeasure).scale;
        outputSerialMeasures(lastMeasure).shape = newSerialMeasures(iMeasure).shape;
        lastMeasure = lastMeasure + 1;
    end
end
