function umimg = unmix_channels(img,bg_img, correctBG, mask)
% input - img matrix, bg_img matrix to subtract
% output- unmixed img matrix

if nargin<3
    correctBG = [];
end

if isempty(correctBG)
    correctBG = 0;
end

if nargin<4
    mask = [];
end

%% updates
% updated 11/6/2016 9PM JM - made faster, minor bug fixes
% updated 11/21/2018 JM - operate on matrices rather than tifs
% 7/6/21 added masking

% squeeze pixel values into one-dimensional arrays for analysis
imgG_list = reshape(img,prod(size(img)),1);
imgB_list = reshape(bg_img,prod(size(bg_img)),1);

% take only ROI pixels
if mask
    maskBin = logical(poly2mask(mask(:,1),mask(:,2),size(img,1),size(img,2)));
    imgMask_list = reshape(maskBin,prod(size(maskBin)),1);
    imgG_list = imgG_list(imgMask_list);
    imgB_list = imgB_list(imgMask_list);
end


%% minimum value fit to subtract offset
%nbins = 50;
%B_bins = linspace(double(min(imgB_list)),double(max(imgB_list)),nbins); % create evenly spaced bins of bg pixel vals

nbins = 20;
Blimits = [10,90];
Bminlim = prctile(imgB_list,Blimits(1));
Bmaxlim = prctile(imgB_list,Blimits(2));
B_bins = linspace(double(Bminlim),double(Bmaxlim),nbins); % use interquartile range of intensity values

B_bins_inds = discretize(imgB_list,B_bins); % place bg pixels in bins

% find minimum image pixel per bg pixels bin
G_min_per_B_bin = []; B_full_bins = [];
for i=1:max(B_bins_inds)
    % find minimum G value in each bin of B pixels 
    minG = min(imgG_list(find(B_bins_inds==i)));
    if ~isempty(minG)
        B_full_bins = [B_full_bins ; B_bins(i)];
        G_min_per_B_bin = [G_min_per_B_bin ; minG ];
    end
end
if correctBG
    %B = double([ones(size(imgB_list)) imgB_list])\double(imgG_list);
    r = NaN;
    B(1) = 0; % do not subtract offset
    B(2) = double([imgB_list])\double(imgG_list); % constrain fit through origin
else
    % linear regression on minimum G values per bin
    % plot
    fh = figure; 
    plot(B_full_bins,G_min_per_B_bin,'.');
    title(['Bleedthrough estimate for image']);
    xlabel('Pixel intensity (LSB)'); ylabel('Bleedthrough estimate (LSB)');axis equal;
    pause(1);
    B = double([ones(size(B_full_bins)) B_full_bins])\double(G_min_per_B_bin);
    r = corr(B_full_bins,double(G_min_per_B_bin));
end

offset = B(1);
scale_factor = B(2);

% only subtract offset if <0 (conservative)
if offset>0;
    offset = 0;
end

% print offset and scale factor
offset
scale_factor
r2 = r.^2

% estimate bleedthrough 
bleed_est = offset+scale_factor*double(bg_img);

% subtract estimated bleedthrough
img_demix = double(img) - bleed_est;

%% plot for debugging
% set doplot = 1 to plot

doplot = 0;

if doplot == 1
    figure;
    hold on;
    plot(imgB_list,imgG_list,'g.');
    plot(B_full_bins,G_min_per_B_bin,'b.');
    plot(B_full_bins,B(1)+B(2)*B_full_bins,'r');
    xlabel('background pixels');
    ylabel('input pixels');
    legend('input pixels','min value per bin','fit');
    pause(1);
end


%% format as image 

% reformat adjusted channel to positive integer
class_img = class(img);
umimg = eval([char(class_img),'(img_demix)']);

