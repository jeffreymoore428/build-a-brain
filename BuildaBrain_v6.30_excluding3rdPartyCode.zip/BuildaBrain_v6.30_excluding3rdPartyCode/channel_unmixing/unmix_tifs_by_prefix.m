function unmix_tif_by_prefix(filename_prefix,im_chan,bg_chan)

allfiles = dir; % list all filenames in directory as struct
allfilenames = {allfiles.name}; %write filenames to cell array
imginds = cellfun(@(x) ~isempty(strfind(x,filename_prefix)),allfilenames); % find indices of images with prefix
image_list = {allfilenames{imginds}}; % write prefix-only images to cell array

% demix images in image_list array
for iimg = 1:length(image_list)
    disp(['Processing image #',num2str(iimg)]);
    unmix_tif(image_list{iimg},im_chan,bg_chan);
end

disp('Done ... yay!');