image_list = {
                'GFP16.tif';
                'GFP16.tif';
                'GFP16.tif';
                'GFP16.tif';
                'GFP16.tif';
                };
            
bg_list = {
                'CFP16.tif';
                'CFP16.tif';
                'CFP16.tif';
                'CFP16.tif';
                'CFP16.tif';
                };

if length(image_list) ~= length(bg_list)
    error('uh oh ... length of image and background image lists not same');
end

for iimg = 1:length(image_list)
    disp(['Processing image #',num2str(iimg)]);
    unmix_tif_GB_separate_input_channels(image_list{iimg},bg_list{iimg});
end

disp('Done ... yay!');