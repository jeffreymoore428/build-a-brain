filenameASC = 'proc_mac_contours_serialSections_Stitch_A01_G002_Scene_1.tif_9_files.mat.ASC';
filenameRS = ['RS_',filenameASC];
rotation = [1 0 0 ; 0 0 1 ; 0 1 0];
orig_section_interval = 300;
resection_interval = 50;

RSparams.shape_parameter = 0;
RSparams.keepZ = 0;
RSparams.define_boundary = 1;
RSparams.dilation_factor = 0.1;

[objStruct markerStruct] = neurolucidaASC2mat(filenameASC); % load reconstruction
[objStructJ, markerStructJ] = neurolucida_jitter_z_vals(objStruct,markerStruct,orig_section_interval);
[objStructR,markerStructR] = neurolucida_rotate(objStructJ,markerStructJ,rotation);
[objStructRS,markerStructRS] = neurolucida_resection(objStructR,markerStructR,orig_section_interval,resection_interval,RSparams);
figure; neurolucida_plot_objects(objStructRS,markerStructRS);
neurolucidaASC_writefile(filenameRS,objStructRS,markerStructRS,resection_interval,resection_interval);

figure; neurolucida_plot_objects(objStructR,markerStructR);
[objStructSlab,markerStructSlab] = neurolucida_reslice(objStructR,markerStructR,[-100 100],orig_section_interval,RSparams)
figure; neurolucida_plot_objects(objStructSlab2,markerStructSlab2);