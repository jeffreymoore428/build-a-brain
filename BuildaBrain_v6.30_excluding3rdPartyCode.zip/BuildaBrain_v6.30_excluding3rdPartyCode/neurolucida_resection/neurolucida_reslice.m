function [objStructNew,markerStructNew] = neurolucida_reslice(objStruct,markerStruct,zlimits,origThickness,params)

%zlimits
%origThickness
% rotate points in markeStruct and objStruct
if nargin<4
    params = [];
end
if isempty(params)
    params.shape_parameter = 0;
    params.keepZ = 0;
    params.define_boundary = 1;
    params.dilation_factor = 0.1;
end
disp('BB Warning: Resectioning assumes at most 1 contour of each type per section');

numMarkers = size(markerStruct,2);
numObjects = size(objStruct,2);

objStructNew = [];
markerStructNew = [];

% remove points in sections that have designated contour
for iMarker = 1:numMarkers
    keepInds = markerStruct(iMarker).points(:,3)>zlimits(1) & markerStruct(iMarker).points(:,3)<=zlimits(2);
    markerStructNew(iMarker).type = markerStruct(iMarker).type;
    markerStructNew(iMarker).points = markerStruct(iMarker).points(keepInds,:);
    markerStructNew(iMarker).sections = ones(sum(keepInds),1);
    markerStruct(iMarker).sections = markerStruct(iMarker).sections(keepInds);
    %markerStructNew(iMarker).ptLines = markerStruct(iMarker).ptLines(keepInds);
    markerStructNew(iMarker).ptLines = [];
    if ~params.keepZ
        markerStructNew(iMarker).points(:,3) = 0;
    else
        markerStructNew(iMarker).points(:,3) = markerStructNew(iMarker).points(:,3)-mean(zlimits)+diff(zlimits)/2;
    end
end

for iObj = 1:numObjects
    numContours = size(objStruct(iObj).contour,2);
    allContourPts = [];
    allContourPtLines = [];
    allContourPtsOrigSects = [];
    % get allpoints of type contour
    for jCont = 1:numContours
        keepInds = objStruct(iObj).contour(jCont).points(:,3)>zlimits(1) & objStruct(iObj).contour(jCont).points(:,3)<zlimits(2);
        if ~isempty(keepInds)
            allContourPts = [allContourPts ; objStruct(iObj).contour(jCont).points(keepInds,:)];
            %allContourPtLines = [allContourPtLines , objStruct(iObj).contour(jCont).ptLines(keepInds)];
            allContourPtLines = [];
            allContourPtsOrigSects = [allContourPtsOrigSects ; objStruct(iObj).contour(jCont).sections(keepInds)];
        end
    end
    if ~isempty(allContourPts)
        if params.define_boundary
            fitContour = neurolucida_fit_contour_to_pts(allContourPts,allContourPtsOrigSects,params.shape_parameter,origThickness,params.dilation_factor);
        else
            fitContour = allContourPts;
        end
        if ~isempty(fitContour)
            if ~params.keepZ
                fitContour(:,3) = 0;
            else
                fitContour(:,3) = fitContour(:,3)-mean(zlimits)+diff(zlimits)/2;
            end
            objStructNew(iObj).name = objStruct(iObj).name;
            objStructNew(iObj).contour(1).name = objStruct(iObj).contour(1).name;
            objStructNew(iObj).contour(1).points = fitContour;
            objStructNew(iObj).contour(1).ptLines = [];
            objStructNew(iObj).contour(1).sections = ones(size(fitContour,1),1);
        end
    end
    % debug
    %if iObj == 2 & ~isempty(allContourPts)
    %    1;
    %end
end


