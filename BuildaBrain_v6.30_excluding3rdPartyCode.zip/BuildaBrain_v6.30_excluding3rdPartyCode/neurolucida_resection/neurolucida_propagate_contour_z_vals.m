function [objStructProp] = neurolucida_propagate_contour_z_vals(objStruct,interSectionDistance,resolution)

%markerStruct.isJittered = 1;
%objStruct.isJittered = 1;

% plot objects frame
for iObj = 1:size(objStruct,2)
    for iContour = 1:length(objStruct(iObj).contour)
        origZ = mean(objStruct(iObj).contour(iContour).points(:,3));
        origPts = objStruct(iObj).contour(iContour).points;
        levels = linspace(origZ-interSectionDistance/2,origZ+interSectionDistance/2,round(1/resolution));
        propPoints = [];
        for iLevel=1:length(levels)
            levelPts = [origPts(:,1) origPts(:,2) ones(size(origPts(:,3)))*levels(iLevel)];
            propPoints = [propPoints ; levelPts];
        end
        objStruct(iObj).contour(iContour).points = propPoints;
        objStruct(iObj).contour(iContour).sections = round( mean( objStruct(iObj).contour(iContour).sections) )*ones(size(propPoints,1),1);
        objStruct(iObj).contour(iContour).ptLines = repmat(objStruct(iObj).contour(iContour).ptLines,1,length(levels));
    end
end

objStructProp = objStruct;
