function [objStructR,markerStructR] = neurolucida_3d_rotate(objStruct,markerStruct,yaw_deg,pitch_deg,roll_deg,orig_section_interval,zres,jitterPts)

if jitterPts
    [objStructJ, markerStructJ] = neurolucida_jitter_z_vals(objStruct,markerStruct,orig_section_interval);
else
    markerStructJ = markerStruct;
end
[objStructProp] = neurolucida_propagate_contour_z_vals(objStruct,orig_section_interval,zres)
R = util_rotation_ang2matrix(yaw_deg,pitch_deg,roll_deg);
[objStructR,markerStructR] = neurolucida_rotate(objStructProp,markerStructJ,R);
