function RSparams = neurolucida_load_RSparams(shape_parameter,keepZ,define_boundary,dilation_factor)

if isempty(shape_parameter)
    shape_parameter = 0;
end

if isempty(keepZ)
    keepZ=1;
end

if isempty(define_boundary)
    define_boundary=1;
end

if isempty(dilation_factor)
    dilation_factor = 0.1
end

RSparams.shape_parameter = shape_parameter;
RSparams.keepZ = keepZ;
RSparams.define_boundary = define_boundary;
RSparams.dilation_factor = dilation_factor