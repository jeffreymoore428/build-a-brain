function fitContour = neurolucida_fit_contour_to_pts(allContourPts,allContourPtsOrigSects,shape_parameter,orig_thickness,dilation_factor)

se = strel('disk',ceil(orig_thickness*dilation_factor));
% fit alphashape
%bk = boundary(allContourPts(:,1),allContourPts(:,2),shape_parameter);
%fitContour = allContourPts(bk,:);

% fit shape to each original section (assumes points jittered)
% get convex hull
hk = boundary(allContourPts(:,1),allContourPts(:,2),0);
fitHull = allContourPts(hk,:);
offset = min(fitHull,[],1);
maxHull = max(fitHull,[],1);
gridSize = ceil( maxHull(:,[1 2])-offset(:,[1 2]));
BW = logical(zeros(gridSize(2),gridSize(1)));

origSections = unique(allContourPtsOrigSects);
dwn = [];
for iSect = 1:length(origSections)
    ptsSect = allContourPts(allContourPtsOrigSects==origSections(iSect),:);
    bk = boundary(ptsSect(:,1),ptsSect(:,2),shape_parameter);
    fitContourSect = ptsSect(bk,:);
    fitContourOffset = [fitContourSect(:,1) - offset(1) , fitContourSect(:,2)-offset(2)];
    BWsect =  logical(poly2mask(fitContourOffset(:,1),fitContourOffset(:,2),gridSize(2),gridSize(1)));
    BW = BW | BWsect;
    % compute contour downsample factor heuristically
    if size(ptsSect,1)>1
        dp1 = repmat(ptsSect(1,:),size(ptsSect,1)-1,1)-ptsSect(2:end,:); % vector between first point in contour pts in current section and all others
        d1 = sqrt(sum(dp1.^2,2)); % distance 
    else
        d1 = []; % do not update if only 1 pt in contour
    end
    dwn = min([dwn ceil(min(d1(d1>0)))]); %update dist to smallest non-zero distance btween points, max resolution 1um
end
BWdil = imdilate(BW,se);
BWer =imerode(BWdil,se);
B = bwboundaries(BWer);
outline = B{1};
fitContourUp(:,1) = outline(:,2) + offset(1);
fitContourUp(:,2) = outline(:,1) + offset(2);
fitContourUp(:,3) = mean(allContourPts(:,3));

% downsample factor
if isempty(dwn);dwn=1;end;    % assume 1um if no other information
fitContour = fitContourUp(1:dwn:end,:);


    
    
    
