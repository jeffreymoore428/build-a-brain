function [objStructNew,markerStructNew] = neurolucida_resection(objStruct,markerStruct,orig_zinterval,zinterval,RSparams,referenceContour)
%zinterval
if nargin<5
    RSparams = [];
end

if nargin<6
    referenceContour = objStruct(1).name;
end

allRefContourPts = [];
numObjects = size(objStruct,2);
for iObj = 1:numObjects
    numContours = size(objStruct(iObj).contour,2);
    for jCont = 1:numContours
        if strcmp(objStruct(iObj).contour(jCont).name,referenceContour)
            allRefContourPts = [allRefContourPts ; objStruct(iObj).contour(jCont).points];
        end
    end
end
minZ = min(allRefContourPts(:,3));
maxZ = max(allRefContourPts(:,3));

% generate sectioning limits
zPositions = minZ:zinterval:maxZ;
% add poartial slab if missing
if zPositions(end)<maxZ
    zPositions = [zPositions zPositions(end)+zinterval];
end

objStructNew = [];
for iSlab = 1:length(zPositions)-1
    zlimits = [zPositions(iSlab) zPositions(iSlab+1)];
    [objStructRS,markerStructRS] = neurolucida_reslice(objStruct,markerStruct,zlimits,orig_zinterval,RSparams);
    if isempty(objStructNew)
        objStructNew = objStructRS;
        markerStructNew = markerStructRS;
    else
        [objStructNew, markerStructNew] = neurolucida_append_2_datasets(objStructNew,markerStructNew,objStructRS,markerStructRS,zinterval,referenceContour,referenceContour,mean(zlimits));
    end
    %neurolucida_plot_objects(objStructNew,markerStructNew);
    %pause(1);
    end