function [objStruct,markerStruct] = neurolucida_rotate(objStruct,markerStruct,rotation_matrix)
% rotate points in markeStruct and objStruct

numMarkers = size(markerStruct,2);
numObjects = size(objStruct,2);

% remove points in sections that have designated contour
for iMarker = 1:numMarkers
    markerStruct(iMarker).points = markerStruct(iMarker).points*rotation_matrix;
end

for iObj = 1:numObjects
    numContours = size(objStruct(iObj).contour,2);
    for jCont = 1:numContours
        objStruct(iObj).contour(jCont).points = objStruct(iObj).contour(jCont).points*rotation_matrix;
    end
end



%disp('Finished rotating points!');
    
    
        
    
    
    