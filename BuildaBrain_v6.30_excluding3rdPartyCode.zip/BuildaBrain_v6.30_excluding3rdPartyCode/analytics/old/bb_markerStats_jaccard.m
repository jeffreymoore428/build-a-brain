function [Jd Jd_p Jd_p_dist] = bb_markerStats_jaccard(markers1,markers2,contours,kernelWidth,repID1,repID2)
% compute Jaccard index statistics for multiple replicates
% points weighted equally among replicates

if nargin<5
    repID1 = [];
    repID2 = [];
end

params.kernelWidth = kernelWidth;
params.contourMatrix = contours;

n1 = size(markers1,1);
n2 = size(markers2,1);
params.ptweights.markers1 = ones(n1,1);
params.ptweights.markers2 = ones(n2,1);

if ~isempty([repID1 ; repID2]);
    uniqueIDs = unique([repID1 ; repID2]);
    for iid = 1:length(uniqueIDs)
        repinds1 = find(repID1==uniqueIDs(iid));
        repinds2 = find(repID2==uniqueIDs(iid));
        params.ptweights.markers1(repinds1) = n1/length(repinds1);
        params.ptweights.markers2(repinds2) = n2/length(repinds2);
    end
end

[Jd, Jd_p, Jd_p_dist ] = bb_markerStats_boot(markers1,markers2,params,@bb_markers2jaccard_kde,100);
