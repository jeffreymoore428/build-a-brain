function [densityImg newContourPos newMarkerPos] = bb_gaussian_density(markers,contours,kernelWidth, ptweights)
%% plot density with gaussian blur

if nargin<4
    ptweights = ones(size(markers,1));
end

markX = markers(:,1); markY = markers(:,2);
contX = contours(:,1); contY = contours(:,2);
minX = min(contX); minY = min(contY);
newMarkX = ceil(markX - minX + 1);
newMarkY = ceil(markY - minY + 1);
newContX = ceil(contX - minX + 1);
newContY = ceil(contY - minY + 1);

densityImg = msproc_getDensity([max(newContY) max(newContX)],newMarkX, newMarkY, kernelWidth,ptweights);

%% output  shifted markers, contours
newContourPos = [newContX newContY];
newMarkerPos = [newMarkX newMarkY];
