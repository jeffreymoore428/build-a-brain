function Jd = bb_markers2jaccard(markers1,markers2,params)
%% plot density with gaussian blur

if ~isfield(params,'ptweights')
    params.ptweights.markers1 = ones(size(markers1,1));
    params.ptweights.markers2 = ones(size(markers2,1));
end

contours = params.contourMatrix;
k = params.kernelWidth;

[densityImg1 newContourPos newMarkerPos] = bb_gaussian_density(markers1,contours,k,params.ptweights.markers1);
[densityImg2] = bb_gaussian_density(markers2,contours,k,params.ptweights.markers2);

Jd = bb_jaccard(densityImg1,densityImg2);

