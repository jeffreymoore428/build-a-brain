function markerStat_resamp = bb_markerStats_resamp(markers1,markers2,params,fcn)
%% resample input groups and compute instance of resampled distribution for fcn
% use: markerStat_resamp = bb_markerStats_resamp(markers1,markers2,@fcn,params)

n1 = size(markers1,1);
n2 = size(markers2,1);
n1inds = ceil(rand(n1,1)*n1);
n2inds = ceil(rand(n2,1)*n2);
markers1r = markers1(n1inds,:);
markers2r = markers2(n2inds,:);


markerStat_resamp = fcn(markers1r,markers2r,params);

