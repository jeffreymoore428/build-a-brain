function [Jd Jd_p Jd_p_dist] = bb_markerStats_jaccard_kde(markers1,markers2,params,nboot)
% compute Jaccard index statistics 

[Jd, Jd_p, Jd_p_dist ] = bb_markerStats_boot(markers1,markers2,params,@bb_markers2jaccard_kde,nboot);
