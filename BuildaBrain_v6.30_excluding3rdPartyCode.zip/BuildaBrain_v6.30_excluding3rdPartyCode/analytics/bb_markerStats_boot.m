function [markerStat, markerStat_p, markerStat_p_dist ] = bb_markerStats_boot(markers1,markers2,params,fcn,nboot)
% bootstrap spatial distribution statistics for pair of distributions
% use: [markerStat, markerStat_ci, markerStat_p, markerStat_ci_dist ,markerStat_p_dist ] = ...
%           bb_markerStats_resamp(markerSet1,markerSet2,@fcn,params,alpha)
% example: [markerStat, markerStat_ci, markerStat_p, markerStat_ci_dist ,markerStat_p_dist ] = ...
%           bb_markerStats_resamp(markers1,markers2,@bb_markers2jaccard,paramSet,0.05)
% inputs: markers1 - (N x 2) matrix containing x,y
%           pairs for point distribution
%         markers2 - same as markers1
%         params - data struct containing paramater values for computing
%           statistics
%         fcn - function handle to use for computation, pass in as "@fcn"
%           functions should take as inputs two Nx2 matrices of spatial
%           coordinates and an optional struct, params specific to each
%           function
%           examples: @bb_markers2jaccard, @bb_markers2peacock
%        nboot (optional) - number of iterations to compute stats (default nboot =
%        5000)


% set default parameters

if nargin<5
    nboot = 5000;
end

%% calculate statistic
markerStat = fcn(markers1,markers2,params);

% bootstrap
for iboot = 1:nboot
    markerStat_p_dist(iboot) = bb_markerStats_shuf(markers1,markers2,params,fcn);
    % display progress
    iboot
    if(mod(iboot,10)==0);disp(['Bootstrapping spatial statistics, ',num2str(iboot/nboot*100),'% complete...']);end
end
disp('Done bootstrapping distance stat!');

markerStat_p = sum(markerStat<markerStat_p_dist)/nboot;

