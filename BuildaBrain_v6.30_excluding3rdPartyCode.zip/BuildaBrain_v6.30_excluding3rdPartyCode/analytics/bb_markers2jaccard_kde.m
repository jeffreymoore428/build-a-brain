function [Jd density1 density2 X Y] = bb_markers2jaccard_kde(markers1,markers2,params)
%% plot density with gaussian blur

if nargin<3
    params = [];
end

if isempty(params)
    data = [markers1 ; markers2];
    MAX=max(data,[],1); MIN=min(data,[],1); Range=MAX-MIN;
    MAX_XY=MAX+Range/2; MIN_XY=MIN-Range/2;
    n=2^8;
else
    n = params.n;
    MIN_XY = params.MIN_XY;
    MAX_XY = params.MAX_XY;
end

[bandwidth1,density1,X,Y]=kde2d(markers1(:,[1 2]),n,MIN_XY,MAX_XY);
[bandwidth2,density2,X2,Y2]=kde2d(markers2(:,[1 2]),n,MIN_XY,MAX_XY);

Jd = bb_jaccard(density1,density2);

