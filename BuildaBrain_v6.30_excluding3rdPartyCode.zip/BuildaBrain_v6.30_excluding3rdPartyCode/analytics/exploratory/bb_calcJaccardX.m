function [Jd n1 n2 bins] = bb_calcJaccardX(points1,points2,bins);

if nargin<3
    bins = [];
end

if isempty(bins)
    xall = [points1(:,1) ; points2(:,1)];
    nbins = sqrt(length(xall));
    bins = linspace(min(xall),max(xall),nbins);
end

x1 = points1(:,1);
x2 = points2(:,1);

n1 = hist(x1,bins);
n2 = hist(x2,bins);

Jd = bb_jaccard_1d(n1,n2);
