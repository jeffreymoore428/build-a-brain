function Jd = bb_jaccard_1d(density1,density2);
% compute weighted Jaccard distance for two 2D density estimates
% a.k.a. Soergel Dist

img1norm = density1/sum(density1);
img2norm = density2/sum(density2);

Jw = sum(min(img1norm,img2norm))/sum(max(img1norm,img2norm));
Jd = 1 - Jw;

%plot(img1norm);hold on;plot(img2norm);pause;hold off;
