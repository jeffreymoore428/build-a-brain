function [Jd thetas] = bb_calcJaccardAngle(points1,points2,bins,dtheta);

if nargin<3
    bins = [];
end

if nargin<4
    dtheta = pi/180;
end

thetas = 0:dtheta:pi;

for itheta = 1:length(thetas)
    [xout1,yout1] = bb_project_points(points1(:,1),points1(:,2),thetas(itheta));
    [xout2,yout2] = bb_project_points(points2(:,1),points2(:,2),thetas(itheta));
    [Jd(itheta) n1 n2 binsout] = bb_calcJaccardX([xout1,yout1],[xout2,yout2],bins);
    subplot(2,1,1); plot(xout1,yout1,'.',xout2,yout2,'.');
    subplot(2,1,2); plot(binsout,n1,binsout,n2);
    pause(0.1);
end

subplot(2,1,1);plot(points1(:,1),points1(:,2),'.',points2(:,1),points2(:,2),'.');
subplot(2,1,2);plot(thetas*180/pi,Jd);
xlabel('Axis (deg)')
ylabel('Soergel Dist');