function [xout,yout] = bb_project_points(x,y,thetaref)

[theta,r] = cart2pol(x,y);
thetat = angdiff(theta,ones(size(theta))*thetaref);
[xout,yout] = pol2cart(thetat,r);