function contdata = MakeContourPlots_pct(dat,levels_in,method);
% make iso-density contour plot s.t. each contour maps to a specified
% level, either as specified fractions of the maximum density (peak) or as
% containing a specified fraction of the datapoints (area)
%
% inputs:   dat - 2D column vector [x y] data
%           levels_in - vector of contour levels to plot (0-1)
%           meathod - specify 'peak' or 'area', peak specifies contour
%           levels as fractions of peak density, area specifies the
%           fraction of points enclosed by the contour (integral)
% outputs:  contdata - data stuct containing contour data
%
% JM modified 6/27/19


% set default contour levels
if nargin<2
    levels_in = [0.1:.1:.99];
end

if nargin<3
    method = 'area';
end

% % test data
% dat1 = randn(10000,2); % simulate point distribution 2D
% dat2 = randn(10000,2)+3;
% %dat = dat1;
% dat = [dat1 ; dat2];

[b,d,x,y] = kde2d(dat); % calculate density (d)

dvals = reshape(d,prod(size(d)),1); % make density matrix 1D
dvals_sorted = sort(dvals); %sort ascending
cum_dvals = cumsum(dvals_sorted); % compute integral 

level_pctiles = 1-levels_in; %[1:9]*.1; 

for i=1:length(level_pctiles) %iterate over levels
    
    if strcmp(method,'area')
        % calculate density value for which the fractional area < x percent
        level_val = dvals_sorted(max(find( (cum_dvals/sum(dvals_sorted)) <level_pctiles(i) )));
    elseif strcmp(method,'peak')
        % calculate density value that is level*100% of the maximum density
        level_val = dvals_sorted(max(find( (dvals_sorted/max(dvals_sorted)) <level_pctiles(i) )));
    else
        error('contouring method not recognized');
    end
    
    cont = contour(x,y,d,level_val*[1 1])'; % compute contour for each level
    
    % create output data structure containing contours
    contdata(i).level_pctile = level_pctiles(i); 
    contdata(i).level_val = level_val;
    contind = 1;
    contnum = 0;
    % iterate to make separate polygon for each enclosed region
    while contind<length(cont)
        npoints = cont(contind,2);
        contd = cont(contind+1:contind+npoints,:); % first entry in cont is [level Npoints] , remove to get contour coords
        contind = contind+npoints+1;
        contnum = contnum+1;
        contdata(i).polygon(contnum).x = contd(:,1);
        contdata(i).polygon(contnum).y = contd(:,2);
    end
    % verify contours by computing the ratio of pts in and outside 
    for j=1:contnum 
        inj(:,j) = inpolygon(dat(:,1),dat(:,2),contdata(i).polygon(j).x,contdata(i).polygon(j).y);
    end
    in = sum(inj,2);
    contdata(i).out = sum(~in)/length(in);
end

%% plot
plot(dat(:,1),dat(:,2),'.');
hold on;

for i=1:length(level_pctiles)
    for j=1:size(contdata(i).polygon,2)
        plot(contdata(i).polygon(j).x,contdata(i).polygon(j).y,'Color',[level_pctiles(i),0,0]);
    end
end

hold off;
    


