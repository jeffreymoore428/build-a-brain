function markerStat_shuf = bb_markerStats_shuf(markers1,markers2,params,fcn)
%% shuffle input groups and compute instance of null distribution for fcn
% use: markerStat_shuf = bb_markerStats_shuf(markers1,markers2,@fcn,params)

numMarkers1 = size(markers1,1);
allMarkers = [markers1 ; markers2];
allMarkersShuf = allMarkers(randperm(size(allMarkers,1)),:);
markers1shuf = allMarkersShuf(1:numMarkers1,:);
markers2shuf = allMarkersShuf((numMarkers1+1):end,:);


markerStat_shuf = fcn(markers1shuf,markers2shuf,params);

