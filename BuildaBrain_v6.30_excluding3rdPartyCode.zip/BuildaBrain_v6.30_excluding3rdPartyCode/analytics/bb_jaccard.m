function Jd = bb_jaccard(densityImg1,densityImg2);
% compute weighted Jaccard distance for two 2D density estimates
% a.k.a. Soergel Dist

img1norm = densityImg1/sum(sum(densityImg1));
img2norm = densityImg2/sum(sum(densityImg2));

Jw = sum(sum(min(img1norm,img2norm)))/sum(sum(max(img1norm,img2norm)));
Jd = 1 - Jw;
