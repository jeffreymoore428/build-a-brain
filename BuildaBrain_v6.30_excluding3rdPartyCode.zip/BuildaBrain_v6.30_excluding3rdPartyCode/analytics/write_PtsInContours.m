function OT = write_PtsInContours(pathfilename,sectionThickness)

if nargin<2
    sectionThickness = 0;
end

if nargin<3
    outformat = '.csv';
end


[pathstr,name,ext] = fileparts(pathfilename);
filename = [name,ext];
outfilename = ['BBstats_',filename];

disp('Counting markers in contours...')

[objStruct markerStruct contourStruct NL_ASC_lines] = neurolucidaASC2mat(pathfilename);
contourNames = {objStruct.name}';
numConts = size(objStruct,2);
numMarkers = size(markerStruct,2)
for iCont = 1:numConts
    name = contourNames(iCont); % remove quotes
    if numMarkers>0
        for iMarker = 1:numMarkers
            [allpts vol totarea] = getPtsInContour(objStruct,markerStruct,iMarker,name,sectionThickness);
            ptcount(iCont,iMarker) = size(allpts,1);
        end
    else % if no markers, get volume only
        markerLabels{1} = 'No markers';
        [allpts vol totarea] = getPtsInContour(objStruct,markerStruct,false,name,sectionThickness);
        ptcount(iCont,:) = 0;
    end
    volcount(iCont) = vol;
    areacount(iCont) = totarea;
end

% generate data table
OT = table;
OT.Contours = {objStruct.name}';
OT.Area_um2 = areacount';
OT.Volume_um3 = volcount';
for iMarker = 1:numMarkers
    eval(['OT.Marker',num2str(iMarker),' = ptcount(:,iMarker);']);
end
OT

disp(['Writing output file ...']);
writetable(OT,[outfilename,outformat]);
disp(['Output file ',outfilename,outformat,' created!'])