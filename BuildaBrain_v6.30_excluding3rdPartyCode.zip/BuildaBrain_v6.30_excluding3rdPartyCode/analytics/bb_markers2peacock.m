function D = bb_markers2peackock(markers1,markers2,params)
% compute Peacock test on spatial distribution of points

[H, pValue, KSstatistic] = kstest_2s_2d(markers1, markers2);
D = KSstatistic;