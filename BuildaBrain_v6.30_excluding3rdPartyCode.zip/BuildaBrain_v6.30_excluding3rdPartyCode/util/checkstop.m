function isStopped = checkstop()
% check if global stop flag executed
global STOP;
isStopped = 0;
%pause(0.001);
if STOP
    isStopped = 1;
    STOP = []; % reset stop
    error('BB error: STOP executed');
else
    isStopped = 0;
end