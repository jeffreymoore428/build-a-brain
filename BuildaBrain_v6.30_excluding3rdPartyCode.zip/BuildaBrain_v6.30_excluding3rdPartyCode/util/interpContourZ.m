function [projectContour contourMap1 contourMap2 project1 project2] = interpContourZ(contour1, contour2, zk)
% generate interpolated contour between two contours
% contour1 and contour 2 are N x 3 polygons, typically all z values are
% same for each contour


%% interpolate contours


pc1 = pointCloud(contour1);
pc2 = pointCloud(contour2);

numPts1 = size(contour1,1);
numPts2 = size(contour2,1);

% map first projection
contourMap1 = []; project1 = [];
for i=1:numPts2 
    ind = findNearestNeighbors(pc1,contour2(i,:),1);
    contourMap1(i,:) = contour1(ind,:);
    [xk,yk] = line2zPlane(contour2(i,:),contourMap1(i,:),zk);
    project1(i,:) = [xk,yk,zk];
end

% map 2nd projection
contourMap2 = []; project2 = [];
for i=1:numPts1
    ind = findNearestNeighbors(pc2,contour1(i,:),1);
    contourMap2(i,:) = contour2(ind,:); 
    [xk,yk] = line2zPlane(contour1(i,:),contourMap2(i,:),zk);
    project2(i,:) = [xk,yk,zk];
end

% move to positive position for pixel indexing (pixel size is in the same
% units as contour size)

offsetx = min([project1(:,1) ; project2(:,1)]) - 1;
rangex = ceil(range([project1(:,1) ; project2(:,1)])) + 1;

offsety = min([project1(:,2) ; project2(:,2)]) - 1;
rangey = ceil(range([project1(:,2) ; project2(:,2)])) + 1;


project1_pos = [ project1(:,1) - offsetx , project1(:,2) - offsety ];
project2_pos = [ project2(:,1) - offsetx , project2(:,2) - offsety ];

% make masks to find superposition

bw1 = poly2mask(project1_pos(:,2),project1_pos(:,1),rangex,rangey);
bw2 = poly2mask(project2_pos(:,2),project2_pos(:,1),rangex,rangey);
bw = logical(bw1 + bw2);

B = bwboundaries(bw);
projectxy_pos = B{1};

% return to original coordinate space
projectxy = [projectxy_pos(:,1) + offsetx , projectxy_pos(:,2) + offsety];
projectContour = [projectxy zk*ones(size(projectxy,1),1)];