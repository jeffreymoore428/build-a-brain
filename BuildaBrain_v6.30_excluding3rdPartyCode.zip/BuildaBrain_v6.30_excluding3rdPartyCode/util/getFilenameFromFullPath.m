function [ filename, filepath ] = getFilenameFromFullPath(pathfilename)
% split filename into path and filename

slashChar = getPathSlash(pathfilename);
lastSlashInd = max(strfind(pathfilename,slashChar));
filename = pathfilename(lastSlashInd+1:end);
filepath = pathfilename(1:lastSlashInd);