function [hFig,hIm] = showCurrentImageTools

hFig = imgcf;
try
    hIm = imhandles(hFig);
    imoverview(hIm);
    imcontrast(hIm);
    impixelinfo(hIm);
    figure(hFig);
catch
    close(hFig);
    disp('No image displayed!');
end