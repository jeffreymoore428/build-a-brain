function [pts vol totarea] = getPtsInContour(objStruct,markerStruct,markerNum,contourName,sectionThickness)
% count points and volume within a contour set

% jm - modified 2/27/2019 - added z values to points
% jm - modified 6/30/2019 - added section thickness to calculate volume edge effects

if nargin<5
    sectionThickness = 0; % use for volume of first/last contours in object
end

pts = [];
vol = [];

numObjs  = size(objStruct,2);
for iObj = 1:numObjs
    if strcmp(objStruct(iObj).name,contourName)
        numConts = size(objStruct(iObj).contour,2)
        for iContour = 1:numConts
            sectionNum = mode(objStruct(iObj).contour(iContour).sections)
            xv = objStruct(iObj).contour(iContour).points(:,1);
            yv = objStruct(iObj).contour(iContour).points(:,2);
            contzavg(iContour) = mean(objStruct(iObj).contour(iContour).points(:,3));
            contarea(iContour) = polyarea(xv,yv);
            if markerNum
                markersInSectionInds = find(markerStruct(markerNum).sections==sectionNum);
            else
                markersInSectionInds = [];
            end
            if ~isempty(markersInSectionInds)
                xq = markerStruct(markerNum).points(markersInSectionInds,1);
                yq = markerStruct(markerNum).points(markersInSectionInds,2);
                zq = markerStruct(markerNum).points(markersInSectionInds,2);
                inInds = inpolygon(xq,yq,xv,yv);
                pts = [pts; [xq(inInds) yq(inInds) zq(inInds)]];
            end
        end
        % calculate volume, avg left and right corner approximations
        [contzsort contzinds] = sort(contzavg,'ascend');
        contareasort = contarea(contzinds);
        dz = diff(contzsort);
        if ~isempty(dz)
            volLeft = sum(contareasort(1:end-1).*dz) + contareasort(end)*sectionThickness;
            volRight = sum(contareasort(2:end).*dz) + contareasort(1)*sectionThickness;
            vol = mean([volLeft, volRight]);
        else
            vol = 0; % only one section, zero 
        end
        totarea = sum(contareasort);
    end
end


            