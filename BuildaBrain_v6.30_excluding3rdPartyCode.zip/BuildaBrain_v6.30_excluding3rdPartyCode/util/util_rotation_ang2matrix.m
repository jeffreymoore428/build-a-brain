function R = util_rotation_ang2matrix(yaw_deg,pitch_deg,roll_deg)

a = deg2rad(yaw_deg);
b = deg2rad(pitch_deg);
g = deg2rad(roll_deg);

Rz = [cos(a) -sin(a) 0; sin(a) cos(a) 0; 0 0 1];
Ry = [cos(b) 0 sin(b); 0 1 0 ; -sin(b) 0 cos(b)];
Rx = [1 0 0; 0 cos(g) -sin(g); 0 sin(g) cos(g)];

R = Rz*Ry*Rx;