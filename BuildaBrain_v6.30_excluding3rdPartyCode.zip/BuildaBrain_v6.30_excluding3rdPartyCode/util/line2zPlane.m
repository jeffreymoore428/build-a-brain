function [xk,yk,zk] = line2zPlane(pt0,pt1,zk)
% finds intersection of line through 2 points pt1 and pt2 with z plane at z
% = zk
% pt1 and pt2 specified as 3 element row vectors [x,y,z]

% use equations for line in 3d: (x - x0)/a = (y-y0)/b = z-zo

x0 = pt0(1); y0 = pt0(2); z0 = pt0(3);
x1 = pt1(1); y1 = pt1(2); z1 = pt1(3);

dx = x1-x0; dy = y1-y0 ; dz = z1-z0;

xk = x0 + (dx/dz)*(zk - z0);
yk = y0 + (dy/dz)*(zk - z0);



