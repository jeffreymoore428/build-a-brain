function slashChar = getPathSlash(PathName)
% get character for directory separation for cross-platform compatability

bsInd = strfind(PathName,'\');
fsInd = strfind(PathName,'/');

if isempty(bsInd)
    slashChar = '/';
elseif isempty(fsInd);
    slashChar = '\';
else
    error('Path not recognized');
end