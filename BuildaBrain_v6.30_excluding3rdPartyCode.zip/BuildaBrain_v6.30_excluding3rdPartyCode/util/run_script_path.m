function varout = run_script_path(pathfilename,varname)
% runs a matlab SCRIPT with full path specified by calling it from the
% directory its stored in
% returns the variable stored in string varname

% example: varout = run_script_path('C:\generate_params.m','params')

curdir = pwd;
[pathstr,name,ext] = fileparts(pathfilename);
cd(pathstr);
eval(name);
eval(['varout = ',varname]);
cd(curdir);