function [allpts allvol totarea] = getPtsInContours(objStruct,markerStruct,markerNum,contourNames)
% marker num is numberic
% contour names is list of names of contours in the form: {'contour1' ;
% 'contour2' ; 'contour3' }

allpts = [];
allvol = [];
allarea = [];
numObjs = length(contourNames)
for iObj = 1:numObjs
    [pts vol totarea] = getPtsInContour(objStruct,markerStruct,markerNum,contourNames{iObj});
    allpts = [allpts ; pts ];
    allvol = [allvol ; vol];
    allarea = [allarea ; totarea ];
end