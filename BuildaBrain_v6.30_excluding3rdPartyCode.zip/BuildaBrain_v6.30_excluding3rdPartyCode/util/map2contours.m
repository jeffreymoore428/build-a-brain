
% %% make test contours
figure;axis equal;
xlim([-2000 2000]); ylim([-2000 2000]);
h1 = imfreehand;h2 = imfreehand; 
a = h1.getPosition; b = h2.getPosition; 
contour1 = [a ones(size(a(:,1)))];
contour2 = [b 2*ones(size(b(:,1)))];
zk = 1.3;

%% do projection
[project contourMap1 contourMap2 project1 project2] = interpContourZ(contour1, contour2, zk);

%% plot
figure;
plot3(contour1(:,1),contour1(:,2),contour1(:,3),'b.')
hold on;
plot3(contour2(:,1),contour2(:,2),contour2(:,3),'g.')
plot3(contourMap1(:,1),contourMap1(:,2),contourMap1(:,3),'r.')
plot3(project(:,1),project(:,2),project(:,3),'m.')
% for i=1:numPts2
%     line([contour2(i,1) contourMap1(i,1)],[contour2(i,2) contourMap1(i,2)],[contour2(i,3) contourMap1(i,3)]);
% end