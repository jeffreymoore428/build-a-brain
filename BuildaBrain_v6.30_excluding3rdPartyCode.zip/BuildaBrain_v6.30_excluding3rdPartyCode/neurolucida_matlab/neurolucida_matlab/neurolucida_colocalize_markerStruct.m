function markerStructNew = neurolucida_colocalize_markerStruct(markerStruct,channel1,channel2,threshDist,type);
% add colocalized marker set to markerStruct
if nargin<5
    type = 'FilledStar';
end

nchannels = size(markerStruct,2);

points1 = markerStruct(channel1).points;
points2 = markerStruct(channel2).points;

[colocID1_rd colocID2_rd minDistColoc minDist] = colocolize_markers3_fast(markerStruct(channel1).points,markerStruct(channel2).points,threshDist);

points = markerStruct(channel1).points(colocID1_rd,:);
sections = markerStruct(channel1).sections(colocID1_rd);

if ~isempty(points)
    markerStructNew = neurolucida_addPts2NeurolucidaMarkers(markerStruct,points,sections,type);
    disp('Colocalization marker added!');
else
    markerStructNew = markerStruct;
    disp('No colocalization between selected points. No marker was added.');
end