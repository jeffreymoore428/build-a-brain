function [sectionNums, sectionOutlineName] = neurolucida_list_all_sectionNums_with_outline(objStruct, sectionOutlineName)

% set defaults
if nargin<2; sectionOutlineName = objStruct(1).name; end

numObjs = size(objStruct,2);
allSectionOutlineSections = [];
for iObj = 1:numObjs
    % get number of contours and markers
    numContours = size(objStruct(iObj).contour,2);
    
    % find all contours with sectionOutline
    sectionOutlineInds = [];
    for iContour = 1:numContours
        if strcmp(objStruct(iObj).contour(iContour).name, sectionOutlineName)
            sectionOutlineInds = [sectionOutlineInds ; iContour];
        end
    end
    
    % find all sections with sectionOutline
    sectionOutlineSections = [];
    for iSection = 1:length(sectionOutlineInds)
        iContourNum = sectionOutlineInds(iSection);
        iContourSections = objStruct(iObj).contour(iContourNum).sections;
        if sum(diff(iContourSections))>0
            warning('Not all contour points in same section!');
        end
        iContourSection = round(mean(iContourSections));
        sectionOutlineSections = [sectionOutlineSections, iContourSection];
    end
    allSectionOutlineSections = [allSectionOutlineSections, sectionOutlineSections];
end

%sectionNums = unique(allSectionOutlineSections) % v4.1
sectionNums = unique(allSectionOutlineSections,'rows','stable'); % JM fix 11/1/2018 for neurolucida renumbered sections
