function [markerMat contourMat] = neurolucidaASC2matrix(ASCFilename,sectionNums)
%convert ASC to matrix

% inputs:
% neurolucida or build-a-brain ascii file
% section Ids to excise

% outputs:
% markerMat - matrix of markers - [x y z MarkerID]
% contourMat - matrix of contours - [x y z ObjectID ContourID]

[objStruct markerStruct] = neurolucidaASC2mat(ASCFilename)

markerMat = [];
numSections= length(sectionNums)
numMarkers = size(markerStruct,2);
for i =1:numMarkers
    for j=1:numSections
        indes=find(markerStruct(i).sections==sectionNums(j));
        xyz = markerStruct(i).points(indes,:);
        markerMat = [markerMat ; [xyz ones(size(xyz,1),1)*i] ];
    end
end

contourMat = [];
numObjects = size(objStruct,2);
for h = 1:numObjects
    numContours = size(objStruct(h).contour,2);
    for i =1:numContours
        for j=1:numSections
            indes=find(objStruct(h).contour(i).sections==sectionNums(j));
            xyz = objStruct(h).contour(i).points(indes,:);
            contourMat = [contourMat ; [xyz ones(size(xyz,1),1)*h ones(size(xyz,1),1)*i] ];
        end
    end
end
            
%