function filenameMod = neurolucidaASC_mat2NL(filename,NL_ASC_lines,lines2remove,lines2modPts,pts);
% write lines to ASCII file omitting lines2remove line indices

if nargin<4
    lines2modPts = [];
    pts = [];
end

filenameMod = [filename(1:end-4),'_MatlabModified.ASC'];
delete(filenameMod);

numLines = size(NL_ASC_lines,2);
lines2write = setxor([1:numLines],lines2remove);

fileID = fopen(filenameMod,'w');

for iline = 1:length(lines2write)
    lineInd = find(ismember(lines2modPts,iline));
    if lineInd
        x = pts(lineInd,1);
        y = pts(lineInd,2);
        z = pts(lineInd,3);
        strall = NL_ASC_lines(lines2write(iline)).line;
        % deconstruct line to numbers
        bracketstart = strfind(strall,'(');
        sectInd = strfind(strall,' S');
        strFirst = strall(1:sectInd-1);
        spaceB4res = max(strfind(strFirst,' '));
        res = strall(spaceB4res+1:sectInd-1);
        strmod = [strall(1:bracketstart),num2str(x),' ',num2str(y),' ',num2str(z),' ',res,strall(sectInd:end)];
        fprintf(fileID,[strmod,'\r\n']);
    else    
        fprintf(fileID,[NL_ASC_lines(lines2write(iline)).line,'\r\n']);
    end
end
fclose(fileID);
