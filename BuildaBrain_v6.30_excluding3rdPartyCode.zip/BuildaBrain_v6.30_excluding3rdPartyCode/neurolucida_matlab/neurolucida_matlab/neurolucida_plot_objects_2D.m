function neurolucida_plot_objects_2D(objStruct,markerStruct,sectionNums);

contours2D = {'k-' ; 'm-' ; 'g-'; 'r-' ; 'b-' ; 'c-' ; 'y-' ; 'k-' ; 'm-' ; 'g-'; 'r-' ; 'b-' ; 'c-' ; 'y-';'k-' ; 'm-' ; 'g-'; 'r-' ; 'b-' ; 'c-' ; 'y-' ; 'k-' ; 'm-' ; 'g-'; 'r-' ; 'b-' ; 'c-' ; 'y-'};

allSections = neurolucida_get_allSections(objStruct,markerStruct);

if nargin<3
    sectionNums = [];
end
if isempty(sectionNums)
    sectionNums = allSections;
end

numTiles = ceil(sqrt(length(sectionNums)));

for iSection = 1:length(sectionNums)
    %checkstop();
    iSection
    currentSection = sectionNums(iSection);
    secs2remove = setdiff(allSections,currentSection);
    [objStructSection, markerStructSection] = neurolucida_remove_objects_by_section(objStruct,markerStruct,secs2remove);
    subplot(numTiles,numTiles,iSection);
    neurolucida_plot_objects(objStructSection, markerStructSection, contours2D, [], []);
end
    
