function dat_full = neurolucida_scan2jp2(inputFilename,channels,flipx,flipy,compressionQuality, outputFilename);

% converts file from slide scanner to jpeg2000
% input: filename - name/path of file
%        channels - channels to convert, default all (if >3, chooses first
%        3)
%        flipx - whether to apply flipud, default 0
%        flipy - whether to apply fliplr, default 0

if nargin<2;
    channels = [];
end

if nargin<3
    flipx = 0;
end

if nargin<4
    flipy = 0;
end

if nargin<5
    compressionQuality = 100;
end

if nargin<6
    outputFilename = [inputFilename(1:end-4),'_jp2.jp2'];
end

dat = bfopen(inputFilename);
dat_full = dat{1};

% set and adjust number of channels
channels_total = size(dat_full,1);
if isempty(channels);
    channels = [1:channels_total];
    if length(channels)>3
        channels = channels([1:3]);
        warning(['More than 3 channels selected, writing channels: ',num2str(channels)]);
    end
end

for ichan = 1:length(channels)
    pix = dat_full{channels(ichan)};
    if flipx; pix = flipud(pix); end;
    if flipy; pix = fliplr(pix); end;
    imgData(:,:,ichan) = pix;
end

if compressionQuality>99
    outputParamName = 'Mode';
    outputParamValue = 'lossless';
else
    outputParamName = 'CompressionRatio';
    outputParamValue = 100/compressionQuality; 
end
disp(['Compression Ratio: ',num2str(outputParamValue)]);
imwrite(imgData,outputFilename,'jp2',outputParamName,outputParamValue);


