function [A polyPts isCorrected] = align_2_sections(fixedContour, movingContour, manualCorrect);
% calculates rigid transformation to align movingContour to fixedContour, 2
% 2d contours
% using iteritive closest points

%   returns the 2D transformation
% if manualCorrect = true, performs the function interactively and allows
% user to correct if wrong

if nargin<3
    manualCorrect = [];
end

% get xy coords
sxFixed = fixedContour(:,1);
syFixed = fixedContour(:,2);

sxMoving = movingContour(:,1);
syMoving = movingContour(:,2);

% calculate forward rigid transform using ICP
tform = pcregrigid(pointCloud([sxMoving syMoving zeros(size(sxMoving))]),pointCloud([sxFixed syFixed zeros(size(sxFixed))]));
A = maketform('affine',tform.T);

% apply forward transform to section outlines
[sxMoved, syMoved, szMoved] = tformfwd(A, sxMoving, syMoving, zeros(size(sxMoving)));

% check and iterate manually if no good
%figure(1);
plot(sxFixed,syFixed,'k.',sxMoving,syMoving,'b--',sxMoved,syMoved,'r.');title('See instructions in MATLAB terminal');axis equal;
polyPts = []; x = [];

if manualCorrect
    x = input('Accept current (red) alignment to previous section (black)? Yes-Hit Enter Key, No-Enter 0:');
    while ~isempty(x)
        disp('Click in figure to outline polygon region on current (blue) section to align to previous (black) section');
        disp('Right click to complete');
        h = impoly;
        polyPts = h.getPosition;
        xi = polyPts(:,1); yi = polyPts(:,2);
        tform = pcregrigid(pointCloud([xi yi zeros(size(xi))]),pointCloud([sxFixed syFixed zeros(size(sxFixed))]));
        A = maketform('affine',tform.T);
        [sxMoved, syMoved, szMoved] = tformfwd(A, sxMoving, syMoving, zeros(size(sxMoving)));
        %figure(1);
        plot(sxFixed,syFixed,'k.',sxMoving,syMoving,'b.',sxMoved,syMoved,'r.'); axis equal
        x = input('Accept alignment? Yes-Hit Enter Key, No-Enter 0');
    end
end

isCorrected = [];