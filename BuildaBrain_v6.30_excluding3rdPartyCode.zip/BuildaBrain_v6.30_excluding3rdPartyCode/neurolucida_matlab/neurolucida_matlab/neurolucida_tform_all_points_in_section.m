function [objStruct, markerStruct] = neurolucida_tform_all_points_in_section(objStruct,markerStruct,sectionNum,A,xyOffset)

if nargin<5; xyOffset = [0 0]; end;

% get number of objects and markers
numMarkers = size(markerStruct,2);
numObjs = size(objStruct,2); % display this to debug

for iObj = 1:numObjs
    numContours = size(objStruct(iObj).contour,2);
    for iContour = 1:numContours
        sections = objStruct(iObj).contour(iContour).sections;
        currentSectionInds = find(sections == sectionNum);
        currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
        if ~isempty(currentSectionPts)
            xc = currentSectionPts(:,1);yc=currentSectionPts(:,2);zc=zeros(size(xc));
            [xcm,ycm,zcm] = tformfwd(A,xc-xyOffset(1),yc-xyOffset(2),zc);
            objStruct(iObj).contour(iContour).points(currentSectionInds,[1 2]) = [ xcm ycm ];
            %figure(2);
            %hold on;
            %plot(xc,yc,'b.',xcm,ycm,'r.');axis equal;
        end
    end
end
for iMarker = 1:numMarkers
    sections = markerStruct(iMarker).sections;
    currentSectionInds = find(sections == sectionNum);
    currentSectionPts = markerStruct(iMarker).points(currentSectionInds,:);
    if ~isempty(currentSectionPts)
        xp = currentSectionPts(:,1);yp=currentSectionPts(:,2);zp=zeros(size(xp));
        [xpm,ypm,zpm] = tformfwd(A,xp - xyOffset(1),yp-xyOffset(2),zp);
        markerStruct(iMarker).points(currentSectionInds,[1 2]) = [ xpm ypm ];
        %plot(xp,yp,'b.',xpm,ypm,'r.')
    end
end