function markerStruct = neurolucida_addMeasure2NeurolucidaMarkers(markerStruct,serialSections,serialMeasures,interSectionInterval,scale)
% add contours contained in serial measures structure, created with
% serialStruct_measurePts

if isempty(serialMeasures); return; end; % don't do anything if no measures to add

newMarkerInds = find(strcmp({serialMeasures.type},'points'));
for iNewMarker = 1:length(newMarkerInds)
    name = serialMeasures(newMarkerInds(iNewMarker)).name;
    newMarkerType = name; % check " convention, OK ; note: if adding points, user should specify in the name text the name of a type that is recognized by neurolucida in order to be neurolucida readable
    if any(strcmp({markerStruct.type},newMarkerType))
        warning(['Marker set already contains a ',newMarkerType,' marker. Mixing markers!']);
    end
    numObjs = size(markerStruct,2);
    numConts = size(serialMeasures(newMarkerInds(iNewMarker)).shape,2);
    allPts = [];
    allSections = [];
    for iSection = 1:numConts
        pts = serialMeasures(newMarkerInds(iNewMarker)).shape(iSection).pts;
        section = serialMeasures(newMarkerInds(iNewMarker)).shape(iSection).section;
        %scale_pts = pts*scale; % code for non-slide referenced contours -
        %obsolete - use option below to correct for slide offsets if utilized
        % add offsets for slide referenced contours (JM 7/8/2019)
        %scale_pts = pts*scale;
        %obsolete - use option below to correct for slide offsets if utilized
        % add offsets for slide referenced contours (JM 7/8/2019)
        if isfield(serialSections.thumb(section),'offset_pix') & isfield(serialSections,'xbounds_pix')
            scale_pts = [];
            scale_pts_0 = pts*scale;
            offset = serialSections.thumb(section).offset_pix;
            xshift_pix = serialSections.xbounds_pix(1);
            yshift_pix = serialSections.ybounds_pix(1);
            if ~isempty(scale_pts_0)
                scale_pts(:,1) = scale_pts_0(:,1) + (offset(1) - xshift_pix)*scale;
                scale_pts(:,2) = scale_pts_0(:,2) - (offset(2) - yshift_pix)*scale;
            end
        else
            scale_pts = pts*scale;    
        end
        % end slide referenced contour adjustment
        sp = size(scale_pts);
        sections = ones(sp(1),1)*section;
        pts3 = [scale_pts , (sections-1)*interSectionInterval];
        if ~any(any(isnan(pts)))
            allPts = [allPts ; pts3];
            allSections = [allSections ; sections ];
        end
    end
    markerStruct = neurolucida_addPts2NeurolucidaMarkers(markerStruct,allPts,allSections,newMarkerType);
end
