function neurolucidaASC_writefile(filename,objStruct,markerStruct,interSectionDistance,sectionThickness)
% given MATLAB representation of Neurolucida points and contours, generate
% complete neurolucida '.ASC' data file

if nargin<5; sectionThickness = interSectionDistance; end

%% get all sections
allSections = [];
numObjects = size(objStruct,2);
for iObj = 1:numObjects
    numContours = size(objStruct(iObj).contour,2);
    for iContour = 1:numContours
        allSections = unique([allSections ; objStruct(iObj).contour(iContour).sections]);
    end
end

numMarkers = size(markerStruct,2);
for iMarker = 1:numMarkers
    allSections = unique([allSections ; markerStruct(iMarker).sections]);
end

allSectionsSorted = sort(allSections,'ascend');
allSectionsZ = (allSectionsSorted-1)*interSectionDistance;

%% write header

header = ';	V3 text file written for MicroBrightField products.';
newline = '\r\n';

fn = [filename,'.ASC'];
fid = fopen(fn,'w');

% print header
fprintf(fid,header,[]);
fprintf(fid,newline,[]);

%% print description
fprintf(fid,newline,[]);
descriptionHeader = ['(Description'];
descriptionFooter = [')  ;  End of description'];
fprintf(fid,descriptionHeader,[]);
fprintf(fid,newline,[]);
fprintf(fid,descriptionFooter,[]);
fprintf(fid,newline,[]);

%% print sections
sectionsHeader = ['(Sections '];
sectionsFooter = [') ; End of Sections'];
fprintf(fid,sectionsHeader,[]);
sectionEntryData =  [allSectionsSorted ...
                    allSectionsSorted ...
                    allSectionsZ ...
                    repmat(sectionThickness,length(allSectionsSorted),1) ...
                    repmat(0,length(allSectionsSorted),1) ...
                    ];

fprintf(fid,[' S%0.0f "Section %0.0f" %0.0f %0.0f %0.0f',newline],sectionEntryData');
fprintf(fid,[sectionsFooter,newline],[]);

%% print contours
contourHeader = ['('];
contourFooter = [' Closure point',newline,')  ;  End of contour',newline];
contourAttributes = [   '  (Color Blue)',newline, ...
                        '  (Closed)',newline, ...
                        '  (GUID "")',newline, ...
                        '  (FillDensity 0)',newline, ...
                        '  (MBFObjectType 5)',newline, ...
                        '  (Resolution 1.000000)',newline, ...
                        ];

for iObj = 1:numObjects
    %checkstop();
    numContours = size(objStruct(iObj).contour,2);
    for iContour = 1:numContours
        contourName = objStruct(iObj).contour(iContour).name;
        contourPoints = objStruct(iObj).contour(iContour).points;
        contourSections = objStruct(iObj).contour(iContour).sections;
        contourNumInds = ones(size(contourPoints,1),1)*iContour;
        contourPointInds = [1:size(contourPoints,1)]';
        contourEntryData = [contourPoints contourSections contourNumInds contourPointInds]; 
        fprintf(fid,newline,[]);
        fprintf(fid,contourHeader,[]);
        fprintf(fid,contourName,[]); 
        fprintf(fid,newline,[]); 
        fprintf(fid,contourAttributes,[]);
        fprintf(fid,['  (%0.2f %0.2f %8.2f     1.00 S%0.0f)  ; %0.0f, %0.0f',newline],contourEntryData(1:end-1,:)');
        fprintf(fid,['  (%0.2f %0.2f %8.2f     1.00 S%0.0f)  ; %0.0f, %0.0f'],contourEntryData(end,:)');
        fprintf(fid,contourFooter,[]);
    end
end

%% print markers

numMarkers = size(markerStruct,2);

markerHeader = ['('];
markerFooter = [')  ;  End of markers',newline];
markerAttributes = [   '  (Color Red)',newline, ...
                        ];
for iMarker = 1:numMarkers
    %checkstop();
    markerName = markerStruct(iMarker).type;
    markerPoints = markerStruct(iMarker).points;
    markerSections = markerStruct(iMarker).sections;
    markerPointInds = [1:size(markerPoints,1)]';
    markerEntryData = [markerPoints markerSections markerPointInds];
    fprintf(fid,newline,[]);
    fprintf(fid,markerHeader,[]);
    fprintf(fid,markerName,[]);
    fprintf(fid,newline,[]);
    fprintf(fid,markerAttributes,[]);
    fprintf(fid,['  (Name "Marker %0.0f")',newline],iMarker);
    fprintf(fid,['  (%0.2f %0.2f %8.2f     1.00 S%0.0f)  ; %0.0f',newline],markerEntryData');
    fprintf(fid,markerFooter,[]);
end
    
    

%% cleanup
fclose(fid);


