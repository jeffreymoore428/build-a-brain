function [objStruct markerStruct contourStruct NL_ASC_lines] = neurolucidaASC2mat_math(filename);
% input is ASC file of neurolucida tracings

[NL_ASC_obj NL_ASC_lines] = neurolucidaASC_parse(filename); % low level ASC parser
[objStruct markerStruct contourStruct] = neurolucidaASC_get_marker_pts(NL_ASC_obj); % get objects (contours of each type) and markers

% modify/delete points and update relevant objects
[markerStruct objStruct contourStruct allLines2remove lines2modPts pts] = neurolucida_mat_math(markerStruct,objStruct,contourStruct);

% rewrite ascii file
newfilename = neurolucidaASC_mat2NL(filename,NL_ASC_lines,allLines2remove,lines2modPts,pts);

% get points from new ascii file
[NL_ASC_obj_new NL_ASC_lines_new] = neurolucidaASC_parse(newfilename); % low level XML parser
[objStruct markerStruct contourStruct] = neurolucidaASC_get_marker_pts(NL_ASC_obj_new); % get objects (contours of each type) and markers

% plot in MATLAB
neurolucida_plot_objects(objStruct, markerStruct); % plot

% write to csv
neurolucida_mat2txt(newfilename,markerStruct,contourStruct); % output to simple text format