function [objStruct markerStruct contourStruct] = neurolucidaASC_get_marker_pts(obj);

% reads in data structure created by neurolucida and parsed from
% 'neurolucida_parseASC.m' and returns points, contour sets
%
% input:    obj - output of neurolucida ASCII parser
%                        'neurolucida_parseASC.m'
% output: objStruct - structure of contour sets with fields:
%              % name - string
%              % contour - struct with fields:
%                   % sections - Nx1 array of numeric section IDs
%                   % points - Nx3 array of x,y,z coordinates
%         markerStruct - structure of contour sets with fields:
%              % type - string
%              % points - Nx3 array of x,y,z coordinates

objTypes = {obj.type}; % get all data types in document
markerObjInds = find(strcmp(objTypes,'markers')); % find marker indices
contourObjInds = find(strcmp(objTypes,'contour')); % find contour indices

% initialize outputs
markerStruct = [];
contourStruct = [];
objStruct = [];

% pull out names of all contours in document and their associated points
for iContour = 1:length(contourObjInds)
    contourStruct(iContour).name = obj(contourObjInds(iContour)).name;
    contourStruct(iContour).points = obj(contourObjInds(iContour)).pts;
    contourStruct(iContour).sections = obj(contourObjInds(iContour)).sections;
    contourStruct(iContour).ptLines = obj(contourObjInds(iContour)).ptLines;
end

% group contours with same type into objects
objStruct = [];
allContourNames = unique({contourStruct.name});
for iObj = 1:length(allContourNames)
    name = allContourNames{iObj};
    objStruct(iObj).name = name;
    objContourInds = find(strcmp({contourStruct.name},name));
    for iContour=1:length(objContourInds)
        objStruct(iObj).contour(iContour) = contourStruct(objContourInds(iContour));
    end
end

for iMarker = 1:length(markerObjInds)
    markerStruct(iMarker).type = obj(markerObjInds(iMarker)).name;
    markerStruct(iMarker).points = obj(markerObjInds(iMarker)).pts;
    markerStruct(iMarker).sections = obj(markerObjInds(iMarker)).sections;
    markerStruct(iMarker).ptLines = obj(markerObjInds(iMarker)).ptLines;
end