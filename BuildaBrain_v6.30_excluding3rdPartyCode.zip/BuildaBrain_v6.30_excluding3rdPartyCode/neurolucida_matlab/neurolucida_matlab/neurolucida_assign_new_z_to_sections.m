function [objStructNew, markerStructNew] = neurolucida_assign_new_z_to_sections(objStruct,markerStruct,sectionNums,newZs, add2currentZ, newSectionNums)

objStructNew = objStruct;
markerStructNew = markerStruct;

if nargin<5; add2currentZ = 0; end
if nargin<6; newSectionNums = sectionNums; end

% get number of contours and markers
numMarkers = size(markerStruct,2);
numObjs = size(objStruct,2);


for iSection = 1:length(sectionNums)
    for iObj = 1:numObjs
        numContours = size(objStruct(iObj).contour,2);
        for iContour = 1:numContours
            sections = objStruct(iObj).contour(iContour).sections;
            currentSectionInds = find(sections == sectionNums(iSection) );
            currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
            if ~isempty(currentSectionPts)
                zc = currentSectionPts(:,3);
                if add2currentZ
                    zcm = zc + ones(size(zc))*newZs(iSection);
                else
                    zcm = ones(size(zc))*newZs(iSection);
                end
                objStructNew(iObj).contour(iContour).points(currentSectionInds,3) = zcm;
                %figure(2);
                %hold on;
                %plot(xc,yc,'b.',xcm,ycm,'r.');axis equal;
            end
            objStructNew(iObj).contour(iContour).sections(currentSectionInds) = ones(size(currentSectionInds))*newSectionNums(iSection);
            1;
        end
    end
    for iMarker = 1:numMarkers
        sections = markerStruct(iMarker).sections;
        currentSectionInds = find(sections == sectionNums(iSection) );
        currentSectionPts = markerStruct(iMarker).points(currentSectionInds,:);
        if ~isempty(currentSectionPts)
            zp = currentSectionPts(:,3);
            if add2currentZ
                zpm = zp + ones(size(zp))*newZs(iSection);
            else
                zpm = ones(size(zp))*newZs(iSection);
            end
            markerStructNew(iMarker).points(currentSectionInds,3) = zpm;
            %plot(xp,yp,'b.',xpm,ypm,'r.')
        end
        markerStructNew(iMarker).sections(currentSectionInds) = ones(size(currentSectionInds))*newSectionNums(iSection);
    end

end
