function objStruct = neurolucida_addMeasure2NeurolucidaObjects(objStruct,serialSections,serialMeasures,interSectionInterval,scale)
% add contours contained in serial measures structure, created with
% serialStruct_measurePts

if isempty(serialMeasures); return; end; % don't do anything if no measures to add

newContourInds = find(strcmp({serialMeasures.type},'contour'));
for iNewContour = 1:length(newContourInds)
    name = serialMeasures(newContourInds(iNewContour)).name;
    newContourName = ['"',name,'"'];
    if any(strcmp({objStruct.name},newContourName))
        warning(['Contour set already contains a ',newContourName,' contour. Appending!']);
    end
    numObjs = size(objStruct,2);
    objStruct(numObjs+1).name = newContourName;
    numConts = size(serialMeasures(newContourInds(iNewContour)).shape,2);
    contNum = 0;
    for iSection = 1:numConts
        pts = serialMeasures(newContourInds(iNewContour)).shape(iSection).pts;
        section = serialMeasures(newContourInds(iNewContour)).shape(iSection).section;
        %scale_pts = pts*scale;
        %obsolete - use option below to correct for slide offsets if utilized
        % add offsets for slide referenced contours (JM 7/8/2019)
        if isfield(serialSections.thumb(section),'offset_pix') & isfield(serialSections,'xbounds_pix')
            scale_pts = [];
            scale_pts_0 = pts*scale;
            offset = serialSections.thumb(section).offset_pix;
            xshift_pix = serialSections.xbounds_pix(1);
            yshift_pix = serialSections.ybounds_pix(1);
            if ~isempty(scale_pts_0)
                scale_pts(:,1) = scale_pts_0(:,1) + (offset(1) - xshift_pix)*scale;
                scale_pts(:,2) = scale_pts_0(:,2) - (offset(2) - yshift_pix)*scale;
            end
        else
            scale_pts = pts*scale;    
        end
        % end slide referenced contour adjustment
        sp = size(scale_pts);
        sections = ones(sp(1),1)*section;
        pts3 = [scale_pts , (sections-1)*interSectionInterval];
        if ~any(any(isnan(pts)))
            objStruct(numObjs+1).contour(contNum+1).name = newContourName;
            objStruct(numObjs+1).contour(contNum+1).points = pts3;
            objStruct(numObjs+1).contour(contNum+1).sections = sections;
            objStruct(numObjs+1).contour(contNum+1).ptLines = [];
            contNum = contNum+1;
        end
    end
end
