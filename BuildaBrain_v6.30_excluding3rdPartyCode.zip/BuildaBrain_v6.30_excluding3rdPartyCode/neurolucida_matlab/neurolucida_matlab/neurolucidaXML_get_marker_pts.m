function [objStruct markerStruct contourStruct] = neurolucidaXML_get_marker_pts(theStruct);
% reads in data structure created by neurolucida and parsed from
% 'parseXML.m' and returns points, contour sets
%
% input:    theStruct - output of low level XML parser
%                        'neurolucida_parseXML.m'
% output: objStruct - structure of contour sets with fields:
%              % name - string
%              % contour - struct with fields:
%                   % sections - Nx1 array of numeric section IDs
%                   % points - Nx3 array of x,y,z coordinates
%         markerStruct - structure of contour sets with fields:
%              % type - string
%              % points - Nx3 array of x,y,z coordinates


objTypes = {theStruct.Children.Name}; % get all data types in document
markerObjInds = find(strcmp(objTypes,'marker')); % find marker indices
contourObjInds = find(strcmp(objTypes,'contour')); % find contour indices

% initialize outputs
markerStruct = [];
contourStruct = [];

% pull out names of all contours in document and their associated points
for iContour = 1:length(contourObjInds)
    nameind = find(strcmp({theStruct.Children(contourObjInds(iContour)).Attributes.Name},'name'));
    contourStruct(iContour).name = theStruct.Children(contourObjInds(iContour)).Attributes(nameind).Value;
    contourObjTypes = {theStruct.Children(contourObjInds(iContour)).Children.Name};
    contourPointObjInds = find(strcmp(contourObjTypes,'point'));
    sections = [];
    for iPoint = 1:length(contourPointObjInds)
        xind = find(strcmp({theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes.Name},'x'));
        yind = find(strcmp({theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes.Name},'y'));
        zind = find(strcmp({theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes.Name},'z'));
        contourStruct(iContour).points(iPoint,:) = str2double({theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes([xind,yind,zind]).Value});
        sectind = find(strcmp({theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes.Name},'sid'));
        sect = {theStruct.Children(contourObjInds(iContour)).Children(contourPointObjInds(iPoint)).Attributes(sectind).Value};
        if ~isempty(sect)
            sectmat = str2mat(sect);
            sectnum = str2num(sectmat(2:end));
        else
            sectnum = NaN;
        end
        sections = [sections ; sectnum ];
    end
    contourStruct(iContour).sections = sections;
end

% group contours with same type into objects
objStruct = [];
allContourNames = unique({contourStruct.name});
for iObj = 1:length(allContourNames)
    name = allContourNames(iObj);
    objStruct(iObj).name = name;
    objContourInds = find(strcmp({contourStruct.name},name));
    for iContour=1:length(objContourInds)
        objStruct(iObj).contour(iContour) = contourStruct(objContourInds(iContour));
    end
end

% pull out names of all markers in document and their associated points
for iMarker = 1:length(markerObjInds)
    typeind = find(strcmp({theStruct.Children(markerObjInds(iMarker)).Attributes.Name},'type'));
    markerStruct(iMarker).type = theStruct.Children(markerObjInds(iMarker)).Attributes(typeind).Value;
    markerObjTypes = {theStruct.Children(markerObjInds(iMarker)).Children.Name};
    markerPointObjInds = find(strcmp(markerObjTypes,'point'));
    sections = [];
    for iPoint = 1:length(markerPointObjInds)
        xind = find(strcmp({theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes.Name},'x'));
        yind = find(strcmp({theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes.Name},'y'));
        zind = find(strcmp({theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes.Name},'z'));
        markerStruct(iMarker).points(iPoint,:) = str2double({theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes([xind,yind,zind]).Value});
        sectind = find(strcmp({theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes.Name},'sid'));
        sect = {theStruct.Children(markerObjInds(iMarker)).Children(markerPointObjInds(iPoint)).Attributes(sectind).Value};
        if ~isempty(sect)
            sectmat = str2mat(sect);
            sectnum = str2num(sectmat(2:end));
        else
            sectnum = NaN;
        end
        sections = [sections ; sectnum ];
    end
    markerStruct(iMarker).sections = sections;
end


