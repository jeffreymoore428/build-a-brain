function neurolucida_scan2jp2_batch(params);

% converts files from slide scanner to jpeg2000
% applies conversion to selected files in input directory

% inputs: params.
%           inputDirectory - file path of input files (include ending '\')
%           outputDirectory - file path for output files, default - same as
%                               input (include ending '\')
%           fileType - 3 character extension of file type to process
%           filePrefix - string corresponding to first N characters of all
%                           files to be processed
%           fileExcludeString - string for which filenames that contain this
%                               string are excluded from processing


inputDirectory = params.inputDirectory;
outputDirectory = params.outputDirectory;
fileType = params.fileType;
filePrefix = params.filePrefix;
fileExcludeString = params.fileExcludeString;
flipx = params.flipx;
flipy = params.flipy;
channels = params.channels;
compressionQuality = params.compressionQuality;


if isempty(outputDirectory)
    outputDirectory = inputDirectory;
end
 
 % create file list
 curdir = pwd;
 cd(inputDirectory);
 fileList = ls([filePrefix,'*',fileType]);
 cd(curdir);
 
 if ~isdir(outputDirectory)
    error('JM: No output directory with name specified!');
 end
 
 for ifile = 1:size(fileList,1)
     currentFilename = strrep(fileList(ifile,:),' ','');
     isExcluded = strfind(currentFilename,fileExcludeString);
     if isempty(isExcluded)
         disp(['Converting file: ',currentFilename]);
         inputFilename = [inputDirectory,currentFilename];
         outputFilename = [outputDirectory,currentFilename(1:end-4),'_jp2.jp2'];
         neurolucida_scan2jp2(inputFilename,channels,flipx,flipy,compressionQuality, outputFilename);
     else
         disp(['Skipping file: ',currentFilename]);
     end
 end
         
         
         
 
 
 
 