function model3d =neurolucida_build_3d_model(objStruct, markerStruct, xydwn, zdwn);
        
% inputs:
%            objStruct, markerStruct -  outputs from function
%                                       'neurolucida_get marker_pts.m'
%            xydwn - structure downsampling in xy
%            zdwn - structure downsampling in z

if nargin<3;xydwn = [];end
if nargin<4;zdwn = [];end

if isempty(xydwn)
    xydwn = ones(size(plot_contours))*1;
end

if isempty(zdwn)
    zdwn = ones(size(plot_contours))*1;
end

% initialized model
model3d = [];

% add markers to model
model3d.markers = [];
for iMarker = 1:length(markerStruct)
    model3d.markers(iMarker).points = markerStruct(iMarker).points;
    model3d.markers(iMarker).name = markerStruct(iMarker).type;
end

% add structures
model3d.structures = [];
for iObj = 1:length(objStruct)
    [f,v,tnorm] = contours3d_get_objSurface(objStruct(iObj).contour,xydwn(iObj),zdwn(iObj));
    model3d.structures(iObj).faces = f;
    model3d.structures(iObj).vertices = v;
    model3d.structures(iObj).normals = tnorm;
    model3d.structures(iObj).name = objStruct(iObj).name;
end