function allSections = neurolucida_get_allSections(objStruct,markerStruct)

numObjs = size(objStruct,2);
allOrigObjSectionsNU = [];
for iObj = 1:numObjs
    allOrigObjSectionsNU = [allOrigObjSectionsNU ; vertcat(objStruct(iObj).contour.sections)];
end
allOrigObjSections = unique(allOrigObjSectionsNU);

if isfield(markerStruct,'sections')
    allOrigMarkerSections = unique(vertcat(markerStruct.sections));
else
    allOrigMarkerSections = [];
end
allSections = unique([allOrigObjSections ; allOrigMarkerSections ]);