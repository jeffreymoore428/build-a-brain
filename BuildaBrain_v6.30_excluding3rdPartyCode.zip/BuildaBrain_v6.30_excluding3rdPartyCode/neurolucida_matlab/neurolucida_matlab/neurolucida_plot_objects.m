function neurolucida_plot_objects(objStruct, markerStruct, plot_contours, plot_markers, plotZ);
% inputs:
%            objStruct, markerStruct -  outputs from function
%                                       'neurolucida_get marker_pts.m'
%            plot_contours - cell array of line types/colors to plot
%                            default: {'c:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'k:'}
%            plot_markers - cell array of marker types/colors to plot
%                            default: {'kx','b.','ro','gx','m.','co'};

if nargin<2
    markerStruct = [];
end

if nargin<3
    plot_contours = [];
end

if nargin<4
    plot_markers = [];
end

if nargin<5
    plotZ = 1;
end

% contours default colors
if isempty(plot_contours)
    contours = {'k:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'c:' ; 'y:' ; 'k:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'c:' ; 'y:' ; 'k:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'c:' ; 'y:' ; 'k:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'c:' ; 'y:' };
else
    contours = plot_contours;
end

% markers default types and colors
if isempty(plot_markers)
    pts = {'r.','b.','k.','g.','m.','c.','y.','r.','b.','k.','g.','m.','c.','y,','r.','b.','k.','g.','m.','c.','y.','r.','b.','k.','g.','m.','c.','y.'};
else
    pts = plot_markers;
end

% plot objects, markers
for iMarker = 1:length(markerStruct)
    %checkstop();
    if plotZ
        plot3(markerStruct(iMarker).points(:,1),markerStruct(iMarker).points(:,2),markerStruct(iMarker).points(:,3),pts{iMarker});
    else
        plot(markerStruct(iMarker).points(:,1),markerStruct(iMarker).points(:,2),pts{iMarker});
    end
    hold on;
end

% plot objects frame
for iObj = 1:length(objStruct)
    for iContour = 1:length(objStruct(iObj).contour)
        %checkstop();
        if ~isempty(objStruct(iObj).contour(iContour))
            if plotZ
                plot3(objStruct(iObj).contour(iContour).points(:,1),objStruct(iObj).contour(iContour).points(:,2),objStruct(iObj).contour(iContour).points(:,3),contours{iObj});
            else
                plot(objStruct(iObj).contour(iContour).points(:,1),objStruct(iObj).contour(iContour).points(:,2),contours{iObj});
            end
            hold on;
        end
    end
end
axis equal