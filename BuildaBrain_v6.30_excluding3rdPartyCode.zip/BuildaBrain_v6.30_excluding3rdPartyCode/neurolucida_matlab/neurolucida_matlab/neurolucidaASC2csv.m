function neurolucidaASC2csv(ASCFilename)
%convert ASC to BB CSV

% input:
% neurolucida or build-a-brain ascii file name w or without path

% outputs:
% CSV table with columns: Type (object ID), Slice (section), X, Y, Z, isPoint, isContour, contourID
% CSV legend with contour/marker names, isPoint, isContour, objectIDs

disp('Converting .ASC data...');

[pathstr,outname,ext] = fileparts(ASCFilename);
outext = '.csv';
outputDataName = ['BBdata_',[outname,ext],outext];
outputLegendName = ['BBnames_',[outname,ext],outext];

[objStruct markerStruct] = neurolucidaASC2mat(ASCFilename);
allSections = neurolucida_get_allSections(objStruct,markerStruct);

numMarkers = size(markerStruct,2);
numObjects = size(objStruct,2);

disp('Writing BB data (*.csv)...');



data = [];

for iSection = 1:length(allSections)
    curSection = allSections(iSection);
    % get markers
    markerMat = [];
    for i =1:numMarkers
        indes=find(markerStruct(i).sections==curSection);
        xyz = markerStruct(i).points(indes,:);
        markerMat = [markerMat ; [xyz ones(size(xyz,1),1)*i] ];
    end
    data = [data ; curSection*ones(size(markerMat,1),1) ones(size(markerMat,1),1) zeros(size(markerMat,1),1) markerMat zeros(size(markerMat,1),1)];
    
    % get contours
    contourMat = [];
    for h = 1:numObjects
        numContours = size(objStruct(h).contour,2);
        for i =1:numContours
            indes=find(objStruct(h).contour(i).sections==curSection);
            xyz = objStruct(h).contour(i).points(indes,:);
            contourMat = [contourMat ; [xyz (ones(size(xyz,1),1)*h + numMarkers) ones(size(xyz,1),1)*i] ];
        end
    end
    %iSection
    data = [data ; curSection*ones(size(contourMat,1),1) zeros(size(contourMat,1),1) ones(size(contourMat,1),1) contourMat];
end

% make data table
T = table;
T.Type = data(:,7);
T.Slice = data(:,1);
T.X = data(:,4);
T.Y = data(:,5);
T.Z = data(:,6);
T.isPoint = data(:,2);
T.isContour = data(:,3);
T.contourID = data(:,8);

writetable(T,outputDataName);

disp('Writing BB names table (*.csv) ...')

allObjectIDs = [1:size(objStruct,2) 1:size(markerStruct,2)]';

Names = table;
Names.objectNames = {objStruct.name markerStruct.type}';
Names.isPoint = [zeros(numObjects,1) ; ones(numMarkers,1)];
Names.isContour = [ones(numObjects,1) ; zeros(numMarkers,1)];
Names.Type = [ numMarkers+(1:numObjects) 1:numMarkers]';

writetable(Names,outputLegendName);

disp('Output files created!');
%