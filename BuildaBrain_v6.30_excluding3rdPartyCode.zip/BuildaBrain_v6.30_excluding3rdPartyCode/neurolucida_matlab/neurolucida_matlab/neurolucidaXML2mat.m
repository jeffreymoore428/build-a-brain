function [objStruct markerStruct contourStruct] = neurolucidaXML2mat(filename);
% input is XML file of neurolucida tracings

theStruct = neurolucidaXML_parse(filename); % low level XML parser
[objStruct markerStruct contourStruct] = neurolucidaXML_get_marker_pts(theStruct); % get objects (contours of each type) and markers
%neurolucida_plot_objects(objStruct, markerStruct); % plot
%neurolucida_mat2txt(filename,markerStruct,contourStruct); % output to simple text format