function contourPts = neurolucida_getSectionContourPts(objStruct,contourName,sectionNum)
% get avg z value for given section, by avg all z values for that section

contourPts = [];

for iObj = 1:size(objStruct,2)
    for iContour = 1:size(objStruct(iObj).contour,2)
        if strcmp(objStruct(iObj).contour(iContour).name,contourName)
            sections = objStruct(iObj).contour(iContour).sections;
            currentSectionInds = find(sections == sectionNum );
            currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
            if ~isempty(currentSectionPts)
                contourPts = [contourPts ; currentSectionPts];
            end
        end
    end
end
