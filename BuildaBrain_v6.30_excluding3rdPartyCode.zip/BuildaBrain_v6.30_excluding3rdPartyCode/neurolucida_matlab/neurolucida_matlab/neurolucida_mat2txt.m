function neurolucida_mat2txt(filename,markerStruct,contourStruct);
% write Neurolucida matlab structs to text format for atlas

filenameMod = [filename(1:end-4),'_simpleTxt.csv'];
delete(filenameMod);
fileID = fopen(filenameMod,'w');
strall = ['type',',','name',',','objid',',','x',',','y',',','z',',','section'];
fprintf(fileID,[strall,'\r\n']);


for iMarker = 1:size(markerStruct,2)
    type = 'marker';
    name = markerStruct(iMarker).type;
    objid = iMarker;
    for iPt = 1:size(markerStruct(iMarker).points,1)
        x = markerStruct(iMarker).points(iPt,1);
        y = markerStruct(iMarker).points(iPt,2);
        z = markerStruct(iMarker).points(iPt,3);
        s = markerStruct(iMarker).sections(iPt);
        strall = [type,',',name,',',num2str(objid),',',num2str(x),',',num2str(y),',',num2str(z),',',num2str(s)];
        fprintf(fileID,[strall,'\r\n']);
    end   
end

for iContour = 1:size(contourStruct,2)
    type = 'contour';
    name = contourStruct(iContour).name;
    objid = iContour;
    for iPt = 1:size(contourStruct(iContour).points,1)
        x = contourStruct(iContour).points(iPt,1);
        y = contourStruct(iContour).points(iPt,2);
        z = contourStruct(iContour).points(iPt,3);
        s = contourStruct(iContour).sections(iPt);
        strall = [type,',',name,',',num2str(objid),',',num2str(x),',',num2str(y),',',num2str(z),',',num2str(s)];
        fprintf(fileID,[strall,'\r\n']);
    end   
end

fclose(fileID);