function [objStructMerged, markerStructMerged] = neurolucida_append_2_datasets(objStructFixed,markerStructFixed,objStructMoving,markerStructMoving,interDistance,referenceContourFixed,referenceContourMoving,flattenedZ)

if nargin<6; referenceContourFixed = objStructFixed(1).name; end
if nargin<7; referenceContourMoving = objStructMoving(1).name; end
if nargin<8; flattenedZ=[]; end
add2currentZ = 1;

% get section numbers with reference contour
[sectionNumsFixed] = neurolucida_list_all_sectionNums_with_outline(objStructFixed, referenceContourFixed);
[sectionNumsMoving] = neurolucida_list_all_sectionNums_with_outline(objStructMoving, referenceContourMoving);

% get reference object numbers
refObjIndFixed = find(strcmp({objStructFixed.name},referenceContourFixed));
refObjIndMoving = find(strcmp({objStructMoving.name},referenceContourMoving));

% generate new section numbers for moving contours/markers
lastSectionFixed = max(sectionNumsFixed);
sectionNumsMoved = sectionNumsMoving + lastSectionFixed;

% find z values for last section
zcmin = [];
numContoursFixed = size(objStructFixed(refObjIndFixed).contour,2);
for iContour = 1:numContoursFixed
    sections = objStructFixed(refObjIndFixed).contour(iContour).sections;
    currentSectionInds = find(sections == lastSectionFixed );
    currentSectionPts = objStructFixed(refObjIndFixed).contour(iContour).points(currentSectionInds,:);
    zc = currentSectionPts(:,3);
    zcmin = [zcmin ; min(zc)];
end
if isempty(flattenedZ)
    newZshift = max(zcmin)+interDistance;
else
    newZshift = flattenedZ+interDistance;
end
newZs = newZshift*ones(size(sectionNumsMoving));

% move sections and z values
[objStructMoved, markerStructMoved] = neurolucida_assign_new_z_to_sections(objStructMoving,markerStructMoving,sectionNumsMoving, newZs, add2currentZ, sectionNumsMoved);
objStructMoved(refObjIndMoving).name = referenceContourFixed;

% merge data structures
[objStructMerged, markerStructMerged] = neurolucida_merge_2_datasets(objStructFixed,markerStructFixed,objStructMoved,markerStructMoved)

        
        