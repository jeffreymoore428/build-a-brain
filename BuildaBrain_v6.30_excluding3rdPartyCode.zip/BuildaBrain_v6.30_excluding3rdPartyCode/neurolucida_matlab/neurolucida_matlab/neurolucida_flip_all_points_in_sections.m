function [objStruct, markerStruct] = neurolucida_flip_all_points_in_sections(objStruct,markerStruct,sectionNums,flipLR,flipUD)

% get number of contours and objs
numMarkers = size(markerStruct,2);
numObjs = size(objStruct,2);


offsetX = zeros(size(sectionNums));
offsetY = zeros(size(sectionNums));

% flip points in section, section by section

for iSection = 1:length(sectionNums)
    for iObj = 1:numObjs
        numContours = size(objStruct(iObj).contour,2);
        for iContour = 1:numContours
            %checkstop();
            sections = objStruct(iObj).contour(iContour).sections;
            currentSectionInds = find(sections == sectionNums(iSection) );
            currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
            if ~isempty(currentSectionPts)
                xcm = currentSectionPts(:,1);ycm=currentSectionPts(:,2);
                if flipLR(iSection); xcm = -1*xcm + offsetX(iSection); end
                if flipUD(iSection); ycm = -1*ycm + offsetY(iSection); end
                objStruct(iObj).contour(iContour).points(currentSectionInds,[1 2]) = [xcm ycm];
                %figure(2);
                %hold on;
                %plot(xc,yc,'b.',xcm,ycm,'r.');axis equal;
            end
        end
    end
    for iMarker = 1:numMarkers
        sections = markerStruct(iMarker).sections;
        currentSectionInds = find(sections == sectionNums(iSection) );
        currentSectionPts = markerStruct(iMarker).points(currentSectionInds,:);
        if ~isempty(currentSectionPts)
            xpm = currentSectionPts(:,1);ypm=currentSectionPts(:,2);
            if flipLR(iSection); xpm = -1*xpm + offsetX(iSection); end
            if flipUD(iSection); ypm = -1*ypm + offsetY(iSection); end
            markerStruct(iMarker).points(currentSectionInds,[1 2]) = [xpm ypm];
            %plot(xp,yp,'b.',xpm,ypm,'r.')
        end
    end
    
end