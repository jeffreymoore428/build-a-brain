function [markerStructOut lines2remove] = neurolucida_mat_decimate(markerStructIn,markerName,dwn);

markerNum = find(strcmp({markerStructIn.type},markerName))
lines2remove = [];

markerStructOut = markerStructIn;

% decimate 3rd marker by factor of dwn
numpts = size(markerStructIn(markerNum).points,1);
inds = randperm(numpts); keepinds = inds(1:floor(numpts/dwn));
removeInds = setxor([1:numpts], keepinds);
markerStructOut(markerNum).points = markerStructIn(markerNum).points(keepinds,:);
if isfield(markerStructIn,'ptLines')
    markerStructOut(markerNum).ptLines = markerStructIn(markerNum).ptLines(keepinds);
    lines2remove = markerStructIn(markerNum).ptLines(removeInds);
end