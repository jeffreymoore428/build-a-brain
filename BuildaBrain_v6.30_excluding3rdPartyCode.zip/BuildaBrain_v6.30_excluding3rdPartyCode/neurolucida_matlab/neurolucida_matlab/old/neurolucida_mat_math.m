function [markerStruct objStruct contourStruct allLines2remove lines2modPts pts] = neurolucida_mat_math(markerStruct,objStruct,contourStruct);
% modify and remove points from neurolucida outputs, write lists of line
% numbers and points to modify/delete

% initialize outputs
allLines2remove = [];
lines2modPts = [];
pts = [];

% modify this function here to change computation on points

[markerStruct allLines2remove] = neurolucida_mat_downsample_markers_to_min(markerStruct);