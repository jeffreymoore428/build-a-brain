function [markerStruct allLines2remove] = neurolucida_mat_downsample_markers_to_min(markerStruct);
% downsample markers to the minimum number of points any individual marker
% has

numMarkers = size(markerStruct,2);
markerNames = {markerStruct.type};
for iMarker = 1:numMarkers
    markerSizes(iMarker) = size(markerStruct(iMarker).points,1);
end
decimate_factor = markerSizes/min(markerSizes);

allLines2remove = [];
for iMarker = 1:numMarkers
    [markerStruct lines2remove] = neurolucida_mat_decimate(markerStruct,markerNames{iMarker},decimate_factor(iMarker));
    allLines2remove = [allLines2remove lines2remove];
end