function [objStructAligned,markerStructAligned,alignmentStruct] = neurolucida_align_objects(objStruct, markerStruct, sectionOutlineName, manualCorrect)

%
alignmentStruct.isAligned = 1;
%for iMarker = 1:size(markerStruct,2);markerStruct(iMarker).isAligned = 1; end

% set defaults
if nargin<3; sectionOutlineName = objStruct.name{1}; end
if nargin<4; manualCorrect = 1; end

outlineObjInd = find(strcmp({objStruct.name},sectionOutlineName));
sectionOutlineSections = neurolucida_list_all_sectionNums_with_outline(objStruct, sectionOutlineName);

% align section by section, starting with lowest number
[sectionOutlineSectionsSorted sortinds] = sort(sectionOutlineSections,'ascend');
for iSection = 2:length(sectionOutlineSectionsSorted)
    checkstop();
    prevSection = sectionOutlineSectionsSorted(iSection-1);
    currentSection = sectionOutlineSectionsSorted(iSection);
    disp(['Aligning section ',num2str(currentSection),'/',num2str(length(sectionOutlineSectionsSorted))]);
    % get section outline of previous section
    fixedContour = objStruct(outlineObjInd).contour(sortinds(iSection-1)).points;
    % get section outline of current section
    movingContour = objStruct(outlineObjInd).contour(sortinds(iSection)).points;
    fixedContour_cmXY = mean(fixedContour(:,[1 2]));
    movingContour_cmXY = mean(movingContour(:,[1 2]));
    delta_cmXY = movingContour_cmXY - fixedContour_cmXY;
    movingContour_offset = [ movingContour(:,1)-delta_cmXY(1) , movingContour(:,2)-delta_cmXY(2) , movingContour(:,3) ];
    
    % perform the alignment
    [A polyPts isCorrected] = align_2_sections(fixedContour, movingContour_offset, manualCorrect);
    
    alignmentStruct.section(iSection).sectionNum = currentSection;
    alignmentStruct.section(iSection).referenceSection = prevSection;
    alignmentStruct.section(iSection).transform = A;
    alignmentStruct.section(iSection).manuallyCorrected = ~isempty(isCorrected);
    alignmentStruct.section(iSection).manualCorrectionPolygon = polyPts;
    
    % transform every point associated with current section!
    [objStruct, markerStruct] = neurolucida_tform_all_points_in_section(objStruct,markerStruct,currentSection,A,delta_cmXY);
    
end
        
objStructAligned = objStruct;
markerStructAligned = markerStruct;