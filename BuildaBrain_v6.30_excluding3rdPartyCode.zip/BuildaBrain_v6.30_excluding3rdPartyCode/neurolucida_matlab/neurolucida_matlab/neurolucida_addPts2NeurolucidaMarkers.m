function markerStructNew = neurolucida_addPts2NeurolucidaMarkers(markerStruct,pts3,sections,type)
% add colocalized marker set to markerStruct
if nargin<4
    type = 'FilledStar';
end

nchannels = size(markerStruct,2);
new_channel = nchannels+1;

markerStruct(new_channel).type = type;
markerStruct(new_channel).points = pts3;
markerStruct(new_channel).sections = sections;

if isfield(markerStruct(1),'isAligned')
    markerStruct(new_channel).isAligned = markerStruct(channel1).isAligned;
end

markerStructNew = markerStruct;