function objStructClosed = neurolucida_close_objects_surface(objStruct)

numObjs = 1:size(objStruct,2);

objStructClosed = objStruct;

for iObj = 1:numObjs
    allSections = neurolucida_get_allSections(objStruct(iObj),[]);
    minSection = min(allSections);
    maxSection = max(allSections);
    minContourNums = []; maxContourNums = [];
    allpoints = vertcat(objStruct(iObj).contour.points);
    zInterval = range(allpoints(:,3))/length(allSections);
    zSamp = zInterval*sqrt(length(allSections));
    for iCont = 1:size(objStruct(iObj).contour,2)
        if any(objStruct(iObj).contour(iCont).sections==minSection)
            z_sect = objStruct(iObj).contour(iCont).points(:,3);
            contWithInterior = fillContour(objStruct(iObj).contour(iCont).points,zSamp);
            objStructClosed(iObj).contour(iCont).points = [contWithInterior , ones(size(contWithInterior,1),1)*mean(z_sect)];
            objStructClosed(iObj).contour(iCont).sections = ones(size(contWithInterior,1),1)*minSection;
            objStructClosed(iObj).contour(iCont).ptLines = [];
        elseif any(objStruct(iObj).contour(iCont).sections==maxSection)
            z_sect = objStruct(iObj).contour(iCont).points(:,3);
            contWithInterior = fillContour(objStruct(iObj).contour(iCont).points,zSamp);
            objStructClosed(iObj).contour(iCont).points = [contWithInterior , ones(size(contWithInterior,1),1)*mean(z_sect)];
            objStructClosed(iObj).contour(iCont).sections = ones(size(contWithInterior,1),1)*maxSection;
            objStructClosed(iObj).contour(iCont).ptLines = [];
        end
    end
end

function filledContour = fillContour(points,dSpace)
xq = points(:,1);
yq = points(:,2);
xGrid = min(xq):dSpace:max(xq);
yGrid = min(yq):dSpace:max(yq);
for iGrid = 1:length(xGrid)
    for jGrid = 1:length(yGrid)
        gridpts( (iGrid-1)*length(xGrid) + jGrid , :) = [xGrid(iGrid), yGrid(jGrid)];
    end
end
in = inpolygon(gridpts(:,1),gridpts(:,2),xq,yq); % naming convention inverted
filledContour = gridpts(find(in),:);

function xyInterval = get_xyInterval(x,y)
for i=1:length(x);
    dist1To2 = sqrt((x(i)-x).^2 + (y(i)-y).^2);
    dist1To1 = dist1To2(dist1To2>0);
    minDist(i) = min(dist1To1);
end
xyInterval = mean(minDist);