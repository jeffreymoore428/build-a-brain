function neurolucida_plot_objects_surf(model3d, contour_colors, marker_colors, ...
            faceTransparency_contours, edgeTransparency_contours, dotTransparency_markers, size_markers, dotPlot)
% inputs:
%            objStruct, markerStruct -  outputs from function
%                                       'neurolucida_get marker_pts.m'
%            plot_contours - cell array of line types/colors to plot
%                            default: {'c:' ; 'm:' ; 'g:'; 'r:' ; 'b:' ; 'k:'}
%            plot_markers - cell array of marker types/colors to plot
%                            default: {'kx','b.','ro','gx','m.','co'};

if nargin<2;contour_colors = [];end
if nargin<3;marker_colors = [];end
if nargin<4;faceTransparency_contours = [];end
if nargin<5;edgeTransparency_contours = [];end
if nargin<6;dotTransparency_markers = [];end
if nargin<7;size_markers = [];end
if nargin<8;dotPlot = [];end

% contours default colors
if isempty(contour_colors)
    contour_colors = {'k' ; 'm' ; 'g'; 'r' ; 'b' ; 'c'};
end

% markers default types and colors
if isempty(marker_colors)
    marker_colors = {'r','b','k','g','m','c'};
end

if isempty(faceTransparency_contours)
    faceTransparency_contours = ones(size(plot_contours))*0.2;
end

if isempty(edgeTransparency_contours)
    edgeTransparency_contours = ones(size(plot_contours))*0.2;
end

if isempty(dotTransparency_markers)
    dotTransparency_markers = ones(size(plot_markers))*0.5;
end

if isempty(size_markers)
    size_markers = ones(size(plot_markers))*2;
end

% plot objects, markers
for iMarker = 1:size(model3d.markers,2)
    if dotTransparency_markers(iMarker)>=1
        plot3(model3d.markers(iMarker).points(:,1),model3d.markers(iMarker).points(:,2),model3d.markers(iMarker).points(:,3), ...
            [marker_colors{iMarker},'.'],'MarkerSize',size_markers(iMarker));
    else
        s = scatter3(model3d.markers(iMarker).points(:,1),model3d.markers(iMarker).points(:,2),model3d.markers(iMarker).points(:,3), ...
            marker_colors{iMarker},'filled','SizeData',size_markers(iMarker));
        alpha(s,dotTransparency_markers(iMarker));
    end
    hold on;
end

% plot objects frame
for iObj = 1:size(model3d.structures,2)
    cColor = contour_colors{iObj};
    f = model3d.structures(iObj).faces;
    v = model3d.structures(iObj).vertices;
    if ~dotPlot
        trisurf(f,v(:,1),v(:,2),v(:,3),'FaceColor',cColor, ...
            'FaceAlpha',faceTransparency_contours(iObj),'EdgeAlpha',edgeTransparency_contours(iObj));
    else
        sp = scatter3(v(:,1),v(:,2),v(:,3),cColor,'filled','SizeData',2);
        alpha(sp,edgeTransparency_contours(iObj));
    end
    hold on;
end
axis equal