function [objStruct markerStruct contourStruct NL_ASC_lines] = neurolucidaASC2mat(filename);
% input is ASC file of neurolucida tracings

disp('Converting from .ASC format. Any empty marker sets will be ommitted...');

[NL_ASC_obj NL_ASC_lines] = neurolucidaASC_parse(filename); % low level ASC parser
[objStruct markerStruct contourStruct] = neurolucidaASC_get_marker_pts(NL_ASC_obj); % get objects (contours of each type) and markers

% plot in MATLAB
%neurolucida_plot_objects(objStruct, markerStruct);

% write to csv
%neurolucida_mat2txt(filename,markerStruct,contourStruct); % output to simple text format