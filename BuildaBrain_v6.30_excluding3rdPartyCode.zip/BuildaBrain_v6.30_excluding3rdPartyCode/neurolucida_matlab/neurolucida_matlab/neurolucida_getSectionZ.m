function [zavg zstd] = neurolucida_getSectionZ(objStruct,sectionNum)
% get avg z value for given section, by avg all z values for that section

allZ = [];

for iObj = 1:size(objStruct,2)
    for iContour = 1:size(objStruct(iObj).contour,2)
        sections = objStruct(iObj).contour(iContour).sections;
        currentSectionInds = find(sections == sectionNum );
        currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
        if ~isempty(currentSectionPts)
            zc = currentSectionPts(:,3);
            allZ = [ allZ ; zc ];
        end
    end
end

zavg = mean(allZ);
zstd = std(allZ);
