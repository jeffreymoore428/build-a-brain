function neurolucida_listContoursMarkers(objStruct,markerStruct)
% display names of contours and markers

nContours = size(objStruct,2);
disp(['Dataset contains ',num2str(nContours),' contours with names:']);
if isfield(objStruct,'name')
    disp({objStruct.name}');
end

nMarkers = size(markerStruct,2);
disp(['Dataset contains ',num2str(nMarkers),' markers with types:']);
if isfield(markerStruct,'type')
    disp({markerStruct.type}');
end