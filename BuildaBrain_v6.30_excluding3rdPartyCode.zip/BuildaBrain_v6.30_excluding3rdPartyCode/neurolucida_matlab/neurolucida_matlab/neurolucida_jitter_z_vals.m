function [objStructJitter, markerStructJitter] = neurolucida_jitter_z_vals(objStruct,markerStruct,interSectionDistance);

%markerStruct.isJittered = 1;
%objStruct.isJittered = 1;

% plot objects, markers
for iMarker = 1:length(markerStruct)
    origPts = markerStruct(iMarker).points(:,3);
    jitterPts = origPts + (rand(size(origPts))-0.5)*interSectionDistance;
    markerStruct(iMarker).points(:,3) = jitterPts;
end

% plot objects frame
for iObj = 1:size(objStruct,2)
    for iContour = 1:length(objStruct(iObj).contour)
        origPts = objStruct(iObj).contour(iContour).points(:,3);
        jitterPts = origPts + (rand(size(origPts))-0.5)*interSectionDistance;
        objStruct(iObj).contour(iContour).points(:,3) = jitterPts;
    end
end

objStructJitter = objStruct;
markerStructJitter = markerStruct;
