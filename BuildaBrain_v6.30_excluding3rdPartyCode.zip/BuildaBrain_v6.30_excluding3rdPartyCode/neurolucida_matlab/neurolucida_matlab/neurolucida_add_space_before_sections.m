function [objStructNew,markerStructNew] = neurolucida_add_space_before_sections(objStruct,markerStruct,sectionNums,zSpace)

add2currentZ = 1;
allSections = neurolucida_get_allSections(objStruct,markerStruct);

for iSpace = 1:length(sectionNums)
    sectionNums2move = allSections(allSections>=sectionNums(iSpace));
    newZs = ones(size(sectionNums2move))*zSpace;
    [objStruct, markerStruct] = neurolucida_assign_new_z_to_sections(objStruct,markerStruct,sectionNums2move,newZs, add2currentZ, sectionNums2move);
end

objStructNew = objStruct;
markerStructNew = markerStruct;