function markerStructEdit = neurolucida_removePtsInContours(objStruct,markerStruct,markerNums,names)
% remove points bounded by contours in cell array of contour names

if nargin<2
    names = {};
end

if isempty(names)
    names = {objStruct.name};
end

markerStructEdit = markerStruct;
for iObj = 1:size(names,2)
    %checkstop();
    disp(['Removing points from ',names{iObj},' ...']);
    markerStructEdit = neurolucida_removePtsInContour(objStruct,markerStructEdit,markerNums,names{iObj});
end
disp('Finished removing points in specified contours!');
