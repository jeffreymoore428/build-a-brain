function objStructInterp = neurolucida_interpContour(objStruct,contourName)

objStructInterp = objStruct;

allSections = neurolucida_get_allSections(objStruct,[]);
[sectionNums, sectionOutlineName] = neurolucida_list_all_sectionNums_with_outline(objStruct, contourName);
if isempty(sectionNums)
    disp(['No sections have contour ',contourName]);
    return;
end

sectionsInRange = min(sectionNums):max(sectionNums);
boundedSections = unique(intersect(allSections,sectionsInRange));
sections2interp = setdiff(boundedSections,sectionNums);

if isempty(sections2interp)
    disp(['No interpolation necessary for contour ',contourName,'. All bounded sections already have contour']);
    return;
end

for iObj = 1:size(objStruct,2)
    if strcmp(objStruct(iObj).name,contourName)
        for iSection = 1:length(sections2interp)
            disp(['Interpolating section ',num2str(sections2interp(iSection)),'...']); 
            % find nearest sections
            preSection = max(sectionNums(find(sectionNums<sections2interp(iSection))));
            postSection= min(sectionNums(find(sectionNums>sections2interp(iSection))));
            if preSection < postSection
                % get bounding section points
                prePts = neurolucida_getSectionContourPts(objStruct,contourName,preSection);
                postPts = neurolucida_getSectionContourPts(objStruct,contourName,postSection);
                % get z value for section to be interpolated
                zk = neurolucida_getSectionZ(objStruct,sections2interp(iSection));
                % do interpolation
                contourPtsProject = interpContourZ(prePts, postPts, zk);
                % add interpolated contour to expanded contour struct
                lastInd = size(objStructInterp(iObj).contour,2);
                objStructInterp(iObj).contour(lastInd+1).name = contourName;
                objStructInterp(iObj).contour(lastInd+1).points = contourPtsProject;
                objStructInterp(iObj).contour(lastInd+1).sections = ones(size(contourPtsProject,1),1)*sections2interp(iSection);
                objStructInterp(iObj).contour(lastInd+1).ptLines = [];
            end
        end
    end
end
disp('Sections interpolated!')
                    
        
    
    
    
    

