function [obj lines] = neurolucidaASC_parse(filename);

objStruct = [];
markerStruct = [];

fid = fopen(filename);

linecounter = 0;
while ~feof(fid)
    line = fgetl(fid);
    linecounter = linecounter+1;
    lines(linecounter).line = line;
end
fclose(fid);

for iline = 1:linecounter
    %checkstop();
    % read line 
    strall = lines(iline).line;
    % determine if line contains coords:
    % check if line is bracketed
    bracketstart = strfind(strall,'(');
    bracketend = strfind(strall,')');
    if ~isempty( bracketstart ) & isempty(bracketend)
        lines(iline).isName = 1;
        lines(iline).Name = strall((bracketstart(1)+1):end);
    else
        lines(iline).isName = 0;
    end
    if ~isempty( bracketstart ) & ~isempty(bracketend)
        % find bracketed text
        strBrackets = strall(bracketstart(1)+1:bracketend(1)-1);
        C = textscan(strBrackets,'%f');
        numPts = size(C{1},1);
        if numPts>3
            lines(iline).hasPoints = 1;
            lines(iline).coord = [C{1}(1) C{1}(2) C{1}(3)];
            strSectPos = strfind(strBrackets,'S');
            if ~isempty(strSectPos)
                S = textscan(strBrackets(strSectPos+1:end),'%f');
            else
                S{1} = NaN;
            end
            lines(iline).section = S{1};
        else
            lines(iline).hasPoints = 0;
        end
    else
        lines(iline).hasPoints = 0;
    end
    % determine if line is terminator
    terminatorStart = strfind(strall,'End of ');
    if ~isempty(terminatorStart)
        lines(iline).isTerminator = 1;
        lines(iline).TerminatorType = strall((terminatorStart+7):end);
    else
        lines(iline).isTerminator = 0;
    end
end

% place points into struct
obj.type = [];
obj.pts = [];
obj.name = [];
obj.sections = [];
% get all object terminators
termLines = find([lines.isTerminator]);
for iterm = 1:length(termLines)
    prevLine = termLines(iterm)-1;
    % if previous line contains numeric data
    if lines(prevLine).hasPoints 
        % place object type label in struct
        obj(iterm).type = lines(termLines(iterm)).TerminatorType;
        nameLines = find([lines(1:termLines(iterm)).isName]);
        lastNameLine = max(nameLines);
        obj(iterm).name = lines(lastNameLine).Name;
        % label contiguous sets of points prior to terminator
        [labels n] = bwlabeln([lines(1:termLines(iterm)).hasPoints]); 
        ptLines = find(labels==n);
        for iPt = 1:length(ptLines)
            obj(iterm).pts(iPt,:) = lines(ptLines(iPt)).coord;
            obj(iterm).sections(iPt,:) = lines(ptLines(iPt)).section;
            obj(iterm).ptLines(iPt) = ptLines(iPt);
        end
    end
end
        
    
    