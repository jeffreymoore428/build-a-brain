function [objStructMerge, markerStructMerge] = neurolucida_align_merge_2_structures(fixedObjStruct,fixedMarkerStruct,movingObjStruct,movingMarkerStruct,applyTform,manualCorrect,fixedContourName,movingContourName)
% aligns and merges 2 neurolucida tracing sets

if nargin<5; applyTform = []; end;
if nargin<6; manualCorrect = []; end;
if nargin<7; fixedContourName = fixedObjStruct.name{1}; end
if nargin<8; movingContourName = movingObjStruct.name{1}; end

alignedName = [movingContourName(1:end-1),'_align_to_',fixedContourName(2:end)];

fixedObjInd = find(strcmp({fixedObjStruct.name},fixedContourName));
movingObjInd = find(strcmp({movingObjStruct.name},movingContourName));
if length(fixedObjInd)>1
    warning('Multiple objects with same contour name found')
    fixedObjInd = fixedObjInd(1);
elseif isempty(fixedObjInd)
    error('contour name not found');
end

numFixedAlignContours = size(fixedObjStruct(fixedObjInd).contour,2);
numMovingAlignContours = size(movingObjStruct(movingObjInd).contour,2);

if numFixedAlignContours == numMovingAlignContours
    numAlignContours = numFixedAlignContours;
else
    error('Fixed and moving alignment objects must have same number of aligning contours')
end

% align objects, markers based on comparision of named contours
for iContour = 1:numAlignContours
    curSect = mode(fixedObjStruct(fixedObjInd).contour(iContour).sections);
    for iMovingContour = 1:numAlignContours
        checkstop();
        isMovingAlignmentContour = strcmp(movingObjStruct(movingObjInd).contour(iMovingContour).name,movingContourName);
        movingSect = mode(movingObjStruct(movingObjInd).contour(iMovingContour).sections);
        if isMovingAlignmentContour && (movingSect==curSect)
            if applyTform
                % get section outline of reference section
                fixedContour = fixedObjStruct(fixedObjInd).contour(iContour).points;
                % get section outline of current section
                movingContour = movingObjStruct(movingObjInd).contour(iMovingContour).points;
                fixedContour_cmXY = mean(fixedContour(:,[1 2]));
                movingContour_cmXY = mean(movingContour(:,[1 2]));
                delta_cmXY = movingContour_cmXY - fixedContour_cmXY;
                movingContour_offset = [ movingContour(:,1)-delta_cmXY(1) , movingContour(:,2)-delta_cmXY(2) , movingContour(:,3) ];
                % transform 2 sections
                [A polyPts isCorrected] = align_2_sections(fixedContour, movingContour_offset, manualCorrect);
                [movingObjStruct, movingMarkerStruct] = neurolucida_tform_all_points_in_section(movingObjStruct,movingMarkerStruct,movingSect,A,delta_cmXY);
            end
        end
    end
end

numMovingObjs = size(movingObjStruct,2);
% rename alignment contour  of moving contours
for iMovingObj = 1:numMovingObjs
    isMovingAlignmentName = strcmp(movingObjStruct(iMovingObj).name,movingContourName);
    if isMovingAlignmentName
        movingObjStruct(iMovingObj).name = alignedName;
    end
    numMovingContours = size(movingObjStruct(iMovingObj).contour,2)
    for iMovingContour = 1:numMovingContours;
        isMovingAlignmentContour = strcmp(movingObjStruct(iMovingObj).contour(iMovingContour).name,movingContourName);
        if isMovingAlignmentContour
            movingObjStruct(iMovingObj).contour(iMovingContour).name = alignedName;
        end
    end
end

% merge obects using merge function
[objStructMerge, markerStructMerge_doNotUse] = neurolucida_merge_2_datasets(fixedObjStruct,fixedMarkerStruct,movingObjStruct,movingMarkerStruct);

% always append markers
markerStructMerge = fixedMarkerStruct;
numMovingMarkers = size(movingMarkerStruct,2)
for iMovingMarker = 1:numMovingMarkers
    if isempty(markerStructMerge)
        clear markerStructMerge
        markerStructMerge(1) = movingMarkerStruct(iMovingMarker);
    else
        markerStructMerge(end+1) = movingMarkerStruct(iMovingMarker);
    end
end

% % merge objects - old 
% objStructMerge = fixedObjStruct;
% for iName = 1:length(movingObjStruct.name)
%     if strcmp(movingObjStruct.name{iName},movingContourName)
%         objStructMerge.name{end+1} = alignedName;
%     else
%         objStructMerge.name{end+1} = movingObjStruct.name{iName};
%     end
% end
% 
% for iMovingContour = 1:numMovingContours
%     objStructMerge.contour(end+1) = movingObjStruct.contour(iMovingContour);
% end
% 
% markerStructMerge = fixedMarkerStruct;
% numMovingMarkers = size(movingMarkerStruct,2)
% for iMovingMarker = 1:numMovingMarkers
%     markerStructMerge(end+1) = movingMarkerStruct(iMovingMarker);
% end
    

    