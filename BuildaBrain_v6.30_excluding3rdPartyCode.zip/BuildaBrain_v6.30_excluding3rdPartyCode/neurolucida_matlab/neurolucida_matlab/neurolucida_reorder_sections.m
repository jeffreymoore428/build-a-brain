function [objStructRO,markerStructRO] = neurolucida_reorder_sections(objStruct, markerStruct, sectionOrder, interSectionDistance)
% reorder, deletions allowed (untested)

if isempty(interSectionDistance)
    error('BB error, inter-section distance must be specified');
end

add2currentZ = 0;
newSectionNums = 1:length(sectionOrder);
newZs = (newSectionNums-1)*interSectionDistance;

if length(sectionOrder) ~= length(unique(sectionOrder))
    error('Section order vector must contain unique IDs');
end

allSections = neurolucida_get_allSections(objStruct,markerStruct);
sectionNums2remove = setdiff(allSections,sectionOrder);

[objStructInt, markerStructInt] = neurolucida_remove_objects_by_section(objStruct,markerStruct,sectionNums2remove);
[objStructRO, markerStructRO] = neurolucida_assign_new_z_to_sections(objStructInt,markerStructInt,sectionOrder,newZs, add2currentZ, newSectionNums);
