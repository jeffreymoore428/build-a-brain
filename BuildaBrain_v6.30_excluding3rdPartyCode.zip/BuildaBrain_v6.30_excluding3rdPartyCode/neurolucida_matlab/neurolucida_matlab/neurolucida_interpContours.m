function objStructInterp = neurolucida_interpContours(objStruct,names)
% interpolate contours in cell array of contour names
% by default, process all if no names provided

if nargin<2
    names = {};
end

if isempty(names)
    names = {objStruct.name};
end

objStructInterp = objStruct;
for iObj = 1:size(names,2)
    %checkstop();
    disp(['Interpolating ',names{iObj},' ...']);
    objStructInterp = neurolucida_interpContour(objStructInterp,names{iObj});
end
disp('Finished interpolating all contours!');
