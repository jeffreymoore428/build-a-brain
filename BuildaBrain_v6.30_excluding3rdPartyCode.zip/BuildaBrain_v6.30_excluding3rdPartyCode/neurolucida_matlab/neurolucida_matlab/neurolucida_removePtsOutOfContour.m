function markerStruct = neurolucida_removePtsOutOfContour(objStruct,markerStruct,markerNums,contourName)
% remove points in an array of marker ID numbers bounded by contour
% specified in contourName

disp('Removing points outside of specified contour...');

if isempty(contourName)
    error('BB error: must choose a contour');
end

[sectionNums] = neurolucida_list_all_sectionNums_with_outline(objStruct, contourName);

% remove points in sections that have designated contour
for iMarker = 1:length(markerNums)
    for iSection = 1:length(sectionNums)
        % get marker points in current section
        markerSectionInds = find(markerStruct(markerNums(iMarker)).sections == sectionNums(iSection));
        if ~isempty(markerSectionInds)
            markerPtsSection = markerStruct(markerNums(iMarker)).points(markerSectionInds,:);
        else
            markerPtsSection = [];
        end
        % get contour points in current section
        contourPtsSection = neurolucida_getSectionContourPts(objStruct,contourName,sectionNums(iSection));
        % remove points from markerstruct
        if ~isempty(markerPtsSection) & ~isempty(contourPtsSection)
            in = inpolygon(markerPtsSection(:,1),markerPtsSection(:,2),contourPtsSection(:,1),contourPtsSection(:,2));
            markerStruct(markerNums(iMarker)).sections(markerSectionInds(~in)) = [];
            markerStruct(markerNums(iMarker)).points(markerSectionInds(~in),:) = [];
        end
    end
end

% remove points from sections that dont have designamted contour
for iMarker = 1:length(markerNums)
    % find points in sections with designated contour
    allSections = markerStruct(markerNums(iMarker)).sections;
    ptsInContourSections = ismember(allSections,sectionNums);
    % remove points not in sections with designated contour
    markerStruct(markerNums(iMarker)).sections(~ptsInContourSections) = [];
    markerStruct(markerNums(iMarker)).points(~ptsInContourSections,:) = [];
end

disp('Finished removing points outside of specified contour!');
    
    
        
    
    
    