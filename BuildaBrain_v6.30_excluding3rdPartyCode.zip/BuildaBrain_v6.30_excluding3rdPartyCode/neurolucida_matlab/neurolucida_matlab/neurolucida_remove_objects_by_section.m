function [objStructNew, markerStructNew] = neurolucida_remove_objects_by_section(objStruct,markerStruct,sectionNums2remove)

% get number of objects and markers
numMarkers = size(markerStruct,2);
numObjs = size(objStruct,2);

% remove points with specified section numbers
for iSection = 1:length(sectionNums2remove)
    for iObj = 1:numObjs
        numContours = size(objStruct(iObj).contour,2);
        for iContour = 1:numContours
            sections = objStruct(iObj).contour(iContour).sections;
            currentSectionInds = find(sections == sectionNums2remove(iSection) );
            currentSectionPts = objStruct(iObj).contour(iContour).points(currentSectionInds,:);
            if ~isempty(currentSectionPts)
                objStruct(iObj).contour(iContour).points(currentSectionInds,:) = [];
                objStruct(iObj).contour(iContour).sections(currentSectionInds) = [];
            end
        end
    end
    for iMarker = 1:numMarkers
        sections = markerStruct(iMarker).sections;
        currentSectionInds = find(sections == sectionNums2remove(iSection) );
        currentSectionPts = markerStruct(iMarker).points(currentSectionInds,:);
        if ~isempty(currentSectionPts)
            markerStruct(iMarker).points(currentSectionInds,:) = [];
            markerStruct(iMarker).sections(currentSectionInds) = [];
        end       
    end
end

% create copy of objStruct and marker struct with empty elements removed
nextObj = 1;
objStructNew = [];
for iObj = 1:numObjs
    nextContour = 1;
    numContours = size(objStruct(iObj).contour,2);
    for iContour = 1:numContours
        if ~isempty(objStruct(iObj).contour(iContour).sections)
            objStructNew(nextObj).name = objStruct(iObj).name;
            objStructNew(nextObj).contour(nextContour).name = objStruct(iObj).contour(iContour).name;
            objStructNew(nextObj).contour(nextContour).points = objStruct(iObj).contour(iContour).points;
            objStructNew(nextObj).contour(nextContour).sections = objStruct(iObj).contour(iContour).sections;
            objStructNew(nextObj).contour(nextContour).ptLines = objStruct(iObj).contour(iContour).ptLines;
            nextContour = nextContour+1;
        end
    end
    if size(objStructNew,2) == nextObj % if added any contours to present object, object exists
        nextObj = nextObj+1;
    end
end

nextMarker = 1;
markerStructNew = [];
for iMarker = 1:numMarkers
    if ~isempty(markerStruct(iMarker).sections)
        markerStructNew(nextMarker).type = markerStruct(iMarker).type;
        markerStructNew(nextMarker).points = markerStruct(iMarker).points;
        markerStructNew(nextMarker).sections = markerStruct(iMarker).sections;
        markerStructNew(nextMarker).ptLines = markerStruct(iMarker).ptLines;
        nextMarker = nextMarker+1;
    end
end
        
        
        
