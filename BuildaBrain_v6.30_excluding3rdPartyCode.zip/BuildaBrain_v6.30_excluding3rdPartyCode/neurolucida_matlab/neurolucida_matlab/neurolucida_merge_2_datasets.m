function [objStructMerged, markerStructMerged] = neurolucida_merge_2_datasets(objStructFixed,markerStructFixed,objStructMoved,markerStructMoved)
% merge data structures

numObjsFixed = size(objStructFixed,2);
numObjsMoved = size(objStructMoved,2);

for iObjFixed = 1:numObjsFixed
    for jObjMoved = 1:numObjsMoved
        numContoursFixed = size(objStructFixed(iObjFixed).contour,2);
        numContoursMoved = size(objStructMoved(jObjMoved).contour,2);
        if strcmp(objStructFixed(iObjFixed).name,objStructMoved(jObjMoved).name)
            for iContourMoved = 1:numContoursMoved
                objStructFixed(iObjFixed).contour(numContoursFixed + iContourMoved).name = objStructMoved(jObjMoved).contour(iContourMoved).name;
                objStructFixed(iObjFixed).contour(numContoursFixed + iContourMoved).points = objStructMoved(jObjMoved).contour(iContourMoved).points;
                objStructFixed(iObjFixed).contour(numContoursFixed + iContourMoved).sections = objStructMoved(jObjMoved).contour(iContourMoved).sections;
                objStructFixed(iObjFixed).contour(numContoursFixed + iContourMoved).ptLines = objStructMoved(jObjMoved).contour(iContourMoved).ptLines;
            end
        elseif ~any(strcmp({objStructFixed.name},objStructMoved(jObjMoved).name))
            newNumObjsFixed = size(objStructFixed,2);
            objStructFixed(newNumObjsFixed+1).name = objStructMoved(jObjMoved).name;
            for iContourMoved = 1:numContoursMoved
                objStructFixed(newNumObjsFixed+1).contour(iContourMoved).name = objStructMoved(jObjMoved).contour(iContourMoved).name;
                objStructFixed(newNumObjsFixed+1).contour(iContourMoved).points = objStructMoved(jObjMoved).contour(iContourMoved).points;
                objStructFixed(newNumObjsFixed+1).contour(iContourMoved).sections = objStructMoved(jObjMoved).contour(iContourMoved).sections;
                objStructFixed(newNumObjsFixed+1).contour(iContourMoved).ptLines = objStructMoved(jObjMoved).contour(iContourMoved).ptLines;
            end
        end
    end
end

numMarkersFixed = size(markerStructFixed,2);
numMarkersMoved = size(markerStructMoved,2);
for jMarkerMoved = 1:numMarkersMoved
    curMovedType = markerStructMoved(jMarkerMoved).type;
    curMovedPts = markerStructMoved(jMarkerMoved).points;
    curMovedSections = markerStructMoved(jMarkerMoved).sections;
    curMovedPtLines = markerStructMoved(jMarkerMoved).ptLines;
    isAlreadyMarker = 0;
    for iMarkerFixed = 1:numMarkersFixed
        if strcmp(markerStructFixed(iMarkerFixed).type,curMovedType)
            isAlreadyMarker = 1;
            curFixedPts = markerStructFixed(iMarkerFixed).points;
            curFixedSections = markerStructFixed(iMarkerFixed).sections;
            curFixedPtLines = markerStructFixed(iMarkerFixed).ptLines;
            markerStructFixed(iMarkerFixed).points = [curFixedPts ; curMovedPts ];
            markerStructFixed(iMarkerFixed).sections = [curFixedSections ; curMovedSections ];
            markerStructFixed(iMarkerFixed).ptLines = [curFixedPtLines , curMovedPtLines ];
            break;
        end
    end
    if ~isAlreadyMarker
        newNumMarkersFixed = size(markerStructFixed,2);
        markerStructFixed(newNumMarkersFixed + 1).type = curMovedType;
        markerStructFixed(newNumMarkersFixed + 1).points = curMovedPts;
        markerStructFixed(newNumMarkersFixed + 1).sections = curMovedSections;
        markerStructFixed(newNumMarkersFixed + 1).ptLines = curMovedPtLines;
    end
end
objStructMerged = objStructFixed;
markerStructMerged = markerStructFixed;
