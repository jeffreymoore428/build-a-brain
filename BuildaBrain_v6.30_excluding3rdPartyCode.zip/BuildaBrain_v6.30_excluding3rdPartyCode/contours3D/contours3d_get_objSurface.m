function [f,v,tnorm] = contours3d_get_objSurface(contours,xydwn,zdwn)

% downsample params
if nargin<2
    xydwn = 1;
end
if nargin<3
    zdwn = 1;
end

% concat contours - make contou by contour in future release
vall=[];
% for downsampling
if zdwn>=1
    % downsample
    for i=1:zdwn:length(contours);
        vall = [vall;contours(i).points(1:xydwn:end,:)];
    end
elseif zdwn<1 & zdwn>0
    % upsample
    numInterpPlanes = round(1./zdwn);
    for i=1:(length(contours)-1);
        vall = [vall;contours(i).points(1:xydwn:end,:)]; % add contour i, for i=1:N-1
        contour1 = contours(i).points(1:xydwn:end,:);
        contour2 = contours(i+1).points(1:xydwn:end,:);
        zstart = mean(contours(i).points(1:xydwn:end,3));
        zend = mean(contours(i+1).points(1:xydwn:end,3));
        zks = linspace(zstart,zend,numInterpPlanes)
        for iz = 2:(length(zks)-1) % intervening contours, not including endpoints
            [projectContour] = interpContourZ(contour1, contour2, zks(iz));
            vall = [vall;projectContour(1:xydwn:end,:)]; % add intervening contours
        end
    end
    vall = [vall;contours(end).points(1:xydwn:end,:)]; % add contour N
    %plot3(vall(:,1),vall(:,2),vall(:,3));
else
    error('BB error: z_downsampling value invalid')
end


v = unique(vall,'rows');
[f,tnorm]=MyRobustCrust(v);

%% smooting functions
% node = v; face = f;
% n1=node;
% n1=sms(n1,face(:,1:3),1,0.99); % apply Laplacian+HC mesh smoothing
% plotmesh(n1,face(:,1:3));axis equal
% 
% conn=meshconn(face(:,1:3),size(node,1));
% n1=node;
% n1=smoothsurf(n1,[],conn,1,0.5,'lowpass');
% plotmesh(n1,face(:,1:3));
% axis equal;

