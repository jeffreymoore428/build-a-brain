function BB_model_2_stl;
% write 3D model outputs

disp('Select model file...');
[FileName,PathName,FilterIndex] = uigetfile('model3d*.mat','Please select BB data "model3d" .mat file');
load([PathName,FileName]);

numStructs = size(model3d.structures,2);
numMarkers = size(model3d.markers,2);
disp('Writing 3D file formats: .stl, .ply ...');
for iS = 1:numStructs
    stlwriteMFE([FileName,'_',model3d.structures(iS).name(2:end-1),'.stl'],model3d.structures(iS).faces,model3d.structures(iS).vertices,'MODE','ascii');
    ptCloud = pointCloud(model3d.structures(iS).vertices);
    pcwrite(ptCloud,[FileName,'_',model3d.structures(iS).name(2:end-1),'.ply'],'PLYFormat','ascii');
end

for iM = 1:numMarkers
    ptCloud = pointCloud(model3d.markers(iM).points);
    pcwrite(ptCloud,[FileName,'_',model3d.markers(iM).name,'.ply'],'PLYFormat','ascii');
end
disp('Wrote 3D files!');
    