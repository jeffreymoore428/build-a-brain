function [f,v] = neurolucida_get_objSurface(contours,xydwn,zdwn)

% downsample params
if nargin<2
    xydwn = 1;
end
if nargin<3
    zdwn = 1;
end

% concat contours - make contou by contour in future release
vall=[];
for i=1:zdwn:length(contours);
    vall = [vall;contours(i).points(1:xydwn:end,:)];
end

v = unique(vall,'rows');
[f,tnorm]=MyRobustCrust(v);

%% smooting functions
% node = v; face = f;
% n1=node;
% n1=sms(n1,face(:,1:3),1,0.99); % apply Laplacian+HC mesh smoothing
% plotmesh(n1,face(:,1:3));axis equal
% 
% conn=meshconn(face(:,1:3),size(node,1));
% n1=node;
% n1=smoothsurf(n1,[],conn,1,0.5,'lowpass');
% plotmesh(n1,face(:,1:3));
% axis equal;

