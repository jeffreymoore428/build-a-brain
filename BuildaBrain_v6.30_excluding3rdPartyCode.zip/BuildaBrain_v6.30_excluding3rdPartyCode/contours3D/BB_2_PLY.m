function BB_2_PLY;

[FileName,PathName,FilterIndex] = uigetfile('*.csv','Please select BB data .csv file');
T = readtable([PathName,FileName]);

typeNums = unique(T.Type);
for iType = 1:length(typeNums)
    typeNum = typeNums(iType);
    myType = find(T.Type==typeNum);
    myPts = [T.X(myType) T.Y(myType) T.Z(myType)];
    ptCloud = pointCloud(myPts);
    pcwrite(ptCloud,[FileName,'_',num2str(typeNum)],'PLYFormat','ascii');
end