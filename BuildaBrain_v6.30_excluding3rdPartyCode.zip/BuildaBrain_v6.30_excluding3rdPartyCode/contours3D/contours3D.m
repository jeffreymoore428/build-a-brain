function varargout = contours3D(varargin)
% CONTOURS3D MATLAB code for contours3D.fig
%      CONTOURS3D, by itself, creates a new CONTOURS3D or raises the existing
%      singleton*.
%
%      H = CONTOURS3D returns the handle to a new CONTOURS3D or the handle to
%      the existing singleton*.
%
%      CONTOURS3D('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CONTOURS3D.M with the given input arguments.
%
%      CONTOURS3D('Property','Value',...) creates a new CONTOURS3D or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before contours3D_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to contours3D_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help contours3D

% Last Modified by GUIDE v2.5 10-Dec-2020 00:14:18

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @contours3D_OpeningFcn, ...
                   'gui_OutputFcn',  @contours3D_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before contours3D is made visible.
function contours3D_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to contours3D (see VARARGIN)

% Choose default command line output for contours3D
handles.output = hObject;

% Update handles structure
imshow('logo.png');
set(handles.axes1,'HandleVisibility','off');
guidata(hObject, handles);

global stopAnimation recordAnimation;
stopAnimation = 0;
recordAnimation = 0;

% UIWAIT makes contours3D wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = contours3D_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadData.
function loadData_Callback(hObject, eventdata, handles)
[FileName,PathName,FilterIndex] = uigetfile('*.ASC','Select contours file ASC');
disp('Loading data...');
if ~FileName
    disp('No file loaded');
    return;
end

% load data
handles.filename_val = [PathName,FileName];
set(handles.filename,'String',handles.filename_val);
[objStruct, markerStruct] = neurolucidaASC2mat(handles.filename_val);
handles.objStruct = objStruct;
handles.markerStruct = markerStruct;
handles.cap_val = 0;
set(handles.cap,'Value',handles.cap_val);
handles.ptCloud_val = 0;
set(handles.ptCloud,'Value',handles.ptCloud_val);

% set animation filename
handles.movieFilename_val = ['movie_',FileName];
handles.model3dFilename_val = ['model3d_',FileName];
set(handles.movieFilename,'String',handles.movieFilename_val);
set(handles.model3dFilename,'String',handles.model3dFilename_val);
guidata(hObject,handles);

% get contour, marker names
handles.all_structures_val = {objStruct.name};
set(handles.structures,'String',handles.all_structures_val);
handles.all_markers_val = {markerStruct.type};
set(handles.Markers,'String',handles.all_markers_val);

% set rendering parameters
numContours = size(objStruct,2);
numMarkers = size(markerStruct,2);
for iContour = 1:numContours
    handles.plot_contours_list{iContour} = handles.contour_line_val;
    handles.xydwn_list(iContour) = handles.xydwn_val;
    handles.zdwn_list(iContour) = handles.zdwn_val;
    handles.faceTransparency_contours_list(iContour) = handles.surf_opaque_val;
    handles.edgeTransparency_contours_list(iContour) = handles.mesh_opaque_val;
end
for iMarker = 1:numMarkers
    handles.plot_markers_list{iMarker} = handles.mark_type_val;
    handles.dotTransparency_markers_list(iMarker) = handles.mark_opaque_val;
    handles.size_markers_list(iMarker) = handles.mark_size_val;
end

if numContours>0
    set(handles.structures,'Value',1);
    handles = structures_Callback(handles.structures, eventdata, handles);
end
if numMarkers>0
    set(handles.Markers,'Value',1);
    handles = Markers_Callback(handles.Markers, eventdata, handles);
end

guidata(hObject, handles);
disp('Data loaded!');


function filename_Callback(hObject, eventdata, handles)

% --- Executes during object creation, after setting all properties.
function filename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in structures.
function handles = structures_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
handles.selected_structure_ind = get(hObject,'Value');
disp([handles.objStruct(handles.selected_structure_ind).name,' structure selected!']);
% display current values for selected contour
set(handles.contour_line,'String',handles.plot_contours_list{handles.selected_structure_ind});
set(handles.xydwn,'String',num2str(handles.xydwn_list(handles.selected_structure_ind)));
set(handles.zdwn,'String',num2str(handles.zdwn_list(handles.selected_structure_ind)));
set(handles.mesh_opaque,'String',num2str(handles.edgeTransparency_contours_list(handles.selected_structure_ind)));
set(handles.surf_opaque,'String',num2str(handles.faceTransparency_contours_list(handles.selected_structure_ind)));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function structures_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on selection change in Markers.
function handles = Markers_Callback(hObject, eventdata, handles)
contents = cellstr(get(hObject,'String'));
handles.selected_marker_ind = get(hObject,'Value');
disp([handles.markerStruct(handles.selected_marker_ind).type,' marker selected!']);
% display current values for selected marker
set(handles.mark_type,'String',handles.plot_markers_list{handles.selected_marker_ind});
set(handles.mark_opaque,'String',num2str(handles.dotTransparency_markers_list(handles.selected_marker_ind)));
set(handles.mark_size,'String',num2str(handles.size_markers_list(handles.selected_marker_ind)));

guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function Markers_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function contour_line_Callback(hObject, eventdata, handles)
handles.contour_line_val = get(hObject,'String');
handles.plot_contours_list{handles.selected_structure_ind} = handles.contour_line_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function contour_line_CreateFcn(hObject, eventdata, handles)
handles.contour_line_val = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function xydwn_Callback(hObject, eventdata, handles)
handles.xydwn_val = str2num(get(hObject,'String'));
handles.xydwn_list(handles.selected_structure_ind) = handles.xydwn_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function xydwn_CreateFcn(hObject, eventdata, handles)
handles.xydwn_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function zdwn_Callback(hObject, eventdata, handles)
handles.zdwn_val = str2num(get(hObject,'String'));
handles.zdwn_list(handles.selected_structure_ind) = handles.zdwn_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function zdwn_CreateFcn(hObject, eventdata, handles)
handles.zdwn_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function mesh_opaque_Callback(hObject, eventdata, handles)
handles.mesh_opaque_val = str2num(get(hObject,'String'));
handles.edgeTransparency_contours_list(handles.selected_structure_ind) = handles.mesh_opaque_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mesh_opaque_CreateFcn(hObject, eventdata, handles)
handles.mesh_opaque_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function surf_opaque_Callback(hObject, eventdata, handles)
handles.surf_opaque_val = str2num(get(hObject,'String'));
handles.faceTransparency_contours_list(handles.selected_structure_ind) = handles.surf_opaque_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function surf_opaque_CreateFcn(hObject, eventdata, handles)
handles.surf_opaque_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function mark_type_Callback(hObject, eventdata, handles)
handles.mark_type_val = get(hObject,'String');
handles.plot_markers_list{handles.selected_marker_ind} = handles.mark_type_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mark_type_CreateFcn(hObject, eventdata, handles)
handles.mark_type_val = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function mark_opaque_Callback(hObject, eventdata, handles)
handles.mark_opaque_val = str2num(get(hObject,'String'));
handles.dotTransparency_markers_list(handles.selected_marker_ind) = handles.mark_opaque_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mark_opaque_CreateFcn(hObject, eventdata, handles)
handles.mark_opaque_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function mark_size_Callback(hObject, eventdata, handles)
handles.mark_size_val = str2num(get(hObject,'String'));
handles.size_markers_list(handles.selected_marker_ind) = handles.mark_size_val;
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mark_size_CreateFcn(hObject, eventdata, handles)
handles.mark_size_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function contour_jitter_Callback(hObject, eventdata, handles)
handles.contour_jitter_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function contour_jitter_CreateFcn(hObject, eventdata, handles)
handles.contour_jitter_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function mark_jitter_Callback(hObject, eventdata, handles)
handles.mark_jitter_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function mark_jitter_CreateFcn(hObject, eventdata, handles)
handles.mark_jitter_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in render.
function render_Callback(hObject, eventdata, handles)
disp('Rendering...');
markerStruct = handles.markerStruct;
objStruct = handles.objStruct;
[objStruct,junk] = neurolucida_jitter_z_vals(objStruct,markerStruct,handles.contour_jitter_val);
[junk, markerStruct] =  neurolucida_jitter_z_vals(objStruct,markerStruct,handles.mark_jitter_val);
if handles.cap_val % beta
    disp('Capping ends...')
    objStruct = neurolucida_close_objects_surface(objStruct);
end
disp('Building 3D model...');
model3d =neurolucida_build_3d_model(objStruct, markerStruct, handles.xydwn_list, handles.zdwn_list );
handles.model3d_val = model3d;
disp('Saving 3D model...');
save([handles.model3dFilename_val,'.mat'],'model3d','-v7.3');
disp('Done rendering!');
guidata(hObject, handles);

% --- Executes on button press in plot3d.
function plot3d_Callback(hObject, eventdata, handles)
handles.plotHandle = figure;
neurolucida_plot_objects_surf(handles.model3d_val, handles.plot_contours_list, handles.plot_markers_list, ...
                                handles.faceTransparency_contours_list, handles.edgeTransparency_contours_list, ...
                                handles.dotTransparency_markers_list, handles.size_markers_list, handles.ptCloud_val);
disp('Done plotting!');
guidata(hObject, handles);

% --- Executes on button press in plot.
function plot_Callback(hObject, eventdata, handles)
markerStruct = handles.markerStruct;
objStruct = handles.objStruct;
[objStruct,junk] = neurolucida_jitter_z_vals(objStruct,markerStruct,handles.contour_jitter_val);
[junk, markerStruct] =  neurolucida_jitter_z_vals(objStruct,markerStruct,handles.mark_jitter_val);
handles.plotHandle = figure;
neurolucida_plot_objects(objStruct, markerStruct);
guidata(hObject, handles);



function theta_Callback(hObject, eventdata, handles)
handles.theta_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes during object creation, after setting all properties.
function theta_CreateFcn(hObject, eventdata, handles)
handles.theta_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function phi_Callback(hObject, eventdata, handles)
handles.phi_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function phi_CreateFcn(hObject, eventdata, handles)
handles.phi_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function thetaSpeed_Callback(hObject, eventdata, handles)
handles.thetaSpeed_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function thetaSpeed_CreateFcn(hObject, eventdata, handles)
handles.thetaSpeed_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in Play.
function Play_Callback(hObject, eventdata, handles)
global stopAnimation recordAnimation;
stopAnimation = 0;

figure(handles.plotHandle);
cah = gca;

if handles.plotHandle.isvalid
    if isempty(handles.theta_val) || isempty(handles.phi_val);
        manualAngles = 1;
        viewAngles = cah.View;
        theta = viewAngles(1); phi = viewAngles(2);
        handles.theta_val = theta;
        handles.phi_val = phi;
        set(handles.theta,'String',num2str(handles.theta_val));
        set(handles.phi,'String',num2str(handles.phi_val));
        guidata(hObject,handles);
    else
        theta = handles.theta_val;
        phi = handles.phi_val;
        manualAngles = 0;
    end
else
    error('BB error: No figure to animate');
end

if recordAnimation
    v = VideoWriter([handles.movieFilename_val],'MPEG-4');
    v.Quality = 100;
    open(v);
    numIterations = 0;
end

while(stopAnimation == 0)
    if recordAnimation;
        disp('Recording...Please do not resize figure');
    else
        disp('Playing...');
    end
    if handles.plotHandle.isvalid
        figure(handles.plotHandle);
    else
        error('BB error: No figure to animate');
        break;
    end
    %theta = mod(theta,360); phi = mod(phi,360);
    view([theta phi]);
    axis equal;
    axis vis3d;
    axis off;
    pause(0.05);
    theta = theta + handles.thetaSpeed_val;
    phi = phi + handles.phiSpeed_val;
    if recordAnimation % maximum 1 full rotation
        dphi = numIterations * handles.thetaSpeed_val;
        dtheta = numIterations * handles.thetaSpeed_val;
        F = getframe(handles.plotHandle);
        writeVideo(v,F);
        numIterations = numIterations + 1;
        if abs(dtheta)>360 || abs(dphi)>360
            stopAnimation = 1;
        end
    end
end
if recordAnimation;
    close(v);
end
recordAnimation = 0;

if handles.plotHandle.isvalid
    figure(handles.plotHandle);
    axis normal;
    axis equal;
    axis on;
end

if manualAngles
    handles.theta_val = [];
    handles.phi_val = [];
    set(handles.theta,'String',num2str(handles.theta_val));
    set(handles.phi,'String',num2str(handles.phi_val));
end
guidata(hObject,handles);

% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
global stopAnimation;
stopAnimation = 1;

% --- Executes on button press in record.
function record_Callback(hObject, eventdata, handles)
global stopAnimation recordAnimation;
stopAnimation = 0; 
recordAnimation = 1;
Play_Callback(handles.Play, eventdata, handles);



function handles = movieFilename_Callback(hObject, eventdata, handles)
handles.movieFilename_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function movieFilename_CreateFcn(hObject, eventdata, handles)
handles.movieFilename_val = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function phiSpeed_Callback(hObject, eventdata, handles)
handles.phiSpeed_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function phiSpeed_CreateFcn(hObject, eventdata, handles)
handles.phiSpeed_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function model3dFilename_Callback(hObject, eventdata, handles)
handles.model3dFilename_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function model3dFilename_CreateFcn(hObject, eventdata, handles)
handles.model3dFilename_val = get(hObject,'String');
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cap.
function cap_Callback(hObject, eventdata, handles)
handles.cap_val = get(hObject,'Value');
guidata(hObject,handles);


% --- Executes on button press in ptCloud.
function ptCloud_Callback(hObject, eventdata, handles)
handles.ptCloud_val = get(hObject,'Value');
guidata(hObject,handles);


% --- Executes on button press in writeStl.
function writeStl_Callback(hObject, eventdata, handles)
BB_model_2_stl;
guidata(hObject,handles);
