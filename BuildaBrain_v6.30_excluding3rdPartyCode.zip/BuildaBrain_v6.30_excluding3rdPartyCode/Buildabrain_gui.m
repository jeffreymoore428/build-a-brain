function varargout = Buildabrain_gui(varargin)
% BUILDABRAIN_GUI MATLAB code for Buildabrain_gui.fig
%      BUILDABRAIN_GUI, by itself, creates a new BUILDABRAIN_GUI or raises the existing
%      singleton*.
%
%      H = BUILDABRAIN_GUI returns the handle to a new BUILDABRAIN_GUI or the handle to
%      the existing singleton*.
%
%      BUILDABRAIN_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in BUILDABRAIN_GUI.M with the given input arguments.
%
%      BUILDABRAIN_GUI('Property','Value',...) creates a new BUILDABRAIN_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Buildabrain_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Buildabrain_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Buildabrain_gui

% Last Modified by GUIDE v2.5 28-Jul-2021 13:34:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Buildabrain_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @Buildabrain_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Buildabrain_gui is made visible.
function Buildabrain_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Buildabrain_gui (see VARARGIN)

% Choose default command line output for Buildabrain_gui
handles.output = hObject;

% Update handles structure
imshow('logo.png');
set(handles.axes2,'HandleVisibility','off');
disp('Welcome to Build-a-Brain! Interactive instructions will be displayed in this window.')
disp('Version 6.20');
global STOP;
STOP = [];
guidata(hObject, handles);

% UIWAIT makes Buildabrain_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Buildabrain_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function sectionsFile_Callback(hObject, eventdata, handles)
set(hObject,'String',handles.sectionsFile_val);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function sectionsFile_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Browse_sectionsFile.
function Browse_sectionsFile_Callback(hObject, eventdata, handles)
[filename,filepath] = uigetfile('*.mat','Select serial sections file');
if ~filename
    disp('No file selected');
    return;
end
handles.sectionsFile_val = [filepath,filename];
disp('Loading serial sections file...');
S=load(handles.sectionsFile_val);
fs = fieldnames(S);
handles.serialSections = eval(['S(1).',fs{1}]);
if isfield(handles.serialSections,'isTransformed')
    handles.sectionsFile_val = [];
    handles.serialSections = [];
    errorFlag = 1;
else
    errorFlag = 0;
end
guidata(hObject,handles);
sectionsFile_Callback(handles.sectionsFile, eventdata, handles);
% set output file name
slashChar = getPathSlash(handles.sectionsFile_val);
fnSlash = strfind(handles.sectionsFile_val,slashChar);
if isempty(fnSlash)
    fnStart = 0;
else
    fnStart = fnSlash(end);
end
handles.contoursOutFilename_val = ['contours_',handles.sectionsFile_val(fnStart+1:end-4)];
set(handles.contoursOutFilename,'String',handles.contoursOutFilename_val);
guidata(hObject,handles);
if errorFlag
    error('BB error: sections already aligned, not possible to edit contours further!');
else
    disp('Serial sections file loaded!');
end

function secs2plot_Callback(hObject, eventdata, handles)
handles.secs2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2plot_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.secs2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes on button press in plotObjects.
function plotObjects_Callback(hObject, eventdata, handles)
figure;
msproc_plotBlobsInSerialStruct(handles.serialSections,handles.secs2plot_val);
disp('Done plotting sections!');

function imgDir_Callback(hObject, eventdata, handles)
set(hObject,'String',handles.imgDir_val);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function imgDir_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function imgType_Callback(hObject, eventdata, handles)
% hObject    handle to imgType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of imgType as text
%        str2double(get(hObject,'String')) returns contents of imgType as a double


% --- Executes during object creation, after setting all properties.
function imgType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to imgType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Browse_imgFiles.
function Browse_imgFiles_Callback(hObject, eventdata, handles)
[imgFilename_val, imgDir_val] = uigetfile('*.*','Select first image file, or txt file with filenames');
handles.imgDir_val = [imgDir_val];
if ~imgFilename_val
    disp('No file selected');
    return;
end
% get file type
dotInds = strfind(imgFilename_val,'.');
fileType = imgFilename_val(dotInds(end)+1:end);
isTxt = strcmp(fileType,'txt');
% set filename list
if isTxt
    handles.imgFilenames_val = imgFilename_val;
else
    handles.imgFilenames_val = ['{''',imgFilename_val,'''}'];
end
set(handles.imgFilenames,'String',handles.imgFilenames_val);
guidata(hObject, handles);
imgDir_Callback(handles.imgDir, eventdata, handles);
handles = imgFilenames_Callback(handles.imgFilenames,eventdata,handles);
handles = colocalize_chans_Callback(handles.add_coloc_marker, eventdata, handles);
maxProject_Callback(handles.maxProject, eventdata, handles);

function secs2correct_Callback(hObject, eventdata, handles)
handles.secs2correct_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2correct_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.secs2correct_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in correct_outlines.
function correct_outlines_Callback(hObject, eventdata, handles)
handles.serialSections = msproc_bf_manualRestrictCZISectionBoundary(handles.serialSections,handles.secs2correct_val);
disp('Done correcting outlines!');
fh=imgcf; close(fh);
guidata(hObject,handles);



function scaleFactor_Callback(hObject, eventdata, handles)
handles.scaleFactor_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function scaleFactor_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.scaleFactor_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function interSection_dist_Callback(hObject, eventdata, handles)
handles.interSection_dist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function interSection_dist_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.interSection_dist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);



function contoursOutFilename_Callback(hObject, eventdata, handles)
handles.contoursOutFilename_val = get(hObject,'String');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function contoursOutFilename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.contoursOutFilename_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes on button press in SaveSerialContours.
function SaveSerialContours_Callback(hObject, eventdata, handles)
% save serial sesctions struct
serialSections = handles.serialSections;
disp('Removing unbounded points...');
serialSections = msproc_serialStructRemoveUnboundedPts(serialSections);
disp('Saving...');
save([handles.contoursOutFilename_val,'.mat'],'serialSections','-v7.3');
% create neurolucida file
if isempty(handles.interSection_dist_val) || isempty(handles.scaleFactor_val)
    error('BB error: Please specify numeric values for scale and inter-section distance');
end
[objStruct markerStruct] = msproc_serialStruct2NeurolucidaStruct(serialSections,handles.interSection_dist_val,handles.scaleFactor_val,handles.zDist_val,1,handles.refContour_val);
neurolucidaASC_writefile([handles.contoursOutFilename_val],objStruct,markerStruct,handles.interSection_dist_val);
disp('Serial sections contours saved!');

% --- Executes on button press in saveSlideContours.
function saveSlideContours_Callback(hObject, eventdata, handles)
slide = handles.serialSections;
if strcmp(slide.type,'slide')
    if ~exist(slide.filepath)
        disp(['Slide image location: ',slide.filepath]);
        disp('Slide image cannot be found, please choose a new location where the image is stored');
        slide = msproc_bf_resetImagePath(slide);
    end
    disp('Calculating section positions on whole slide image...');
    slide = msproc_bf_setCZIImageOffsetsInSlide(slide);
    disp('Removing unbounded points...');
    slide = msproc_serialStructRemoveUnboundedPts(slide);
    disp('Saving...');
    save([handles.contoursOutFilename_val,'.mat'],'slide','-v7.3');
    % create neurolucida file
    if isempty(handles.interSection_dist_val) || isempty(handles.scaleFactor_val)
        error('BB error: Please specify numeric values for scale and inter-section distance');
    end
    [objStruct markerStruct] = msproc_serialStruct2NeurolucidaStruct(slide,handles.interSection_dist_val,handles.scaleFactor_val, handles.zDist_val,1,handles.refContour_val);
    neurolucidaASC_writefile([handles.contoursOutFilename_val],objStruct,markerStruct,handles.interSection_dist_val);
    disp('Slide contours saved!');
else
    error('Input file must be single slide image');
end



function contours_inputFilename_Callback(hObject, eventdata, handles)
set(hObject,'String',handles.contoursInputFilename_val);
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function contours_inputFilename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in browse_contourInput.
function browse_contourInput_Callback(hObject, eventdata, handles)
[filename,filepath] = uigetfile({'*.ASC';'*.xml'},'Select contours ".ASC" or ".xml"  file');
if ~filename
    disp('No file selected');
    return;
end
handles.contoursInputFilename_val = [filepath,filename];
disp('Loading contours file...');
if strcmp(filename(end-3:end),'.ASC')
    [objStruct markerStruct] = neurolucidaASC2mat(handles.contoursInputFilename_val);
elseif strcmp(filename(end-3:end),'.xml')
    [objStruct markerStruct] = neurolucidaXML2mat(handles.contoursInputFilename_val);
end
handles.objStruct = objStruct;
handles.markerStruct = markerStruct;
guidata(hObject,handles);
contours_inputFilename_Callback(handles.contours_inputFilename, eventdata, handles);
disp('Contours file loaded!');
handles.is3D_val = 1;
handles.jitterz_val = 0;
set(handles.is3D,'Value',handles.is3D_val);
set(handles.jitterz,'Value',handles.jitterz_val);
guidata(hObject,handles);
% set output file specs
slashChar = getPathSlash(handles.contoursInputFilename_val);
fnSlash = strfind(handles.contoursInputFilename_val,slashChar);
if isempty(fnSlash)
    fnStart = 0;
else
    fnStart = fnSlash(end);
end
handles.processedFilename_val = ['proc_',handles.contoursInputFilename_val(fnStart+1:end-4)];
set(handles.processedFilename,'String',handles.processedFilename_val);
guidata(hObject,handles)

% --- Executes on button press in jitterz.
function jitterz_Callback(hObject, eventdata, handles)
handles.jitterz_val = get(hObject,'Value');
guidata(hObject,handles);

% --- Executes on button press in plotContours.
function plotContours_Callback(hObject, eventdata, handles)
objStruct = handles.objStruct;
markerStruct = handles.markerStruct;
neurolucida_listContoursMarkers(objStruct,markerStruct);
if ~isempty(handles.conts2plot_val);
    allSections = neurolucida_get_allSections(objStruct,markerStruct);
    secs2remove = setdiff(allSections,handles.conts2plot_val)
    [objStruct,markerStruct] = neurolucida_remove_objects_by_section(objStruct,markerStruct,secs2remove);
end
if handles.jitterz_val
    [objStruct, markerStruct] = neurolucida_jitter_z_vals(objStruct,markerStruct,handles.interSection_dist_val);
end

figure;
if handles.is3D_val
    neurolucida_plot_objects(objStruct, markerStruct, [], [], handles.is3D_val);
else
    neurolucida_plot_objects_2D(objStruct,markerStruct);
%     allSections2Plot = neurolucida_get_allSections(objStruct,markerStruct);
%     numTiles = ceil(sqrt(length(allSections2Plot)));
%     for iPlot = 1:length(allSections2Plot)
%         disp(['Plotting section ',num2str(iPlot),'/',num2str(length(allSections2Plot))]);
%         tempSections2remove = setdiff(allSections2Plot,allSections2Plot(iPlot));
%         [objStructPlot,markerStructPlot] = neurolucida_remove_objects_by_section(objStruct,markerStruct,tempSections2remove);
%         subplot(numTiles,numTiles,iPlot);
%         neurolucida_plot_objects(objStructPlot, markerStructPlot, [], [], handles.is3D_val);
%     end
end

disp('Done plotting!');


% --- Executes on button press in flip.
function flip_Callback(hObject, eventdata, handles)
sectionNums = [handles.secs2flip_val , handles.secs2flipUD_val];
flipLR = [ones(size( handles.secs2flip_val )) zeros(size(handles.secs2flipUD_val)) ];
flipUD = [zeros(size( handles.secs2flip_val )) ones(size(handles.secs2flipUD_val)) ];
[objStruct, markerStruct] = neurolucida_flip_all_points_in_sections(handles.objStruct,handles.markerStruct,sectionNums,flipLR,flipUD);
handles.objStruct = objStruct;
handles.markerStruct = markerStruct;
guidata(hObject,handles);
disp('Done flipping sections!');



% --- Executes on button press in reorder.
function reorder_Callback(hObject, eventdata, handles)
[objStructRO,markerStructRO] = neurolucida_reorder_sections(handles.objStruct, handles.markerStruct, handles.newOrder_val, handles.interSection_dist_val)
handles.objStruct = objStructRO;
handles.markerStruct = markerStructRO;
guidata(hObject,handles);
disp('Done re-ordering sections!');

% --- Executes on button press in align.
function align_Callback(hObject, eventdata, handles)
manualCorrect = 1;
halign = figure;
[objStructAligned,markerStructAligned] = neurolucida_align_objects(handles.objStruct, handles.markerStruct, handles.refContour_val, manualCorrect);
handles.objStruct = objStructAligned;
handles.markerStruct = markerStructAligned;
guidata(hObject,handles);
close(halign);
disp('Done aligning sections!');

function secs2flip_Callback(hObject, eventdata, handles)
handles.secs2flip_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function secs2flip_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.secs2flip_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

function newOrder_Callback(hObject, eventdata, handles)
handles.newOrder_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function newOrder_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.newOrder_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function refContour_Callback(hObject, eventdata, handles)
handles.refContour_val = get(hObject,'String');
handles.refContour_val = ['"',handles.refContour_val,'"']; % v6 add quotes
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function refContour_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.refContour_val = get(hObject,'String');
handles.refContour_val = ['"',handles.refContour_val,'"']; % v6 add quotes
guidata(hObject,handles);



function flipUD_Callback(hObject, eventdata, handles)
handles.secs2flipUD_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function flipUD_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.secs2flipUD_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes on button press in saveProcessed.
function saveProcessed_Callback(hObject, eventdata, handles)
disp('Saving sections contours...');
neurolucidaASC_writefile([handles.processedFilename_val],handles.objStruct,handles.markerStruct,handles.interSection_dist_val);
disp('Serial sections contours saved!');


function processedFilename_Callback(hObject, eventdata, handles)
handles.processedFilename_val = get(hObject,'String');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function processedFilename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.processedFilename_val = get(hObject,'String');
guidata(hObject,handles);



function mergeFilenames_Callback(hObject, eventdata, handles)
handles.alignMerger_val = get(handles.alignMergedSections,'Value');
handles.alignSlab_val = get(handles.alignSlab,'Value');
handles.mergeAffine_val = get(handles.mergeAffine,'Value');
handles.mergeFilenames_val = get(hObject,'String');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function mergeFilenames_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.mergeFilenames_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes on button press in merge.
function merge_Callback(hObject, eventdata, handles)
disp('Merging data...');
alignMergedSections_Callback(handles.alignMergedSections, eventdata, handles);
guidata(hObject,handles);
alignSlab_Callback(handles.alignSlab, eventdata, handles);
guidata(hObject,handles);
mergeAffine_Callback(handles.mergeAffine, eventdata, handles);
guidata(hObject,handles);
mergeAffineAuto_Callback(handles.mergeAffine, eventdata, handles);
guidata(hObject,handles);
if handles.alignMerger_val
    applyTform = 1;
else
    applyTform = 0;
end

manualCorrect = 1;
fixedObjStruct = handles.objStruct;
fixedMarkerStruct = handles.markerStruct;

fnames = eval(handles.mergeFilenames_val);
hmerge = figure;
mergeSlabs = handles.alignSlab_val;
mergeAffine = handles.mergeAffine_val;
mergeAffineAuto = handles.mergeAffineAuto_val;
for imerge = 1:size(fnames,1)
    [movingObjStruct,movingMarkerStruct] = neurolucidaASC2mat([fnames{imerge}]);
    if mergeSlabs
        if handles.alignMerger_val | mergeAffineAuto | mergeAffine
            error('BB error: Must select either manual or auto, rigid or affine alignment');
        end
        [objStructMerge, markerStructMerge] = neurolucida_fit_to_reference_slab_ctrlpts(movingObjStruct,movingMarkerStruct,fixedObjStruct,fixedMarkerStruct,handles.refContour_val);
    elseif mergeAffine
        if handles.alignMerger_val | mergeAffineAuto
            error('BB error: Must select either manual or auto, rigid or affine alignment');
        end
        [objStructMerge, markerStructMerge] = neurolucida_align_merge_2_structures_ctrlpts(movingObjStruct,movingMarkerStruct,fixedObjStruct,fixedMarkerStruct,handles.refContour_val);
    elseif mergeAffineAuto
        if handles.alignMerger_val | mergeAffine
            error('BB error: Must select either manual or auto, rigid or affine alignment');
        end
        [objStructMerge, markerStructMerge] = neurolucida_align_merge_2_structures_autoAffine(movingObjStruct,movingMarkerStruct,fixedObjStruct,fixedMarkerStruct,handles.refContour_val);
    else 
        [objStructMerge, markerStructMerge] = neurolucida_align_merge_2_structures(fixedObjStruct,fixedMarkerStruct,movingObjStruct,movingMarkerStruct,applyTform,manualCorrect,handles.refContour_val,handles.refContour_val);
    end
    
    fixedObjStruct = objStructMerge;
    fixedMarkerStruct = markerStructMerge;
end
handles.objStruct = objStructMerge;
handles.markerStruct = markerStructMerge;
guidata(hObject,handles);
disp('Data merged!');
close(hmerge);

% --- Executes on button press in append.
function append_Callback(hObject, eventdata, handles)
disp('Appending data...');
fixedObjStruct = handles.objStruct;
fixedMarkerStruct = handles.markerStruct;

fnames = eval(handles.mergeFilenames_val);
for imerge = 1:size(fnames,1)
    [movingObjStruct,movingMarkerStruct] = neurolucidaASC2mat([fnames{imerge}]);
    [objStructMerge, markerStructMerge] = neurolucida_append_2_datasets(fixedObjStruct,fixedMarkerStruct,movingObjStruct,movingMarkerStruct,handles.interSection_dist_val,handles.refContour_val,handles.refContour_val)
    fixedObjStruct = objStructMerge;
    fixedMarkerStruct = markerStructMerge;
end
handles.objStruct = objStructMerge;
handles.markerStruct = markerStructMerge;
guidata(hObject,handles);
disp('Data appended!');


function handles = imgFilenames_Callback(hObject, eventdata, handles)
handles.imgFilenames_val = get(hObject,'String');
% init mapFilename based on image filename
if (handles.imgFilenames_val(1) == '{') & (handles.imgFilenames_val(end) == '}')
    handles.filelist = eval(handles.imgFilenames_val);
elseif strcmp(handles.imgFilenames_val(end-3:end),'.txt')
    T = readtable([handles.imgDir_val,handles.imgFilenames_val],'Delimiter',',','ReadVariableNames',false);
    handles.filelist = T.Var1;
else
    error('File list format not recognized!');
end   

handles.mapFilename_val = ['serialSections_',handles.filelist{1},'_',num2str(length(handles.filelist)),'_files.mat'];
set(handles.mapFilename,'String',handles.mapFilename_val);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function imgFilenames_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.imgFilenames_val = get(hObject,'String');
guidata(hObject,handles);



function diameter_range_Callback(hObject, eventdata, handles)
handles.diameter_range_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function diameter_range_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.diameter_range_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function SNRthresh_Callback(hObject, eventdata, handles)
handles.SNRthresh_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function SNRthresh_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.SNRthresh_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function paramsFile_Callback(hObject, eventdata, handles)
set(hObject,'String',handles.paramsFile_val);
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function paramsFile_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.paramsFile_val = [];
guidata(hObject,handles);

% --- Executes on button press in browse_params.
function browse_params_Callback(hObject, eventdata, handles)
[filename,pathname] = uigetfile({'*.txt';'*.m'},'Select parameters .txt or .m file to load');
if ~filename
    disp('No file selected');
    return;
end
[pathstr,name,ext] = fileparts(filename);
handles.paramsFile_ext = ext;
handles.paramsFile_val = [pathname,filename];
guidata(hObject,handles);
paramsFile_Callback(handles.paramsFile, eventdata, handles);


function bg_thresh_Callback(hObject, eventdata, handles)
handles.bg_thresh_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function bg_thresh_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.bg_thresh_val = str2num(get(hObject,'String'));
guidata(hObject,handles);



function spot_channels_Callback(hObject, eventdata, handles)
handles.spot_channels_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function spot_channels_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.spot_channels_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function bg_channel_Callback(hObject, eventdata, handles)
handles.bg_channel_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function bg_channel_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.bg_channel_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in add_coloc_marker.
function handles = colocalize_chans_Callback(hObject, eventdata, handles)
handles.coloc = get(hObject,'Value');
guidata(hObject,handles);



function mapFilename_Callback(hObject, eventdata, handles)
handles.mapFilename_val = get(hObject,'String');
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function mapFilename_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.mapFilename_val = get(hObject,'String');
guidata(hObject,handles);

% --- Executes on button press in map_objects.
function map_objects_Callback(hObject, eventdata, handles)

% set parameters
minD = handles.diameter_range_val(1);
maxD = handles.diameter_range_val(2);
maxA = (maxD/2)^2*pi;
minA = (minD/2)^2*pi;
min_size = minA/maxA;
if isempty(handles.paramsFile_val)
    disp('Applying parameters from BB GUI...')
    params = [];
    BuildaBrain_params;
    params.hp_sigma_sharp = maxD;
    params.diameter = maxD;
    params.min_size = min_size;
    params.max_size = 1;
    params.thresh_rel = handles.SNRthresh_val;
    params.bg_threshfactor = handles.bg_thresh_val;
    params.coloc = handles.coloc;
else
    disp('Applying parameters from file...')
    if strcmp(handles.paramsFile_ext,'.m')
        run(handles.paramsFile_val);
        %params = run_script_path(handles.paramsFile_val,'params'); for m-files
    else
        params = msproc_table2params(handles.paramsFile_val);
    end
end
params
slideFileNames = msproc_bf_mapBlobsInCZIBrainScan(handles.imgDir_val,handles.filelist,handles.spot_channels_val,handles.bg_channel_val, params, handles.mapFilename_val)
disp('Map file created!');

% --- Executes on button press in reset_params.
function reset_params_Callback(hObject, eventdata, handles)
handles.paramsFile_val = [];
guidata(hObject,handles);
paramsFile_Callback(handles.paramsFile, eventdata, handles)



function single_img_specs_Callback(hObject, eventdata, handles)
handles.single_img_specs_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function single_img_specs_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.single_img_specs_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in detect.
function detect_Callback(hObject, eventdata, handles)
specs = handles.single_img_specs_val;
displaySpecs = handles.single_img_display_val;

slideNum = specs(1); 
sceneNum = specs(2); 
channelNum = displaySpecs(1); 
planeNum = displaySpecs(2);
img_sat_pct = displaySpecs(3);
filepath = [handles.imgDir_val,handles.filelist{slideNum}];

% set parameters
minD = handles.diameter_range_val(1);
maxD = handles.diameter_range_val(2);
maxA = (maxD/2)^2*pi;
minA = (minD/2)^2*pi;
min_size = minA/maxA;
if isempty(handles.paramsFile_val)
    disp('Appling params from BB gui...');
    params = [];
    BuildaBrain_params;
    params.hp_sigma_sharp = maxD;
    params.diameter = maxD;
    params.min_size = min_size;
    params.max_size = 1;
    params.thresh_rel = handles.SNRthresh_val;
    params.bg_threshfactor = handles.bg_thresh_val;
    params.coloc = handles.coloc;
else
    disp('Appling params from file...');
    if strcmp(handles.paramsFile_ext,'.m')
        run(handles.paramsFile_val);
        %params = run_script_path(handles.paramsFile_val,'params');
    else
        params = msproc_table2params(handles.paramsFile_val);
    end
end
params

% map spots
% test spot detection in single channel
% paramChannelNum = find(handles.spot_channels_val == channelNum);
% disp(['Detecting spots in Image channel #',num2str(channelNum),', spot channel index #',num2str(paramChannelNum),'...']);
% if size(params,2)>1
%     disp(['Applying params(',num2str(paramChannelNum),') to image channel ',num2str(channelNum),'...']);
%     subparams = params(paramChannelNum);
% else
%     subparams = params;
% end
% if length(subparams.thresh_rel)>1
%     subparams.thresh_rel = subparams.thresh_rel(paramChannelNum);
% end
% if isfield(subparams,'abs_thresh')
%     if length(subparams.abs_thresh)>1
%         subparams.abs_thresh = subparams.thresh_rel(paramChannelNum);
%     end
% end
%slide = msproc_bf_mapInCZISeriesFile(filepath, channelNum,  handles.bg_channel_val, subparams, sceneNum);
% test spot detection in all selected channels
slide = msproc_bf_mapInCZISeriesFile(filepath, handles.spot_channels_val,  handles.bg_channel_val, params, sceneNum);
disp('Plotting in image...');
msproc_plotBlobsInCZIImage(slide,sceneNum,channelNum, planeNum, img_sat_pct)
disp('Done plotting!');



function coloc_inds_Callback(hObject, eventdata, handles)
handles.coloc_inds_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function coloc_inds_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.coloc_inds_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in add_coloc_marker.
function add_coloc_marker_Callback(hObject, eventdata, handles)
disp('Adding colocalization marker...');
chans2coloc = handles.coloc_inds_val;
channel1 = chans2coloc(1); channel2 = chans2coloc(2);
markerStructNew = neurolucida_colocalize_markerStruct(handles.markerStruct,channel1,channel2,handles.coloc_dist_val);
handles.markerStruct = markerStructNew;
guidata(hObject,handles);


function coloc_thresh_dist_Callback(hObject, eventdata, handles)
handles.coloc_dist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function coloc_thresh_dist_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.coloc_dist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes when uipanel4 is resized.
function uipanel4_SizeChangedFcn(hObject, eventdata, handles)
% hObject    handle to uipanel4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function uipanel4_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to uipanel4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in is3D.
function is3D_Callback(hObject, eventdata, handles)
handles.is3D_val = get(hObject,'Value');
guidata(hObject,handles);

function conts2plot_Callback(hObject, eventdata, handles)
handles.conts2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function conts2plot_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.conts2plot_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

function spaceAfterSecs_Callback(hObject, eventdata, handles)
handles.spaceBeforeSecs_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function spaceAfterSecs_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.spaceBeforeSecs_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in addSpaces.
function addSpaces_Callback(hObject, eventdata, handles)
disp('Adding empty section spacing before specified sections...');
[objStructNew,markerStructNew] = neurolucida_add_space_before_sections(handles.objStruct,handles.markerStruct,handles.spaceBeforeSecs_val,handles.interSection_dist_val);
handles.objStruct = objStructNew;
handles.markerStruct = markerStructNew;
guidata(hObject,handles);
disp('Spacing added!');


% --- Executes on button press in removeSpaces.
function removeSpaces_Callback(hObject, eventdata, handles)
disp('Removing empty section spacing before specified sections...');
[objStructNew,markerStructNew] = neurolucida_add_space_before_sections(handles.objStruct,handles.markerStruct,handles.spaceBeforeSecs_val,-handles.interSection_dist_val);
handles.objStruct = objStructNew;
handles.markerStruct = markerStructNew;
guidata(hObject,handles);
disp('Spacing removed!');


function zDist_Callback(hObject, eventdata, handles)
handles.zDist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function zDist_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.zDist_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes on button press in makeTifs.
function makeTifs_Callback(hObject, eventdata, handles)
channels = [handles.bg_channel_val,handles.spot_channels_val];
msproc_bf_TifConverter(handles.imgDir_val,handles.filelist,channels,handles.maxProject_val);
disp('Done creating images!');

% --- Executes on button press in maxProject.
function maxProject_Callback(hObject, eventdata, handles)
handles.maxProject_val = get(hObject,'Value');
guidata(hObject,handles);


% --- Executes on button press in dilate.
function dilate_Callback(hObject, eventdata, handles)
disp('Dilating edges...');
%handles.serialSections = msproc_serialStructRemoveEdgePts(handles.serialSections);
handles.serialSections = msproc_serialStructDilateEdges(handles.serialSections,handles.dilatePixels_val,handles.secs2correct_val);
guidata(hObject,handles);
if handles.dilatePixels_val>=0;
    disp('Section outlines dilated!');
else
    disp('Sections outlines eroded!');
end


% --- Executes on button press in render3D.
function render3D_Callback(hObject, eventdata, handles)
contours3D;
disp('Contours 3D tool opened!')

% --- Executes on button press in mcam_tool.
function mcam_tool_Callback(hObject, eventdata, handles)
ConstructaCord;
disp('Manual Align and Contour Tool opened!')


function single_img_display_Callback(hObject, eventdata, handles)
handles.single_img_display_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function single_img_display_CreateFcn(hObject, eventdata, handles)
handles.single_img_display_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function dilatePixels_Callback(hObject, eventdata, handles)
handles.dilatePixels_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function dilatePixels_CreateFcn(hObject, eventdata, handles)
handles.dilatePixels_val = str2num(get(hObject,'String'));
guidata(hObject,handles);
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in removeUnboundedButton.
function removeUnboundedButton_Callback(hObject, eventdata, handles)
disp('Removing unbounded points in all sections...');
handles.serialSections = msproc_serialStructRemoveUnboundedPts(handles.serialSections);
guidata(hObject,handles);
disp('Unbounded points removed!')


% --- Executes on button press in removeEdgesButton.
function removeEdgesButton_Callback(hObject, eventdata, handles)
disp('Removing putative edge spots in all sections...');
handles.serialSections = msproc_serialStructRemoveEdgePts(handles.serialSections);
disp('Edge spots removed!');


% --- Executes on button press in reportCounts.
function reportCounts_Callback(hObject, eventdata, handles)
[filename,pathname] = uigetfile('*.ASC','Select contours .ASC file to count');
if isempty(handles.interSection_dist_val)
    error('BB error: please specify inter-section distance for contour volume estimates');
end
write_PtsInContours([pathname,filename],handles.interSection_dist_val);


function InterpCont_Callback(hObject, eventdata, handles)
contNames = handles.conts2interp_val;
if ~isempty(contNames)
    names = {contNames};
else
    names = {};
end
handles.objStruct = neurolucida_interpContours(handles.objStruct,names);
guidata(hObject,handles);

function conts2interp_Callback(hObject, eventdata, handles)
handles.conts2interp_val = get(hObject,'String');
if ~isempty(handles.conts2interp_val)
    handles.conts2interp_val = ['"',handles.conts2interp_val,'"'];
end
guidata(hObject,handles);

function conts2interp_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.conts2interp_val = get(hObject,'String');
if ~isempty(handles.conts2interp_val)
    handles.conts2interp_val = ['"',handles.conts2interp_val,'"'];
end
guidata(hObject,handles);


% --- Executes on button press in help.
function help_Callback(hObject, eventdata, handles)
disp('Opening manual (pdf file reader required) ...');
open('Build-a-brain_Manual.pdf');
disp('Please refer to the manual!');


% --- Executes on button press in stopnow.
function stopnow_Callback(hObject, eventdata, handles)
global STOP;
STOP = get(hObject,'Value');
if STOP
    disp('Manual editing OFF!');
    set(hObject,'String','OFF');
    set(hObject,'BackgroundColor','r');
else
    disp('Manual editing ON!');
    set(hObject,'String','ON');
    set(hObject,'BackgroundColor','g');
end
guidata(hObject,handles);
%checkstop();

% --- Executes on button press in workDir_browse.
function workDir_browse_Callback(hObject, eventdata, handles)
handles.workingDir_val = uigetdir(pwd,'Please select working directory');
guidata(hObject,handles);
cd(handles.workingDir_val);
workingDirectory_Callback( handles.workingDirectory , eventdata, handles);


function workingDirectory_Callback(hObject, eventdata, handles)
set(hObject,'String',handles.workingDir_val);
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function workingDirectory_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.workingDir_val = pwd;
set(hObject,'String',handles.workingDir_val);
guidata(hObject,handles);


% --- Executes on button press in exportData.
function exportData_Callback(hObject, eventdata, handles)
[filename,pathname] = uigetfile('*.ASC','Select contours .ASC file to export');
neurolucidaASC2csv([pathname,filename]);


% --- Executes on button press in addImportSpots.
function addImportSpots_Callback(hObject, eventdata, handles)
disp('Format for spots file is a .csv file with columns: X,Y,Type,Slice');
disp('X = horizontal pixel location of spots in image, Y = vertical pixel location of spot in image');
disp('Type = marker channel number of each spot, Slice = section number of each spot');
handles.serialSections = msproc_importSpotsFromFile(handles.serialSections);
guidata(hObject,handles);


% --- Executes on button press in removeMarkers.
function removeMarkers_Callback(hObject, eventdata, handles)
contNames = handles.conts2interp_val;
if ~isempty(contNames)
    names = {contNames};
else
    names = {};
end
handles.markerStruct = neurolucida_removePtsInContours(handles.objStruct,handles.markerStruct,handles.coloc_inds_val,names);
guidata(hObject,handles);


% --- Executes on button press in removeMarkersOut.
function removeMarkersOut_Callback(hObject, eventdata, handles)
contName = handles.conts2interp_val;
handles.markerStruct = neurolucida_removePtsOutOfContour(handles.objStruct,handles.markerStruct,handles.coloc_inds_val,contName);
guidata(hObject,handles);


% --- Executes on button press in alignMergedSections.
function alignMergedSections_Callback(hObject, eventdata, handles)
handles.alignMerger_val = get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in ImageTools.
function ImageTools_Callback(hObject, eventdata, handles)
showCurrentImageTools;



function az_angle_Callback(hObject, eventdata, handles)
handles.yaw_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function az_angle_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.yaw_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);



function pitch_angle_rotate_Callback(hObject, eventdata, handles)
handles.pitch_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function pitch_angle_rotate_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.pitch_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


function roll_angle_rotate_Callback(hObject, eventdata, handles)
handles.roll_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes during object creation, after setting all properties.
function roll_angle_rotate_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.roll_angle_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in rs_rotate.
function rs_rotate_Callback(hObject, eventdata, handles)
handles.objStructTemp = handles.objStruct;
handles.markerStructTemp = handles.markerStruct;
[objStructR,markerStructR] = neurolucida_3d_rotate(handles.objStruct,handles.markerStruct,handles.yaw_angle_val,handles.pitch_angle_val,handles.roll_angle_val,handles.interSection_dist_val,handles.zres_val,handles.jitterz_val);
handles.objStruct = objStructR;
handles.markerStruct = markerStructR;
guidata(hObject,handles);
disp('Points rotated!');



function rs_interval_Callback(hObject, eventdata, handles)
handles.rs_interval_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function rs_interval_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.rs_interval_val = str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes on button press in rs_reslice.
function rs_reslice_Callback(hObject, eventdata, handles)
dilation = 2*handles.zres_val;
RSparams = neurolucida_load_RSparams([],[],[],dilation);
handles.objStructTemp = handles.objStruct;
handles.markerStructTemp = handles.markerStruct;
[objStructRS,markerStructRS] = neurolucida_resection(handles.objStruct,handles.markerStruct,handles.interSection_dist_val,handles.rs_interval_val,RSparams);
handles.objStruct = objStructRS;
handles.markerStruct = markerStructRS;
guidata(hObject,handles);
disp('Points resectioned!');


% --- Executes on button press in rs_undo.
function rs_undo_Callback(hObject, eventdata, handles)
if ~isempty(handles.objStructTemp) & ~isempty(handles.markerStructTemp)
    handles.objStruct = handles.objStructTemp;
    handles.markerStruct = handles.markerStructTemp;
    handles.objStructTemp = [];
    handles.markerStructTemp = [];
    guidata(hObject,handles);
    disp('Last action undone!');
else
    disp('No action to undo!');
end


% z resolution (%)
function edit41_Callback(hObject, eventdata, handles)
handles.zres_val = 0.01*str2num(get(hObject,'String'));
guidata(hObject,handles);

% --- Executes during object creation, after setting all properties.
function edit41_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
handles.zres_val = 0.01*str2num(get(hObject,'String'));
guidata(hObject,handles);


% --- Executes on button press in addFromQupath.
function addFromQupath_Callback(hObject, eventdata, handles)
disp('Format for points file is a .csv file with 3 columns');
disp('Column 1: Full file path for each qupath .tsv -points file corresponding to a serial section');
disp('Column 2: serial section numbers corresponding to the files in column 1');
disp('Column 3: Names of each of the point classes to import');
T = qupath_tsvList2ImageJ;
handles.serialSections = msproc_importSpotsFromFile(handles.serialSections,T);
guidata(hObject,handles);


% --- Executes on button press in alignSlab.
function alignSlab_Callback(hObject, eventdata, handles)
handles.alignSlab_val = get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in mergeAffine.
function mergeAffine_Callback(hObject, eventdata, handles)
handles.mergeAffine_val = get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in mergeAffineAuto.
function mergeAffineAuto_Callback(hObject, eventdata, handles)
handles.mergeAffineAuto_val = get(hObject,'Value');
guidata(hObject, handles);
